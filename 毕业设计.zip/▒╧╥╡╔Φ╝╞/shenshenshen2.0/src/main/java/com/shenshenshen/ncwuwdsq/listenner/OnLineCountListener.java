package com.shenshenshen.ncwuwdsq.listenner;

import java.util.Date;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.utils.ShenStringUtils;

/**
*@author 申中秋
*@date 2019年4月27日下午1:58:54
*/
@Component
@WebListener
public class OnLineCountListener implements HttpSessionListener{

	@Autowired
	private StringRedisTemplate redisTemplate;
	@Override
	public void sessionCreated(HttpSessionEvent arg0) {
		System.out.println("session创建"+ShenStringUtils.dateToString("yyyy-MM-dd:HH-mm-ss", new Date()));
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
		System.err.println("销毁session"+ShenStringUtils.dateToString("yyyy-MM-dd:HH-mm-ss", new Date()));
		HttpSession session = arg0.getSession();
		Userinfo userinfo = (Userinfo)session.getAttribute("user");
		redisTemplate.delete("online_"+userinfo.getUsername());
	}

}
