package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Answerinfo;
import com.shenshenshen.ncwuwdsq.domain.AnswerinfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AnswerinfoMapper {
    int countByExample(AnswerinfoExample example);

    int deleteByExample(AnswerinfoExample example);

    int insert(Answerinfo record);

    int insertSelective(Answerinfo record);

    List<Answerinfo> selectByExampleWithBLOBs(AnswerinfoExample example);

    List<Answerinfo> selectByExample(AnswerinfoExample example);

    int updateByExampleSelective(@Param("record") Answerinfo record, @Param("example") AnswerinfoExample example);

    int updateByExampleWithBLOBs(@Param("record") Answerinfo record, @Param("example") AnswerinfoExample example);

    int updateByExample(@Param("record") Answerinfo record, @Param("example") AnswerinfoExample example);
}