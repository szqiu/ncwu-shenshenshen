package com.shenshenshen.ncwuwdsq.rabbitmq;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.support.CorrelationData;
/**
 * 
*@author 申中秋
*@date 2019年4月16日下午8:45:02
*/
public class MsgSendConfirmCallBack implements RabbitTemplate.ConfirmCallback{

	@Override
	public void confirm(CorrelationData correlationData, boolean ack, String cause) {
		System.out.println("MsgSendConfirmCallBack  , 回调id:" + correlationData);
		if (ack) {
			System.err.println("消费成功");
		} else{
			System.err.println("消息消费失败:" + cause+"\n重新发送");
		}
		
	}

}
