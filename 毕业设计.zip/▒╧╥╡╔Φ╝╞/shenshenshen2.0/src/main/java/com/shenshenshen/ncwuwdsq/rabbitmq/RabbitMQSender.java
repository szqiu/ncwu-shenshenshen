package com.shenshenshen.ncwuwdsq.rabbitmq;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.domain.Pushinfo;

/**
 * 新消息队列
 * 
 * @author 申中秋
 * @date 2019年4月16日下午4:32:43
 */
@Component
public class RabbitMQSender {
	@Autowired
	private RabbitTemplate rabbitTemplate;

	/**
	 * 像队列中插入赞同答案提醒
	 * 
	 * @param pushinfo
	 * @param questionContant
	 * @param info
	 */
	public void sendAgreeInfoNews(Pushinfo pushinfo, String questionContant) {
		String pushContant = pushinfo.getFromUser() + "赞同了你在问题" + "“" + questionContant + "”" + "下的回答";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_agreeanswer", jsonObject.toString());
	}

	/**
	 * 像队列中插入反对答案提醒
	 * @param pushinfo
	 * @param questionContant
	 */
	public void sendAgainstInfoNews(Pushinfo pushinfo, String questionContant) {
		String pushContant = pushinfo.getFromUser() + "反对了你在问题" + "“" + questionContant + "”" + "下的回答";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_againstanswer", jsonObject.toString());
	}

	/**
	 * 像队列中插入答案评论提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendCommentAnswerInfoNews(Pushinfo pushinfo, String questionContant) {
		String pushContant = pushinfo.getFromUser() + "评论了你在问题" + "“" + questionContant + "”" + "下的回答";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_commentanswer", jsonObject.toString());
		
	}

	/**
	 * 像队列中插入收藏答案
	 * @param pushinfo
	 * @param string
	 */
	public void sendLikeAnswerInfoNews(Pushinfo pushinfo, String questionContant) {
		String pushContant = pushinfo.getFromUser() + "收藏了你在问题" + "“" + questionContant + "”" + "下的回答";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_likeanswer", jsonObject.toString());
		
	}
	
	/**
	 * 像队列中插入赞文章提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendZanArticleInfoNews(Pushinfo pushinfo, String title) {
		String pushContant = pushinfo.getFromUser() + "赞了你标题为：" + "“" + title + "”" + "的文章";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_zanarticle", jsonObject.toString());
		
	}
	
	/**
	 * 像队列中插入赞文章提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendCaiArticleInfoNews(Pushinfo pushinfo, String title) {
		String pushContant = pushinfo.getFromUser() + "踩了你标题为：" + "“" + title + "”" + "的文章";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_caiarticle", jsonObject.toString());
		
	}
	
	/**
	 * 像队列中插入赞文章提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendCommentArticleInfoNews(Pushinfo pushinfo, String title) {
		String pushContant = pushinfo.getFromUser() + "评论了你标题为：" + "“" + title + "”" + "的文章";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_commentarticle", jsonObject.toString());
		
	}
	
	/**
	 * 像队列中插入赞文章提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendShoucangArticleInfoNews(Pushinfo pushinfo, String title) {
		String pushContant = pushinfo.getFromUser() + "收藏了你标题为：" + "“" + title + "”" + "的文章";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_shoucangarticle", jsonObject.toString());
		
	}

	/**
	 * 向队列中插入答案评论回复提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendBackCommentAnswerInfoNews(Pushinfo pushinfo, String string) {
		String pushContant = pushinfo.getFromUser() + "回复了你在问题" + "“" + string + "”" + "的答案下的评论";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_rebackcommentanswer", jsonObject.toString());
		
	}
	
	/**
	 * 向队列中插入文章评论回复提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendBackCommentArticleInfoNews(Pushinfo pushinfo, String title) {
		String pushContant = pushinfo.getFromUser() + "回复了你在标题为" + "“" + title + "”" + "下的评论";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_rebackcommentarticle", jsonObject.toString());
		
	}

	/**
	 * 向队列中插入私信提醒
	 * @param pushinfo
	 * @param string
	 */
	public void sendLetterInfoNews(Pushinfo pushinfo, String content) {
		String pushContant = pushinfo.getFromUser() + "私信了你：" + "“" + content + "”";
		// 将对象转换为json字符串
		pushinfo.setPushContant(pushContant);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		// 插入队列
		rabbitTemplate.convertAndSend("shenshenshen_pushnews", "key_rebackcommentarticle", jsonObject.toString());
		
	}
}
