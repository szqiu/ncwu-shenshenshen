package com.shenshenshen.ncwuwdsq.service.api;

import java.util.List;
import java.util.Map;

import com.shenshenshen.ncwuwdsq.domain.Userinfo;

/**
 * 赞同业务接口
*@author 申中秋
*@date 2019年4月11日下午12:10:26
*/
public interface IAgreeAndAgainstService {
	/**
	 * 获取当前用户赞同记录
	 * @param userid
	 * @param start
	 * @param size
	 * @return
	 */
	public List<Map<String, Object>> getAgreeRecordByUid(String userid, Integer start, Integer size);

	/**
	 * 计算用户赞同记录总数
	 * @param userid
	 * @return
	 */
	public long countAgreeByUid(String username);
	
	/**
	 * 赞同答案
	 * @param answerid
	 * @param user 
	 */
	public void agree(String answerid, Userinfo user);

	/**
	 * 获取用户得到的总赞同数
	 * @param username
	 * @return
	 */
	public long countUserAgree(String username);

	/**
	 * 反对答案
	 * @param answerid
	 * @param user
	 */
	public void against(String answerid, Userinfo user);

	/**
	 * 收藏答案
	 * @param answerid
	 * @param user
	 */
	public void like(String answerid, Userinfo user);

	/**
	 * 获取用户反对记录
	 * @param username
	 * @param start
	 * @param size
	 * @return
	 */
	public List<Map<String, Object>> getAgainstRecordByUid(String username, Integer start, Integer size);

	/**
	 * 获取反对记录数
	 * @param username
	 * @return
	 */
	public long countAgainstByUid(String username);
	
	/**
	 * 判断答案和文章是否已被用户赞同
	 * @param username
	 * @param mainid
	 * @return
	 */
	public boolean is_Agree(String username, String mainid);
	
	/**
	 * 判断答案和文章是否已被用户反对
	 * @param username
	 * @param mainid
	 * @return
	 */
	public boolean is_Against(String username, String mainid);

	/**
	 * 判断是否已经收藏
	 * @param user
	 * @param mainid
	 * @return
	 */
	public boolean is_like(Userinfo user, String mainid);
}
