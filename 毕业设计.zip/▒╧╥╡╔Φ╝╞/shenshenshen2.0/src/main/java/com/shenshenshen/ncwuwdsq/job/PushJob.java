package com.shenshenshen.ncwuwdsq.job;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.controller.WebSocketServer;

/**
 * 消息推送job
*@author 申中秋
*@date 2019年4月29日上午9:36:12
*/
@Component
@Configurable
@EnableScheduling
public class PushJob {
	@Autowired
	private StringRedisTemplate redisTemplate;
	/**
	 * 推送最近30分钟的新消息
	 */
	@Scheduled(fixedRate = 1000*60)
	public void PushNews() {
		System.err.println("推送");
		Set<String> keySet = redisTemplate.keys("push_*");
		for (String key : keySet) {
			String info = redisTemplate.opsForValue().get(key);
			JSONObject push = JSON.parseObject(info);
			if (redisTemplate.opsForValue().get("online_"+push.getString("toUser")) != null) {
				WebSocketServer.sendInfo(push.getString("pushContant"), push.getString("toUser"));
			}
			
		}
	}
}
