package com.shenshenshen.ncwuwdsq.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.shenshenshen.ncwuwdsq.domain.Pushinfo;
import com.shenshenshen.ncwuwdsq.domain.PushinfoExample;
import com.shenshenshen.ncwuwdsq.mapper.PushinfoMapper;
import com.shenshenshen.ncwuwdsq.service.api.INewsPushService;

/**
 * 服务器消息推送业务实现类
*@author 申中秋
*@date 2019年4月23日下午7:15:16
*/
@Service
public class NewsPushServiceImpl implements INewsPushService{

	@Autowired
	private PushinfoMapper pushMapper;
	@Autowired
	private StringRedisTemplate redisTemplate;
	@Override
	public void addPush(Pushinfo pushinfo) {
		pushMapper.insert(pushinfo);
		
	}
	@Override
	public List<Pushinfo> getRecentlyNews(String username) {
		PushinfoExample example = new PushinfoExample();
		example.setOrderByClause(" creatdate desc limit 0,8");
		example.createCriteria().andToUserEqualTo(username);
		return pushMapper.selectByExample(example);
	}
	@Override
	public long countByUname(String username) {
		PushinfoExample example = new PushinfoExample();
		example.createCriteria().andToUserEqualTo(username).andIsReceivedEqualTo(0);
		return pushMapper.countByExample(example);
	}
	@Override
	public List<Pushinfo> getPushinfoByUser(Integer start, Integer size, String username) {
		PushinfoExample example = new PushinfoExample();
		example.setOrderByClause(" creatdate desc limit "+start+","+size);
		example.createCriteria().andToUserEqualTo(username).andIsReceivedEqualTo(0);
		return pushMapper.selectByExample(example);
	}
	@Override
	public long countOldByUname(String username) {
		PushinfoExample example = new PushinfoExample();
		example.createCriteria().andToUserEqualTo(username).andIsReceivedEqualTo(1);
		return pushMapper.countByExample(example);
	}
	@Override
	public List<Pushinfo> getPushOldinfoByUser(Integer start, Integer size, String username) {
		PushinfoExample example = new PushinfoExample();
		example.setOrderByClause(" creatdate desc limit "+start+","+size);
		example.createCriteria().andToUserEqualTo(username).andIsReceivedEqualTo(1);
		return pushMapper.selectByExample(example);
	}
	@Override
	public long countLetter(String username) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public boolean readNew(String pushid) {
		PushinfoExample example = new PushinfoExample();
		example.createCriteria().andPushidEqualTo(pushid);
		List<Pushinfo> list = pushMapper.selectByExample(example);
		// 删除redis中的待推送消息
		if (list != null && list.size() > 0) {
			Pushinfo deletepush = list.get(0);
			redisTemplate.delete("push_"+deletepush.getFromUser()+"_"+deletepush.getPushid());
		}
		Pushinfo pushinfo = new Pushinfo();
		pushinfo.setIsReceived(1);
		if (pushMapper.updateByExampleSelective(pushinfo, example) > 0) {
			return true;
		}
		return false;
	}

}
