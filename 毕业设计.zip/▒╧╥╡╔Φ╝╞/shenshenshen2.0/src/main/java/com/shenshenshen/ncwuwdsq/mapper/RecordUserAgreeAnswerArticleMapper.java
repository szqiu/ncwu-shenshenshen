package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.RecordUserAgreeAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgreeAnswerArticleExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RecordUserAgreeAnswerArticleMapper {
    int countByExample(RecordUserAgreeAnswerArticleExample example);

    int deleteByExample(RecordUserAgreeAnswerArticleExample example);

    int insert(RecordUserAgreeAnswerArticle record);

    int insertSelective(RecordUserAgreeAnswerArticle record);

    List<RecordUserAgreeAnswerArticle> selectByExample(RecordUserAgreeAnswerArticleExample example);

    int updateByExampleSelective(@Param("record") RecordUserAgreeAnswerArticle record, @Param("example") RecordUserAgreeAnswerArticleExample example);

    int updateByExample(@Param("record") RecordUserAgreeAnswerArticle record, @Param("example") RecordUserAgreeAnswerArticleExample example);
}