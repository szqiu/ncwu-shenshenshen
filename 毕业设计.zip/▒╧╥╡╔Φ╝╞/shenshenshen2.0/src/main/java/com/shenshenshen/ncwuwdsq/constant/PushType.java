package com.shenshenshen.ncwuwdsq.constant;
/**
 * 服务器消息推送类别常量
*@author 申中秋
*@date 2019年4月23日下午4:10:36
*/
public class PushType {
	/**
	 * 赞同答案
	 */
	public static Integer AGREEANSWER = 0;
	/**
	 * 反对答案
	 */
	public static Integer AGAINSTANSWER = 1;
	/**
	 * 收藏答案
	 */
	public static Integer LIKEANSWER = 2;
	/**
	 * 赞文章
	 */
	public static Integer ZANARTICLE = 3;
	/**
	 * 踩文章
	 */
	public static Integer CAIARTICLE = 4;
	/**
	 * 收藏文章
	 */
	public static Integer LIKEARTICLE = 5;
	/**
	 * 评论答案
	 */
	public static Integer COMMENTANSWER = 6;
	/**
	 * 评论文章
	 */
	public static Integer COMMENTARTICLE = 7;
	/**
	 * 回复答案评论
	 */
	public static Integer BACKCOMMENTANSWER = 8;
	/**
	 * 回复文章评论
	 */
	public static Integer BACKCOMMENTARTICLE = 9;
	/**
	 * 私信
	 */
	public static Integer LETTER = 10;
}
