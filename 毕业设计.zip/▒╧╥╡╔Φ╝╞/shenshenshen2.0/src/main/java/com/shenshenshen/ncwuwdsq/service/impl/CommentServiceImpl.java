package com.shenshenshen.ncwuwdsq.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shenshenshen.ncwuwdsq.domain.Answerinfo;
import com.shenshenshen.ncwuwdsq.domain.AnswerinfoExample;
import com.shenshenshen.ncwuwdsq.domain.Comment;
import com.shenshenshen.ncwuwdsq.domain.CommentExample;
import com.shenshenshen.ncwuwdsq.mapper.AnswerinfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.CommentMapper;
import com.shenshenshen.ncwuwdsq.service.api.ICommentService;

/**
 * @author 申中秋
 * @date 2019年4月9日下午7:48:22
 */
@Service
public class CommentServiceImpl implements ICommentService {

	@Autowired
	private CommentMapper commentMapper;
	@Autowired
	private AnswerinfoMapper answerMapper;

	@Override
	@Transactional(rollbackFor = Exception.class)// 开启事务 加入线程锁
	public synchronized void addAnswerComment(Comment comment) {
		// 插入评论记录
		commentMapper.insert(comment);
		// 获取问题信息
		Answerinfo answerinfo = null;
		AnswerinfoExample example = new AnswerinfoExample();
		example.createCriteria().andAnsweridEqualTo(comment.getAnswerguid());
		List<Answerinfo> list = answerMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			answerinfo = list.get(0);
		}
		// 更新问题信息
		if (answerinfo != null) {
			answerinfo.setCommentnum(answerinfo.getCommentnum() + 1);
			answerinfo.setHot(answerinfo.getHot() + 7);
		}
		answerMapper.updateByExample(answerinfo, example);
	}

	@Override
	public List<Comment> getCommentByQid(String answerid) {
		CommentExample commentExample = new CommentExample();
		commentExample.setOrderByClause(" creatdate desc");
		commentExample.createCriteria().andAnswerguidEqualTo(answerid);
		List<Comment> comments = commentMapper.selectByExample(commentExample);
		return comments;
	}

	@Override
	public Comment getCommentByid(String commentid) {
		CommentExample example = new CommentExample();
		example.createCriteria().andRowguidEqualTo(commentid);
		List<Comment> list = new ArrayList<>(4);
		list = commentMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

}
