package com.shenshenshen.ncwuwdsq.job;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.service.api.IQuestionAndAnswerService;

/**
 * quartz定时任务
 * 
 * @author 申中秋
 * @date 2019年3月28日下午5:12:50
 */
@Component
@Configurable
@EnableScheduling
public class HotQuestionJob {
	@Autowired
	private IQuestionAndAnswerService questionAndAnswerService;
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	
	/**
	 * 定时更新最热问题top10
	 */
	@Scheduled(fixedRate = 1000*60)
	public void flushHotQuestion() {
		
		List<Map<String, Object>> hotlist = questionAndAnswerService.getHotQuestionAndAnswer();
		for (int i = 0;i < hotlist.size(); i++) {
			JSONObject jsonObject = (JSONObject) JSON.toJSON(hotlist.get(i));
			stringRedisTemplate.opsForValue().set("hot_"+i,jsonObject.toString());
		}
		Set<String> sets = stringRedisTemplate.keys("online_*");
		for (String string : sets) {
		}
		
	}

	// 每1分钟执行一次
	@Scheduled(cron = "0 */1 *  * * * ")
	public void reportCurrentByCron() {
		
	}
}
