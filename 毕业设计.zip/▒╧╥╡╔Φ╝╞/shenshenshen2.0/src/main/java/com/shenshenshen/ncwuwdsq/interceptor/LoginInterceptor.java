package com.shenshenshen.ncwuwdsq.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 登录验证
*@author 申中秋
*@date 2019年3月25日下午2:30:04
*/
public class LoginInterceptor extends HandlerInterceptorAdapter{
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		HttpSession session = request.getSession();
		if (session.getAttribute("user") != null) {
			return true;
		}
		String url = "/shenshenshen/login.html";
		response.sendRedirect(url);
		return false;
	}
}
