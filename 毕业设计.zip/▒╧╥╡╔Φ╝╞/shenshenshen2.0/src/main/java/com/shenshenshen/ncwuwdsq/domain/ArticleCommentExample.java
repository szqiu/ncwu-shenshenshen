package com.shenshenshen.ncwuwdsq.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ArticleCommentExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ArticleCommentExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRowguidIsNull() {
            addCriterion("rowguid is null");
            return (Criteria) this;
        }

        public Criteria andRowguidIsNotNull() {
            addCriterion("rowguid is not null");
            return (Criteria) this;
        }

        public Criteria andRowguidEqualTo(String value) {
            addCriterion("rowguid =", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidNotEqualTo(String value) {
            addCriterion("rowguid <>", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidGreaterThan(String value) {
            addCriterion("rowguid >", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidGreaterThanOrEqualTo(String value) {
            addCriterion("rowguid >=", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidLessThan(String value) {
            addCriterion("rowguid <", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidLessThanOrEqualTo(String value) {
            addCriterion("rowguid <=", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidLike(String value) {
            addCriterion("rowguid like", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidNotLike(String value) {
            addCriterion("rowguid not like", value, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidIn(List<String> values) {
            addCriterion("rowguid in", values, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidNotIn(List<String> values) {
            addCriterion("rowguid not in", values, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidBetween(String value1, String value2) {
            addCriterion("rowguid between", value1, value2, "rowguid");
            return (Criteria) this;
        }

        public Criteria andRowguidNotBetween(String value1, String value2) {
            addCriterion("rowguid not between", value1, value2, "rowguid");
            return (Criteria) this;
        }

        public Criteria andCreatuserIsNull() {
            addCriterion("creatuser is null");
            return (Criteria) this;
        }

        public Criteria andCreatuserIsNotNull() {
            addCriterion("creatuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreatuserEqualTo(String value) {
            addCriterion("creatuser =", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserNotEqualTo(String value) {
            addCriterion("creatuser <>", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserGreaterThan(String value) {
            addCriterion("creatuser >", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserGreaterThanOrEqualTo(String value) {
            addCriterion("creatuser >=", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserLessThan(String value) {
            addCriterion("creatuser <", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserLessThanOrEqualTo(String value) {
            addCriterion("creatuser <=", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserLike(String value) {
            addCriterion("creatuser like", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserNotLike(String value) {
            addCriterion("creatuser not like", value, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserIn(List<String> values) {
            addCriterion("creatuser in", values, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserNotIn(List<String> values) {
            addCriterion("creatuser not in", values, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserBetween(String value1, String value2) {
            addCriterion("creatuser between", value1, value2, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatuserNotBetween(String value1, String value2) {
            addCriterion("creatuser not between", value1, value2, "creatuser");
            return (Criteria) this;
        }

        public Criteria andCreatdateIsNull() {
            addCriterion("creatdate is null");
            return (Criteria) this;
        }

        public Criteria andCreatdateIsNotNull() {
            addCriterion("creatdate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatdateEqualTo(Date value) {
            addCriterion("creatdate =", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateNotEqualTo(Date value) {
            addCriterion("creatdate <>", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateGreaterThan(Date value) {
            addCriterion("creatdate >", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateGreaterThanOrEqualTo(Date value) {
            addCriterion("creatdate >=", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateLessThan(Date value) {
            addCriterion("creatdate <", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateLessThanOrEqualTo(Date value) {
            addCriterion("creatdate <=", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateIn(List<Date> values) {
            addCriterion("creatdate in", values, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateNotIn(List<Date> values) {
            addCriterion("creatdate not in", values, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateBetween(Date value1, Date value2) {
            addCriterion("creatdate between", value1, value2, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateNotBetween(Date value1, Date value2) {
            addCriterion("creatdate not between", value1, value2, "creatdate");
            return (Criteria) this;
        }

        public Criteria andArticleguidIsNull() {
            addCriterion("articleguid is null");
            return (Criteria) this;
        }

        public Criteria andArticleguidIsNotNull() {
            addCriterion("articleguid is not null");
            return (Criteria) this;
        }

        public Criteria andArticleguidEqualTo(String value) {
            addCriterion("articleguid =", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidNotEqualTo(String value) {
            addCriterion("articleguid <>", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidGreaterThan(String value) {
            addCriterion("articleguid >", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidGreaterThanOrEqualTo(String value) {
            addCriterion("articleguid >=", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidLessThan(String value) {
            addCriterion("articleguid <", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidLessThanOrEqualTo(String value) {
            addCriterion("articleguid <=", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidLike(String value) {
            addCriterion("articleguid like", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidNotLike(String value) {
            addCriterion("articleguid not like", value, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidIn(List<String> values) {
            addCriterion("articleguid in", values, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidNotIn(List<String> values) {
            addCriterion("articleguid not in", values, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidBetween(String value1, String value2) {
            addCriterion("articleguid between", value1, value2, "articleguid");
            return (Criteria) this;
        }

        public Criteria andArticleguidNotBetween(String value1, String value2) {
            addCriterion("articleguid not between", value1, value2, "articleguid");
            return (Criteria) this;
        }

        public Criteria andContantIsNull() {
            addCriterion("contant is null");
            return (Criteria) this;
        }

        public Criteria andContantIsNotNull() {
            addCriterion("contant is not null");
            return (Criteria) this;
        }

        public Criteria andContantEqualTo(String value) {
            addCriterion("contant =", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantNotEqualTo(String value) {
            addCriterion("contant <>", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantGreaterThan(String value) {
            addCriterion("contant >", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantGreaterThanOrEqualTo(String value) {
            addCriterion("contant >=", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantLessThan(String value) {
            addCriterion("contant <", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantLessThanOrEqualTo(String value) {
            addCriterion("contant <=", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantLike(String value) {
            addCriterion("contant like", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantNotLike(String value) {
            addCriterion("contant not like", value, "contant");
            return (Criteria) this;
        }

        public Criteria andContantIn(List<String> values) {
            addCriterion("contant in", values, "contant");
            return (Criteria) this;
        }

        public Criteria andContantNotIn(List<String> values) {
            addCriterion("contant not in", values, "contant");
            return (Criteria) this;
        }

        public Criteria andContantBetween(String value1, String value2) {
            addCriterion("contant between", value1, value2, "contant");
            return (Criteria) this;
        }

        public Criteria andContantNotBetween(String value1, String value2) {
            addCriterion("contant not between", value1, value2, "contant");
            return (Criteria) this;
        }

        public Criteria andToCommentidIsNull() {
            addCriterion("to_commentid is null");
            return (Criteria) this;
        }

        public Criteria andToCommentidIsNotNull() {
            addCriterion("to_commentid is not null");
            return (Criteria) this;
        }

        public Criteria andToCommentidEqualTo(String value) {
            addCriterion("to_commentid =", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidNotEqualTo(String value) {
            addCriterion("to_commentid <>", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidGreaterThan(String value) {
            addCriterion("to_commentid >", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidGreaterThanOrEqualTo(String value) {
            addCriterion("to_commentid >=", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidLessThan(String value) {
            addCriterion("to_commentid <", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidLessThanOrEqualTo(String value) {
            addCriterion("to_commentid <=", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidLike(String value) {
            addCriterion("to_commentid like", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidNotLike(String value) {
            addCriterion("to_commentid not like", value, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidIn(List<String> values) {
            addCriterion("to_commentid in", values, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidNotIn(List<String> values) {
            addCriterion("to_commentid not in", values, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidBetween(String value1, String value2) {
            addCriterion("to_commentid between", value1, value2, "toCommentid");
            return (Criteria) this;
        }

        public Criteria andToCommentidNotBetween(String value1, String value2) {
            addCriterion("to_commentid not between", value1, value2, "toCommentid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}