package com.shenshenshen.ncwuwdsq.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shenshenshen.ncwuwdsq.constant.PushType;
import com.shenshenshen.ncwuwdsq.domain.ArticleComment;
import com.shenshenshen.ncwuwdsq.domain.ArticleCommentExample;
import com.shenshenshen.ncwuwdsq.domain.Articleinfo;
import com.shenshenshen.ncwuwdsq.domain.ArticleinfoExample;
import com.shenshenshen.ncwuwdsq.domain.Draftinfo;
import com.shenshenshen.ncwuwdsq.domain.DraftinfoExample;
import com.shenshenshen.ncwuwdsq.domain.Pushinfo;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgainstAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgreeAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.RecordUserLikeAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.mapper.ArticleCommentMapper;
import com.shenshenshen.ncwuwdsq.mapper.ArticleinfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.DraftinfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.RecordUserAgainstAnswerArticleMapper;
import com.shenshenshen.ncwuwdsq.mapper.RecordUserAgreeAnswerArticleMapper;
import com.shenshenshen.ncwuwdsq.mapper.RecordUserLikeAnswerArticleMapper;
import com.shenshenshen.ncwuwdsq.rabbitmq.RabbitMQSender;
import com.shenshenshen.ncwuwdsq.service.api.IArticleService;

/**
 * 文章业务接口实现类
 * 
 * @author 申中秋
 * @date 2019年4月19日上午10:38:58
 */
@Service
public class ArticleServiceImpl implements IArticleService {

	@Autowired
	private ArticleinfoMapper articleMapper;
	@Autowired
	private DraftinfoMapper draftMapper;
	@Autowired
	private RecordUserAgreeAnswerArticleMapper agreeArticleMapper;
	@Autowired
	private RecordUserAgainstAnswerArticleMapper againstArticleMapper;
	@Autowired
	private RecordUserLikeAnswerArticleMapper likeArticleMapper;
	@Autowired
	private ArticleCommentMapper commentMapper;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private RabbitMQSender mqSend;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void insert(Articleinfo articleinfo) {
		if (articleinfo.getIsDraft() == 1) {
			// 插入草稿记录
			Draftinfo draftinfo = new Draftinfo();
			draftinfo.setType(1);
			draftinfo.setCreatuser(articleinfo.getCreatuser());
			draftinfo.setMainid(articleinfo.getArticleid());
			draftinfo.setDraftid(UUID.randomUUID().toString());
			draftMapper.insert(draftinfo);
		}
		articleMapper.insert(articleinfo);
	}

	@Override
	public List<Articleinfo> getList(Integer start, Integer size) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.setOrderByClause(" hot desc limit " + start + "," + size);
		example.createCriteria().andIsDraftEqualTo(0);
		return articleMapper.selectByExampleWithBLOBs(example);
	}

	@Override
	public long count() {
		return articleMapper.countByExample(new ArticleinfoExample());
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void update(Articleinfo articleinfo) {
		// 若是发表文章就将草稿记录删除
		if (articleinfo.getIsDraft() == 0) {
			DraftinfoExample draftinfoExample = new DraftinfoExample();
			draftinfoExample.createCriteria().andMainidEqualTo(articleinfo.getArticleid());
			draftMapper.deleteByExample(draftinfoExample);
		}
		// 更新文章信息
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andArticleidEqualTo(articleinfo.getArticleid());
		articleMapper.updateByExampleWithBLOBs(articleinfo, example);

	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean zan(String articleid, Userinfo userinfo) {
		synchronized (this) {
			String sql = "select agreenum,hot,creatuser,title from articleinfo where articleid = ?";
			Map<String, Object> map = jdbcTemplate.queryForMap(sql, articleid);
			Articleinfo articleinfo = new Articleinfo();
			// 插入赞记录
			RecordUserAgreeAnswerArticle recordAgreeArticle = new RecordUserAgreeAnswerArticle();
			recordAgreeArticle.setAgreeUser(userinfo.getUsername());
			recordAgreeArticle.setRowguid(UUID.randomUUID().toString());
			recordAgreeArticle.setArticleid(articleid);
			recordAgreeArticle.setToUser((String) map.get("creatuser"));
			recordAgreeArticle.setDate(new Date());
			recordAgreeArticle.setType(1);
			agreeArticleMapper.insert(recordAgreeArticle);
			// 更新文章信息
			articleinfo.setAgreenum((Integer) map.get("agreenum") + 1);
			articleinfo.setHot((Integer) map.get("hot") + 5);
			ArticleinfoExample example = new ArticleinfoExample();
			example.createCriteria().andArticleidEqualTo(articleid);
			// 向作者推送提醒
			Pushinfo pushinfo = new Pushinfo();
			pushinfo.setFromUser(userinfo.getUsername());
			pushinfo.setToUser((String) map.get("creatuser"));
			pushinfo.setCreatdate(new Date());
			pushinfo.setIsReceived(0);
			pushinfo.setType(PushType.ZANARTICLE);
			pushinfo.setMainid(articleid);
			pushinfo.setPushid(UUID.randomUUID().toString());
			mqSend.sendZanArticleInfoNews(pushinfo, (String) map.get("title"));
			if (articleMapper.updateByExampleSelective(articleinfo, example) > 0) {
				return true;
			}
			return false;
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean cai(String articleid, Userinfo userinfo) {
		synchronized (this) {
			String sql = "select hatenum,hot,creatuser,title from articleinfo where articleid = ?";
			Map<String, Object> map = jdbcTemplate.queryForMap(sql, articleid);
			Articleinfo articleinfo = new Articleinfo();
			// 插入踩记录
			RecordUserAgainstAnswerArticle recordAgainstArticle = new RecordUserAgainstAnswerArticle();
			recordAgainstArticle.setAgainstUser(userinfo.getUsername());
			recordAgainstArticle.setRowguid(UUID.randomUUID().toString());
			recordAgainstArticle.setArticleid(articleid);
			recordAgainstArticle.setToUser((String) map.get("creatuser"));
			recordAgainstArticle.setDate(new Date());
			recordAgainstArticle.setType(1);
			againstArticleMapper.insert(recordAgainstArticle);
			// 更新文章信息
			articleinfo.setHatenum((Integer) map.get("hatenum") + 1);
			articleinfo.setHot((Integer) map.get("hot") + 3);
			ArticleinfoExample example = new ArticleinfoExample();
			example.createCriteria().andArticleidEqualTo(articleid);
			// 向作者推送提醒
			Pushinfo pushinfo = new Pushinfo();
			pushinfo.setFromUser(userinfo.getUsername());
			pushinfo.setToUser((String) map.get("creatuser"));
			pushinfo.setCreatdate(new Date());
			pushinfo.setIsReceived(0);
			pushinfo.setType(PushType.CAIARTICLE);
			pushinfo.setMainid(articleid);
			pushinfo.setPushid(UUID.randomUUID().toString());
			mqSend.sendCaiArticleInfoNews(pushinfo, (String) map.get("title"));
			if (articleMapper.updateByExampleSelective(articleinfo, example) > 0) {
				return true;
			}
			return false;
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean shoucang(String articleid, Userinfo userinfo) {
		synchronized (this) {
			String sql = "select likenum,hot,creatuser,title from articleinfo where articleid = ?";
			Map<String, Object> map = jdbcTemplate.queryForMap(sql, articleid);
			Articleinfo articleinfo = new Articleinfo();
			// 插入收藏记录
			RecordUserLikeAnswerArticle recordLikeArticle = new RecordUserLikeAnswerArticle();
			recordLikeArticle.setLikefromUser(userinfo.getUsername());
			recordLikeArticle.setRowguid(UUID.randomUUID().toString());
			recordLikeArticle.setArticleid(articleid);
			recordLikeArticle.setToUser((String) map.get("creatuser"));
			recordLikeArticle.setLikedate(new Date());
			recordLikeArticle.setType(1);
			likeArticleMapper.insert(recordLikeArticle);
			// 更新文章信息
			articleinfo.setLikenum((Integer) map.get("likenum") + 1);
			articleinfo.setHot((Integer) map.get("hot") + 7);
			ArticleinfoExample example = new ArticleinfoExample();
			example.createCriteria().andArticleidEqualTo(articleid);
			// 向作者推送提醒
			Pushinfo pushinfo = new Pushinfo();
			pushinfo.setFromUser(userinfo.getUsername());
			pushinfo.setToUser((String) map.get("creatuser"));
			pushinfo.setCreatdate(new Date());
			pushinfo.setIsReceived(0);
			pushinfo.setType(PushType.LIKEARTICLE);
			pushinfo.setMainid(articleid);
			pushinfo.setPushid(UUID.randomUUID().toString());
			mqSend.sendShoucangArticleInfoNews(pushinfo, (String) map.get("title"));
			if (articleMapper.updateByExampleSelective(articleinfo, example) > 0) {
				return true;
			}
			return false;
		}
	}

	@Override
	public List<Map<String, Object>> getArticleByUser(String username, Integer start, Integer size) {
		String sql = "select articleid,title,creatuser,creatdate from articleinfo where creatuser = ? and is_draft = 0 limit ?,?";
		return jdbcTemplate.queryForList(sql, new Object[] { username, start, size });

	}

	@Override
	public long countArticleByUname(String username) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andCreatuserEqualTo(username);
		return articleMapper.countByExample(example);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean addComment(ArticleComment comment, Userinfo onlineuser) {
		// 更新文章信息
		String sql = "select commentnum,hot,creatuser,title,articleid from articleinfo where articleid = ?";
		Map<String, Object> map = jdbcTemplate.queryForMap(sql, comment.getArticleguid());
		Articleinfo articleinfo = new Articleinfo();
		articleinfo.setCommentnum((Integer) map.get("commentnum") + 1);
		articleinfo.setHot((Integer) map.get("hot") + 10);
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andArticleidEqualTo(comment.getArticleguid());
		articleMapper.updateByExampleSelective(articleinfo, example);
		// 向作者推送提醒
		Pushinfo pushinfo = new Pushinfo();
		pushinfo.setFromUser(onlineuser.getUsername());
		pushinfo.setToUser((String) map.get("creatuser"));
		pushinfo.setCreatdate(new Date());
		pushinfo.setIsReceived(0);
		pushinfo.setType(PushType.COMMENTARTICLE);
		pushinfo.setMainid((String) map.get("articleid"));
		pushinfo.setPushid(UUID.randomUUID().toString());
		mqSend.sendCommentArticleInfoNews(pushinfo, (String) map.get("title"));
		// 插入评论
		if (commentMapper.insert(comment) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<ArticleComment> getComment(String articleid) {
		ArticleCommentExample example = new ArticleCommentExample();
		example.setOrderByClause(" creatdate desc");
		example.createCriteria().andArticleguidEqualTo(articleid);
		return commentMapper.selectByExample(example);
	}

	@Override
	public List<Articleinfo> searchArticle(Integer start, Integer size, String searchinfo) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.setOrderByClause(" hot desc limit " + start + "," + size);
		example.createCriteria().andIsDraftEqualTo(0).andTitleLike("%" + searchinfo + "%");
		return articleMapper.selectByExampleWithBLOBs(example);
	}

	@Override
	public long countSearch(String seachinfo) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andTitleLike(seachinfo);
		return articleMapper.countByExample(example);
	}

	@Override
	public ArticleComment getCommentByid(String commentid) {
		ArticleCommentExample example = new ArticleCommentExample();
		example.createCriteria().andRowguidEqualTo(commentid);
		List<ArticleComment> list = new ArrayList<>(4);
		list = commentMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public String getTitleByArticleId(String articleguid) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andArticleidEqualTo(articleguid);
		List<Articleinfo> list = new ArrayList<>(4);
		list = articleMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0).getTitle();
		}
		return null;
	}

	@Override
	public Articleinfo getArticleByid(String articleid) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andArticleidEqualTo(articleid);
		List<Articleinfo> list = new ArrayList<>(4);
		list = articleMapper.selectByExampleWithBLOBs(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
		
	}

	@Override
	public int aditArticle(Articleinfo articleinfo) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andArticleidEqualTo(articleinfo.getArticleid());
		return articleMapper.updateByExampleWithBLOBs(articleinfo, example);
	}

}
