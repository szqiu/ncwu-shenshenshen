package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Pushinfo;
import com.shenshenshen.ncwuwdsq.domain.PushinfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PushinfoMapper {
    int countByExample(PushinfoExample example);

    int deleteByExample(PushinfoExample example);

    int insert(Pushinfo record);

    int insertSelective(Pushinfo record);

    List<Pushinfo> selectByExample(PushinfoExample example);

    int updateByExampleSelective(@Param("record") Pushinfo record, @Param("example") PushinfoExample example);

    int updateByExample(@Param("record") Pushinfo record, @Param("example") PushinfoExample example);
}