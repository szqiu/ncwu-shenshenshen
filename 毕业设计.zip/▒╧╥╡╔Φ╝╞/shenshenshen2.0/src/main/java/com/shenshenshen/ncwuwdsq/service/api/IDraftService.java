package com.shenshenshen.ncwuwdsq.service.api;

import java.util.List;
import java.util.Map;

import com.shenshenshen.ncwuwdsq.domain.Articleinfo;

/**
 * 用户草稿业务接口
*@author 申中秋
*@date 2019年4月19日下午9:07:28
*/
public interface IDraftService {

	/**
	 * 获取用户草稿
	 * @param start
	 * @param size
	 * @param username
	 * @return
	 */
	List<Map<String, Object>> getDraftByUser(Integer start, Integer size, String username);

	/**
	 * 获取draft详请
	 * @param list
	 * @return
	 */
	List<Map<String, Object>> getDraftDetil(List<Map<String, Object>> list);

	/**
	 * 获取用户草稿总数
	 * @param username
	 * @return
	 */
	long count(String username);

	/**
	 * 根据id获取文章草稿
	 * @param articleid
	 * @return
	 */
	Articleinfo getArticleById(String articleid);
	
	
}
