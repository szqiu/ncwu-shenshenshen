package com.shenshenshen.ncwuwdsq.service.api;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.domain.Answerinfo;
import com.shenshenshen.ncwuwdsq.domain.Questioninfo;
import com.shenshenshen.ncwuwdsq.domain.Questiontype;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;

/**
 *类说明:问题与答案业务接口
 *@author 申中秋
 *@date 2019年3月15日 下午2:08:36
 *
 */
public interface IQuestionAndAnswerService {
	/**
	 * 新增问题
	 * @param question
	 */
	public void insert(Questioninfo questioninfo);
	
	/**
	 * 按时间获取问题跟优秀答案
	 * @param start
	 * @param size
	 * @return
	 */
	public List<Map<String, Object>> getAll(Integer start, Integer size);
	
	/**
	 * 计算问题总数，供分页使用
	 * @return
	 */
	public long countQuestion();
	
	/**
	 * 计算答案数
	 * @param qid
	 * @return
	 */
	public long countAnswerByQid(String qid);
	/**
	 * 根据id获取问题
	 * @param id
	 * @return
	 */
	public Questioninfo getQuestionById(String id);

	/**
	 * 添加答案
	 * @param answer
	 * @param questionid
	 * @param creatuser 
	 * @return
	 */
	public int addAnswer(Answerinfo answerinfo);

	/**
	 * 根据问题id获取所有答案
	 * @param questionid
	 * @param size 
	 * @param page 
	 * @return
	 */
	public List<Answerinfo> getAllAnswerByQuestionid(String questionid, Integer page, Integer size);

	

	

	/**
	 * 分页获取用户的提问
	 * @param username
	 * @param start
	 * @param size
	 * @return
	 */
	public List<Map<String, Object>> getQuestionByUser(String creatuser, Integer start, Integer size);
	/**
	 * 计算当前用户提问总数
	 * @param username
	 * @return
	 */
	public long countQuestionByUname(String username);

	/**
	 * 获取当前用户的回答
	 * @param username
	 * @param start
	 * @param size
	 * @return
	 */
	public List<Map<String, Object>> getAnswerByUser(String username, Integer start, Integer size);

	/**
	 * 计算当前用户答案
	 * @param username
	 * @return
	 */
	public long countAnswerByUname(String username);



	/**
	 * 获取所有问题分类
	 * @return
	 */
	public List<Questiontype> getType();

	/**
	 * 根据typecode获取type
	 * @param typecode
	 * @return
	 */
	public Questiontype getTypeText(String typecode);

	/**
	 * 根据typetext获取type
	 * @param typetext
	 * @return
	 */
	public Questiontype getTypeCode(String typetext);

	/**
	 * 更新redis最热问题与答案
	 * @return
	 */
	public List<Map<String, Object>> getHotQuestionAndAnswer();
	
	/**
	 * 获取最热问题
	 * @param start
	 * @param size
	 * @return
	 */
	public List<JSONObject> getHot(Integer start, Integer size);

	/**
	 * 根据id获取答案
	 * @param answerid
	 * @return
	 */
	public Map<String, Object> getAnswerById(String answerid);

	/**
	 * 更新答案
	 * @param answerinfo
	 * @return
	 */
	public int updateAnswer(Answerinfo answerinfo);

	/**
	 * 根据答案获取问题
	 * @param answerid
	 * @return
	 */
	public Questioninfo getQuestionByAnswerId(String answerid);

	/**
	 * 获取个性化问题
	 * @param start
	 * @param size
	 * @param onlineuser
	 * @return
	 */
	public List<Map<String, Object>> getPersonly(Integer start, Integer size, Userinfo onlineuser);

	/**
	 * 计算个性化推荐问题数目
	 * @param onlineuser
	 * @return
	 */
	long countQuestionPersonly(Userinfo onlineuser);

	/**
	 * 按照题目搜索
	 * @param start
	 * @param size
	 * @param searchinfo
	 * @return
	 */
	public List<Map<String, Object>> searchQuestion(Integer start, Integer size, String searchinfo);

	/**
	 * 计算搜索结果数目
	 * @param searchinfo
	 * @return
	 */
	public long countQuestionSearch(String searchinfo);

	/**
	 * 根据answerid获取answer
	 * @param answerid
	 * @return
	 */
	public Answerinfo getAnswerByAid(String answerid);

	/**
	 * 修改答案
	 * @param answerinfo
	 * @return
	 */
	public int eidtAnswer(Answerinfo answerinfo);

	

		
}
