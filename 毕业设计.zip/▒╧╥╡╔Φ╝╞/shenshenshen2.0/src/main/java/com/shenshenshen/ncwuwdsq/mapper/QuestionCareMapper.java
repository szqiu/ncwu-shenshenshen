package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.QuestionCare;
import com.shenshenshen.ncwuwdsq.domain.QuestionCareExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface QuestionCareMapper {
    int countByExample(QuestionCareExample example);

    int deleteByExample(QuestionCareExample example);

    int insert(QuestionCare record);

    int insertSelective(QuestionCare record);

    List<QuestionCare> selectByExample(QuestionCareExample example);

    int updateByExampleSelective(@Param("record") QuestionCare record, @Param("example") QuestionCareExample example);

    int updateByExample(@Param("record") QuestionCare record, @Param("example") QuestionCareExample example);
}