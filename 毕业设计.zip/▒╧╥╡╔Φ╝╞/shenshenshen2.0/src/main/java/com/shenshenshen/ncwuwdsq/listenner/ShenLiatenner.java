package com.shenshenshen.ncwuwdsq.listenner;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;

/**
*@author 申中秋
*@date 2019年4月27日下午7:25:17
*/
@WebListener
public class ShenLiatenner implements ServletContextListener{
	@Autowired
	private StringRedisTemplate redisTemplate;
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		
		
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		// 启动时清空在线用户信息
		redisTemplate.delete(redisTemplate.keys("online_*"));
	}

}
