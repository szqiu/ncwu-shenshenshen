package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.RecordUserLikeAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.RecordUserLikeAnswerArticleExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RecordUserLikeAnswerArticleMapper {
    int countByExample(RecordUserLikeAnswerArticleExample example);

    int deleteByExample(RecordUserLikeAnswerArticleExample example);

    int deleteByPrimaryKey(String rowguid);

    int insert(RecordUserLikeAnswerArticle record);

    int insertSelective(RecordUserLikeAnswerArticle record);

    List<RecordUserLikeAnswerArticle> selectByExample(RecordUserLikeAnswerArticleExample example);

    RecordUserLikeAnswerArticle selectByPrimaryKey(String rowguid);

    int updateByExampleSelective(@Param("record") RecordUserLikeAnswerArticle record, @Param("example") RecordUserLikeAnswerArticleExample example);

    int updateByExample(@Param("record") RecordUserLikeAnswerArticle record, @Param("example") RecordUserLikeAnswerArticleExample example);

    int updateByPrimaryKeySelective(RecordUserLikeAnswerArticle record);

    int updateByPrimaryKey(RecordUserLikeAnswerArticle record);
}