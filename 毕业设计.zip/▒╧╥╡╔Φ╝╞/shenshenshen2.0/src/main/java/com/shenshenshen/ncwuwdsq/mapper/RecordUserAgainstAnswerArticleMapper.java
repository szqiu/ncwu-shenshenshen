package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.RecordUserAgainstAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgainstAnswerArticleExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RecordUserAgainstAnswerArticleMapper {
    int countByExample(RecordUserAgainstAnswerArticleExample example);

    int deleteByExample(RecordUserAgainstAnswerArticleExample example);

    int insert(RecordUserAgainstAnswerArticle record);

    int insertSelective(RecordUserAgainstAnswerArticle record);

    List<RecordUserAgainstAnswerArticle> selectByExample(RecordUserAgainstAnswerArticleExample example);

    int updateByExampleSelective(@Param("record") RecordUserAgainstAnswerArticle record, @Param("example") RecordUserAgainstAnswerArticleExample example);

    int updateByExample(@Param("record") RecordUserAgainstAnswerArticle record, @Param("example") RecordUserAgainstAnswerArticleExample example);
}