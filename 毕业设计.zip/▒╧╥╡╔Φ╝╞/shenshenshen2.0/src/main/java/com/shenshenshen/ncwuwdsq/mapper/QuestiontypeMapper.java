package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Questiontype;
import com.shenshenshen.ncwuwdsq.domain.QuestiontypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface QuestiontypeMapper {
    int countByExample(QuestiontypeExample example);

    int deleteByExample(QuestiontypeExample example);

    int deleteByPrimaryKey(Integer typecode);

    int insert(Questiontype record);

    int insertSelective(Questiontype record);

    List<Questiontype> selectByExample(QuestiontypeExample example);

    Questiontype selectByPrimaryKey(Integer typecode);

    int updateByExampleSelective(@Param("record") Questiontype record, @Param("example") QuestiontypeExample example);

    int updateByExample(@Param("record") Questiontype record, @Param("example") QuestiontypeExample example);

    int updateByPrimaryKeySelective(Questiontype record);

    int updateByPrimaryKey(Questiontype record);
}