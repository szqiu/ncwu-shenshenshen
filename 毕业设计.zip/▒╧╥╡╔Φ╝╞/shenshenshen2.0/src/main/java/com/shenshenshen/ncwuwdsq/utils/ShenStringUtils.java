package com.shenshenshen.ncwuwdsq.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 工具类
*@author 申中秋
*@date 2019年3月25日上午9:56:42
*/
public class ShenStringUtils {
	
	// 判断字符串是否为空
	public static boolean isBlank(String str) {
		if ("".equals(str) || str == null) {
			return true;
		}
		
		return false;
	}	
	public static boolean isNotBlank(String str) {
		return !isBlank(str);
	}
	
	// 格式化日期
	public static String dateToString(String format, Date date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);		
		return simpleDateFormat.format(date);
	}
	public static void main(String[] args) {
		System.out.println(dateToString("yyyy-MM-dd HH-mm-ss", new Date()));
	}
	
	// 将时间戳转化为时间
	
}
