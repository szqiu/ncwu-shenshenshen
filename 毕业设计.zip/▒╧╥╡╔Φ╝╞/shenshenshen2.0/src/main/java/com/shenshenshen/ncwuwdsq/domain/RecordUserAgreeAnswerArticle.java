package com.shenshenshen.ncwuwdsq.domain;

import java.util.Date;

public class RecordUserAgreeAnswerArticle {
    private String rowguid;

    private String agreeUser;

    private String answerid;

    private Date date;

    private String toUser;

    private Integer type;

    private String articleid;

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid == null ? null : rowguid.trim();
    }

    public String getAgreeUser() {
        return agreeUser;
    }

    public void setAgreeUser(String agreeUser) {
        this.agreeUser = agreeUser == null ? null : agreeUser.trim();
    }

    public String getAnswerid() {
        return answerid;
    }

    public void setAnswerid(String answerid) {
        this.answerid = answerid == null ? null : answerid.trim();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getToUser() {
        return toUser;
    }

    public void setToUser(String toUser) {
        this.toUser = toUser == null ? null : toUser.trim();
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getArticleid() {
        return articleid;
    }

    public void setArticleid(String articleid) {
        this.articleid = articleid == null ? null : articleid.trim();
    }
}