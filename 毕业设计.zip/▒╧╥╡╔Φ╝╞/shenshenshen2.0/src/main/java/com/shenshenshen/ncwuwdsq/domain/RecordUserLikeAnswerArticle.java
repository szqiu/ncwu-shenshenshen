package com.shenshenshen.ncwuwdsq.domain;

import java.util.Date;

public class RecordUserLikeAnswerArticle {
    private String rowguid;

    private String answerid;

    private String likefromUser;

    private Date likedate;

    private String toUser;

    private Integer type;

    private String articleid;

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid == null ? null : rowguid.trim();
    }

    public String getAnswerid() {
        return answerid;
    }

    public void setAnswerid(String answerid) {
        this.answerid = answerid == null ? null : answerid.trim();
    }

    public String getLikefromUser() {
        return likefromUser;
    }

    public void setLikefromUser(String likefromUser) {
        this.likefromUser = likefromUser == null ? null : likefromUser.trim();
    }

    public Date getLikedate() {
        return likedate;
    }

    public void setLikedate(Date likedate) {
        this.likedate = likedate;
    }

    public String getToUser() {
        return toUser;
    }

    public void setToUser(String toUser) {
        this.toUser = toUser == null ? null : toUser.trim();
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getArticleid() {
        return articleid;
    }

    public void setArticleid(String articleid) {
        this.articleid = articleid == null ? null : articleid.trim();
    }
}