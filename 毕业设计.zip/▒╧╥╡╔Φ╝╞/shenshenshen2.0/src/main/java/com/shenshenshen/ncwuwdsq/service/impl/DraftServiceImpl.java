package com.shenshenshen.ncwuwdsq.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.shenshenshen.ncwuwdsq.domain.Articleinfo;
import com.shenshenshen.ncwuwdsq.domain.ArticleinfoExample;
import com.shenshenshen.ncwuwdsq.domain.DraftinfoExample;
import com.shenshenshen.ncwuwdsq.mapper.ArticleinfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.DraftinfoMapper;
import com.shenshenshen.ncwuwdsq.service.api.IDraftService;
import com.shenshenshen.ncwuwdsq.utils.ShenStringUtils;

/**
 * 用户草稿业务实现类
*@author 申中秋
*@date 2019年4月19日下午9:07:56
*/
@Service
public class DraftServiceImpl implements IDraftService{

	@Autowired
	private DraftinfoMapper draftMapper;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private ArticleinfoMapper articleMapper;
	
	@Override
	public List<Map<String, Object>> getDraftByUser(Integer start, Integer size, String username) {
		String sql = "select * from draftinfo"
				+ " where creatuser = ? limit ?,?";
		return jdbcTemplate.queryForList(sql, new Object[]{username,start,size});
	}

	@Override
	public List<Map<String, Object>> getDraftDetil(List<Map<String, Object>> list) {
		List<Map<String, Object>> draftlist = new ArrayList<>(16);
		for (Map<String, Object> draftinfo : list) {
			Map<String, Object> map = new HashMap<>(8);
			// 若为答案草稿
			if ((Integer)draftinfo.get("type") == 0) {
				String sql = "select a.creatdate,b.contant from answerinfo a "
						+ " left join questioninfo b on a.questionid = b.questionid "
						+ " where a.answerid = ?";
				map = jdbcTemplate.queryForMap(sql, draftinfo.get("mainid"));
				map.put("type", 0);
				System.out.println(map);
			}
			// 若为文章草稿
			if ((Integer)draftinfo.get("type") == 1) {
				String sql = "select creatdate, title from articleinfo where articleid = ?";
				map = jdbcTemplate.queryForMap(sql, draftinfo.get("mainid"));
				map.put("type", 1);
			}
			map.put("mainid",draftinfo.get("mainid"));
			// 格式化日期
			map.put("creatdate", ShenStringUtils.dateToString("yyyy年MM月dd日 HH时mm分ss秒", (Date)map.get("creatdate")));
			draftlist.add(map);
		}
		return draftlist;
	}

	@Override
	public long count(String username) {
		DraftinfoExample example = new DraftinfoExample();
		example.createCriteria().andCreatuserEqualTo(username);
		return draftMapper.countByExample(example);
	}

	@Override
	public Articleinfo getArticleById(String articleid) {
		ArticleinfoExample example = new ArticleinfoExample();
		example.createCriteria().andArticleidEqualTo(articleid);
		List<Articleinfo> list = articleMapper.selectByExampleWithBLOBs(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}
	
}
