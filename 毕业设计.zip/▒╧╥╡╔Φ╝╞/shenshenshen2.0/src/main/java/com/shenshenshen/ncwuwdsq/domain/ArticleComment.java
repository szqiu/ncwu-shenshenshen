package com.shenshenshen.ncwuwdsq.domain;

import java.util.Date;

public class ArticleComment {
    private String rowguid;

    private String creatuser;

    private Date creatdate;

    private String articleguid;

    private String contant;

    private String toCommentid;

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid == null ? null : rowguid.trim();
    }

    public String getCreatuser() {
        return creatuser;
    }

    public void setCreatuser(String creatuser) {
        this.creatuser = creatuser == null ? null : creatuser.trim();
    }

    public Date getCreatdate() {
        return creatdate;
    }

    public void setCreatdate(Date creatdate) {
        this.creatdate = creatdate;
    }

    public String getArticleguid() {
        return articleguid;
    }

    public void setArticleguid(String articleguid) {
        this.articleguid = articleguid == null ? null : articleguid.trim();
    }

    public String getContant() {
        return contant;
    }

    public void setContant(String contant) {
        this.contant = contant == null ? null : contant.trim();
    }

    public String getToCommentid() {
        return toCommentid;
    }

    public void setToCommentid(String toCommentid) {
        this.toCommentid = toCommentid == null ? null : toCommentid.trim();
    }
}