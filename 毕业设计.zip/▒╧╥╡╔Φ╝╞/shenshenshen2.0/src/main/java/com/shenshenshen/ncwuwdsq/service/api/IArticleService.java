package com.shenshenshen.ncwuwdsq.service.api;

import java.util.List;
import java.util.Map;

import com.shenshenshen.ncwuwdsq.domain.ArticleComment;
import com.shenshenshen.ncwuwdsq.domain.Articleinfo;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;

/**
 * 文章业务接口
*@author 申中秋
*@date 2019年4月19日上午10:38:16
*/
public interface IArticleService {

	/**
	 * 新增文章
	 * @param articleinfo
	 */
	public void insert(Articleinfo articleinfo);

	/**
	 * 分页获取文章
	 * @param size 
	 * @param start 
	 * @return
	 */
	public List<Articleinfo> getList(Integer start, Integer size);

	/**
	 * 计算文章总数
	 * @return
	 */
	public long count();

	/**
	 * 更新
	 * @param articleinfo
	 */
	public void update(Articleinfo articleinfo);

	/**
	 * 赞
	 * @param articleid
	 * @param userinfo
	 * @return
	 */
	public boolean zan(String articleid,Userinfo userinfo);
	/**
	 * 踩
	 * @param articleid
	 * @param userinfo
	 * @return
	 */
	public boolean cai(String articleid,Userinfo userinfo);

	/**
	 * 收藏
	 * @param articleid
	 * @param userinfo
	 * @return
	 */
	public boolean shoucang(String articleid,Userinfo userinfo);

	/**
	 * 获取用户已发表文章记录
	 * @param username
	 * @param start
	 * @param size
	 * @return
	 */
	public List<Map<String, Object>> getArticleByUser(String username, Integer start, Integer size);

	/**
	 * 计算以发表文章总数
	 * @param username
	 * @return
	 */
	public long countArticleByUname(String username);

	/**
	 * 添加文章评论
	 * @param comment
	 * @param onlineuser
	 * @return
	 */
	public boolean addComment(ArticleComment comment, Userinfo onlineuser);

	/**
	 * 获取文章评论
	 * @param articleid
	 * @return
	 */
	public List<ArticleComment> getComment(String articleid);

	/**
	 * 搜索文章
	 * @param start
	 * @param size
	 * @param searchinfo
	 * @return
	 */
	public List<Articleinfo> searchArticle(Integer start, Integer size, String searchinfo);

	/**
	 * 计算搜索结果数目
	 * @param searchinfo
	 * @return
	 */
	public long countSearch(String searchinfo);

	/**
	 * 根据id获取评论
	 * @param commentid
	 * @return
	 */
	public ArticleComment getCommentByid(String commentid);

	/**
	 * 根据id获取文章标题
	 * @param articleguid
	 * @return
	 */
	public String getTitleByArticleId(String articleguid);

	/**
	 * 根据id获取文章
	 * @param articleid
	 * @return
	 */
	public Articleinfo getArticleByid(String articleid);

	/**
	 * 修改文章
	 * @param articleinfo
	 * @return
	 */
	public int aditArticle(Articleinfo articleinfo);

}
