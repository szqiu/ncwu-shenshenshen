package com.shenshenshen.ncwuwdsq.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.shenshenshen.ncwuwdsq.interceptor.LoginInterceptor;

/**
*@author 申中秋
*@date 2019年3月26日下午3:44:29
*/
@Configuration
public class MyConfig implements WebMvcConfigurer{
	/**
	 * 自定义图片虚拟路径
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/upload/**")
		.addResourceLocations("file:D:/images/");
		
	}

	/**
	 * 注册登录拦截器
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		// 注册拦截器
		InterceptorRegistration registration = registry.addInterceptor(new LoginInterceptor());
		registration.addPathPatterns("/**");
		// 配置不需要拦截的
		registration.excludePathPatterns("/login.html","/login/**","/layui-master/**","/user/login",
				"/upload/**","/register.html","/user/register","/user/regist/**");
	}
	
	
}
