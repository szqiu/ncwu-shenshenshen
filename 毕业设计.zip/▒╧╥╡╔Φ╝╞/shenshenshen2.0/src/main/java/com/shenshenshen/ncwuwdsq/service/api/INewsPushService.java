package com.shenshenshen.ncwuwdsq.service.api;

import java.util.List;

import com.shenshenshen.ncwuwdsq.domain.Pushinfo;

/**
 * 服务器新消息推送
*@author 申中秋
*@date 2019年4月9日下午7:38:21
*/
public interface INewsPushService {

	/**
	 * 新增推送
	 * @param pushinfo
	 */
	void addPush(Pushinfo pushinfo);

	/**
	 * 回去用户最近消息
	 * @param username
	 * @return
	 */
	List<Pushinfo> getRecentlyNews(String username);

	/**
	 * 获取用户与我相关数
	 * @param username
	 * @return
	 */
	long countByUname(String username);

	/**
	 * 获取用户的与我相关信息
	 * @param size 
	 * @param start 
	 * @param username
	 * @return
	 */
	List<Pushinfo> getPushinfoByUser(Integer start, Integer size, String username);

	/**
	 * 计算历史与我相关数
	 * @param username
	 * @return
	 */
	long countOldByUname(String username);

	/**
	 * 获取与我相关历史信息
	 * @param start
	 * @param size
	 * @param username
	 * @return
	 */
	List<Pushinfo> getPushOldinfoByUser(Integer start, Integer size, String username);

	/**
	 * 计算我的私信数
	 * @param username
	 * @return
	 */
	long countLetter(String username);

	/**
	 * 已读消息
	 * @param pushid
	 * @return
	 */
	boolean readNew(String pushid);
	
	
}
