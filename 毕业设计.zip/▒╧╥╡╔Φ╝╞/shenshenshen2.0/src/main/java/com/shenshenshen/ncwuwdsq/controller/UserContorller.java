package com.shenshenshen.ncwuwdsq.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.constant.PushType;
import com.shenshenshen.ncwuwdsq.domain.Letter;
import com.shenshenshen.ncwuwdsq.domain.Pushinfo;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.rabbitmq.RabbitMQSender;
import com.shenshenshen.ncwuwdsq.service.api.IAgreeAndAgainstService;
import com.shenshenshen.ncwuwdsq.service.api.IArticleService;
import com.shenshenshen.ncwuwdsq.service.api.IDraftService;
import com.shenshenshen.ncwuwdsq.service.api.INewsPushService;
import com.shenshenshen.ncwuwdsq.service.api.IQuestionAndAnswerService;
import com.shenshenshen.ncwuwdsq.service.api.IUserService;
import com.shenshenshen.ncwuwdsq.utils.ShenStringUtils;

/**
 * 用户controller
 * 
 * @author 申中秋
 * @date 2019年3月25日下午5:11:50
 */
@RestController
@RequestMapping(value = "/user")
public class UserContorller {

	@Autowired
	private IUserService userService;
	@Autowired
	private IQuestionAndAnswerService questionAndAnswerService;
	@Autowired
	private IAgreeAndAgainstService agreeService;
	@Autowired
	private IArticleService articleService;
	@Autowired
	private IDraftService draftService;
	@Autowired
	private INewsPushService pushService;
	@Autowired
	private RabbitMQSender mqSender;
	/**
	 * 用户注册接口
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registUser(@RequestBody String params, HttpServletRequest request) {
		// 接收注册数据
		String username = request.getParameter("username");
		String mail = request.getParameter("mail");
		String phone = request.getParameter("phone");
		String loginid = request.getParameter("loginid");
		String password = request.getParameter("password");
		String confirm = request.getParameter("confirm");
		if (ShenStringUtils.isNotBlank(password) && password.equals(confirm) && userService.confirmLoginid(loginid) && userService.confirmUsername(username)) {
			Userinfo userinfo = new Userinfo();
			userinfo.setUsername(username);
			userinfo.setPassword(password);
			userinfo.setLoginid(loginid);
			userinfo.setMail(mail);
			userinfo.setPhone(phone);
			if (userService.registUser(userinfo)) {
				return "注册成功！";
			}
		}
		return "请检查填写内容";
	}

	/**
	 * 用户登录接口
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String userLogin(@RequestBody String params, HttpServletRequest request) {
		HttpSession session = request.getSession();
		String loginid = request.getParameter("loginid");
		String password = request.getParameter("password");
		Userinfo userinfo = new Userinfo();
		userinfo.setLoginid(loginid);
		userinfo.setPassword(password);
		Userinfo onlineuser = userService.login(userinfo);
		if (onlineuser != null) {
			session.setAttribute("user", onlineuser);
			
			return "200";
		}
		return "100";
	}

	/**
	 * 获取服务器消息推送pid
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getsid", method = RequestMethod.POST)
	public String test(HttpServletRequest request) {
		System.out.println("hello");
		Userinfo user = (Userinfo) request.getSession().getAttribute("user");
		return user.getUsername();
	}

	/**
	 * 验证用户名接口
	 * 
	 * @param username
	 * @return
	 */
	@RequestMapping(value = "/regist/confirm_username", method = RequestMethod.POST)
	public String conformUsername(@RequestParam String username) {
		// 验证
		if (userService.confirmUsername(username)) {
			return "200";
		}
		return "100";
	}

	/**
	 * 验证登录名接口
	 * 
	 * @param loginid
	 * @return
	 */
	@RequestMapping(value = "/regist/confirm_loginid", method = RequestMethod.POST)
	public String confirmLoginid(@RequestParam String loginid) {
		if (userService.confirmLoginid(loginid)) {
			return "200";
		}
		return "100";
	}

	/**
	 * 用户登出接口
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(value = "/loginout", method = RequestMethod.GET)
	public void loginOut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		Userinfo userinfo = (Userinfo) session.getAttribute("user");
		if (userService.loginOut(userinfo)) {
			session.removeAttribute("user");
			response.sendRedirect("/shenshenshen/login.html");
		}
	}

	/**
	 * 获取用户的提问
	 * 
	 * @param questionid
	 * @return
	 */
	@RequestMapping(value = "/getquestion", method = RequestMethod.POST)
	public String getQuestion(@RequestParam Integer page, Integer size, String username, HttpServletRequest request) {
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		HttpSession session = request.getSession();
		// 如果昵称为空，则查找当前用户的信息
		Userinfo user = new Userinfo();
		if (ShenStringUtils.isBlank(username)) {
			user = (Userinfo) session.getAttribute("user");
		} else {
			user = userService.getUserByUname(username);
			if (user.getShownews() != null && user.getShownews() == 0) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("list", new ArrayList<>());
				jsonObject.put("pages", 0);
				jsonObject.put("show", 0);
				return jsonObject.toString();
			}
		}

		List<Map<String, Object>> list = questionAndAnswerService.getQuestionByUser(user.getUsername(), start, size);
		for (Map<String, Object> map : list) {
			map.put("creatdate", ShenStringUtils.dateToString("yyyy-MM-dd HH:mm:ss", (Date) map.get("creatdate")));
		}
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		// 计算总页数
		long count = questionAndAnswerService.countQuestionByUname(user.getUsername());
		long pages = count % size == 0 ? count / size : count / size + 1;
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}

	/**
	 * 获取用户的答案记录
	 * 
	 * @param questionid
	 * @return
	 */
	@RequestMapping(value = "/getanswer", method = RequestMethod.POST)
	public String getAnswer(@RequestParam Integer page, Integer size, String username, HttpServletRequest request) {
		
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		HttpSession session = request.getSession();
		// 如果昵称为空，则查找当前用户的信息
		Userinfo user = new Userinfo();
		if (ShenStringUtils.isBlank(username)) {
			user = (Userinfo) session.getAttribute("user");
		} else {
			user.setUsername(username);
		}
		List<Map<String, Object>> list = questionAndAnswerService.getAnswerByUser(user.getUsername(), start, size);
		for (Map<String, Object> map : list) {
			map.put("creatdate", ShenStringUtils.dateToString("yyyy-MM-dd HH:mm:ss", (Date) map.get("creatdate")));
		}

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		// 计算总页数
		long count = questionAndAnswerService.countAnswerByUname(user.getUsername());
		long pages = count % size == 0 ? count / size : count / size + 1;
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	/**
	 * 获取用户赞同记录
	 * 
	 * @param page
	 * @param size
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getagree", method = RequestMethod.POST)
	public String userAgree(@RequestParam Integer page, Integer size, String username, HttpServletRequest request) {

		// 计算当前分页索引
		Integer start = (page - 1) * size;
		HttpSession session = request.getSession();
		// 如果昵称为空，则查找当前用户的信息
		Userinfo user = new Userinfo();	
		if (ShenStringUtils.isBlank(username)) {
			user = (Userinfo) session.getAttribute("user");
		} else {
			user = userService.getUserByUname(username);
		}
		List<Map<String, Object>> list = agreeService.getAgreeRecordByUid(user.getUsername(), start, size);
		for (Map<String, Object> map : list) {
			map.put("date", ShenStringUtils.dateToString("yyyy-MM-dd HH:mm:ss", (Date) map.get("date")));
		}
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		// 计算总页数
		long count = agreeService.countAgreeByUid(user.getUsername());
		long pages = count % size == 0 ? count / size : count / size + 1;
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	
	/**
	 * 获取用户反对记录
	 * @param page
	 * @param size
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getagainst", method = RequestMethod.POST)
	public String userAgainst(@RequestParam Integer page, Integer size, String username, HttpServletRequest request) {

		// 计算当前分页索引
		Integer start = (page - 1) * size;
		HttpSession session = request.getSession();
		// 如果昵称为空，则查找当前用户的信息
		Userinfo user = new Userinfo();
		
		if (ShenStringUtils.isBlank(username)) {
			user = (Userinfo) session.getAttribute("user");
		} else {
			user = userService.getUserByUname(username);
		}
		List<Map<String, Object>> list = agreeService.getAgainstRecordByUid(user.getUsername(), start, size);
		for (Map<String, Object> map : list) {
			map.put("date", ShenStringUtils.dateToString("yyyy-MM-dd HH:mm:ss", (Date) map.get("date")));
		}
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		// 计算总页数
		long count = agreeService.countAgainstByUid(user.getUsername());
		long pages = count % size == 0 ? count / size : count / size + 1;
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	
	/**
	 * 关注用户接口
	 * @param username
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/careuser", method = RequestMethod.POST)
	public String careFor(@RequestParam  String username, HttpServletRequest request){
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		Userinfo becaredUser = userService.getUserByUname(username);
		if(userService.careForUser(onlineuser,becaredUser)) {
			return "200";
		}
		return "100";
	}	
	/**
	 * 取消关注接口
	 * @param username
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/notcareuser", method = RequestMethod.POST)
	public String notCareFor(@RequestParam String username, HttpServletRequest request){
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		Userinfo becaredUser = userService.getUserByUname(username);
		if(userService.notCareForUser(onlineuser,becaredUser)) {
			return "200";
		}
		return "100";
	}
	
	/**
	 * 判断该用户是否已关注
	 * @param username
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/iscarefor", method = RequestMethod.POST)
	public String isCareFor(@RequestParam  String username, HttpServletRequest request) {
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		Userinfo becaredUser = userService.getUserByUname(username);
		if(userService.isCareFor(onlineuser,becaredUser)) {
			return "200";
		}
		return "100";
	}
	
	/**
	 * 获取用户信息
	 * @param username
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getuserinfo", method = RequestMethod.POST)
	public String getUserInfo(@RequestParam String username, HttpServletRequest request) {
		// 判断查找的是当前登录用户还是其他用户
		Userinfo user = null;
		Map<String, Object> map = new HashMap<>(2);
		if (ShenStringUtils.isBlank(username)) {
			user = (Userinfo) request.getSession().getAttribute("user");
		} else {
			user = userService.getUserByUname(username);
		}
		// 获取该用户获得的总赞同数
		long agreeNum = agreeService.countUserAgree(user.getUsername()); 
		// 封装返回数据
		map.put("username", user.getUsername());
		if (user.getSex() == null) {
			map.put("sex", "尚未设置");
		} else if (user.getSex() == 1) {
			map.put("sex", "男");
		} else {
			map.put("sex", "女");
		}
		if (user.getSign() == null) {
			map.put("sign", "这个人很赖，什么都没写");
		} else {
			map.put("sign", user.getSign());
		}
		if (user.getQq() == null) {
			map.put("qq", "尚未设置");
		} else {
			map.put("qq", user.getQq());
		}
		if (user.getPhone() == null) {
			map.put("phone", "尚未设置");
		} else {
			map.put("phone", user.getPhone());
		}
		map.put("agreenum", agreeNum);
		map.put("mail", user.getMail());
		map.put("agreenum", agreeNum);
		List<Map<String, Object>> list = new ArrayList<>();
		list.add(map);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		return jsonObject.toString();
	}
	/**
	 * 获取用户信息
	 * @param username
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getedituser", method = RequestMethod.POST)
	public String getEditUser(HttpServletRequest request) {
		Userinfo user = (Userinfo) request.getSession().getAttribute("user");
		JSONObject jsonObject = (JSONObject) JSON.toJSON(user);
		return jsonObject.toString();
	}
	/**
	 * 修改用户信息
	 * @param infodata
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/edituserinfo", method = RequestMethod.POST)
	public String editUserInfo(@RequestParam String infodata, HttpServletRequest request) {
		JSONObject newinfo = JSONObject.parseObject(infodata);
		System.out.println(newinfo.toString());
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		// 封装新用户信息
		onlineuser.setQq(newinfo.getString("qq"));
		onlineuser.setLiketype(newinfo.getString("liketype"));
		onlineuser.setMail(newinfo.getString("mail"));
		onlineuser.setPhone(newinfo.getString("phone"));
		onlineuser.setSex(newinfo.getInteger("sex"));
		if ("on".equals(newinfo.getString("switch"))) {
			onlineuser.setShownews(1);
		} else {
			onlineuser.setShownews(0);
		}
		onlineuser.setSign(newinfo.getString("sign"));
		// 更新用户信息
		if (userService.updateUserInfo(onlineuser)) {
			return "200";
		}
		return "100";
	}
	/**
	 * 获取用户已发表文章记录
	 * 
	 * @param questionid
	 * @return
	 */
	@RequestMapping(value = "/getarticle", method = RequestMethod.POST)
	public String getArticle(@RequestParam Integer page, Integer size, String username, HttpServletRequest request) {
		
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		HttpSession session = request.getSession();
		// 如果昵称为空，则查找当前用户的信息
		Userinfo user = new Userinfo();
		if (ShenStringUtils.isBlank(username)) {
			user = (Userinfo) session.getAttribute("user");
		} else {
			user.setUsername(username);
		}
		List<Map<String, Object>> list = articleService.getArticleByUser(user.getUsername(), start, size);
		for (Map<String, Object> map : list) {
			map.put("creatdate", ShenStringUtils.dateToString("yyyy-MM-dd HH:mm:ss", (Date) map.get("creatdate")));
		}

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		// 计算总页数
		long count = articleService.countArticleByUname(user.getUsername());
		long pages = count % size == 0 ? count / size : count / size + 1;
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	/**
	 * 获取用户草稿记录
	 * @param page
	 * @param size
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/draft", method = RequestMethod.POST)
	public String getDraft(@RequestParam Integer page, Integer size, HttpServletRequest request) {
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		Userinfo onlineuser = (Userinfo)request.getSession().getAttribute("user");
		List<Map<String, Object>> list = draftService.getDraftByUser(start, size,onlineuser.getUsername());
		JSONObject jsonObject = new JSONObject();
		long pages = 0;
		if (list != null && list.size() > 0) {
			List<Map<String, Object>> maps = draftService.getDraftDetil(list);
			// 计算总页数
			long count = draftService.count(onlineuser.getUsername());
			pages = (count % size == 0 ? count / size : count / size + 1);
			
			jsonObject.put("list", maps);
		}
	
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	
	/**
	 * 获取用户的最近消息
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/recentlynews", method = RequestMethod.POST)
	public String recentlyNews(HttpServletRequest request) {
		Userinfo onlineuser =(Userinfo) request.getSession().getAttribute("user");
		List<Pushinfo> list = pushService.getRecentlyNews(onlineuser.getUsername());
		if (list != null && list.size() > 0) {
			String jsonObject = JSON.toJSONString(list);
			return jsonObject;
		}
		return null;
	}
	
	/**
	 * 获取用户与我相关数
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/aboutme_num", method = RequestMethod.POST)
	public String aboutmeNum(HttpServletRequest request) {
		Userinfo onlineuser =(Userinfo) request.getSession().getAttribute("user");
		Long count = pushService.countByUname(onlineuser.getUsername());
		return count.toString();
	}
	
	/**
	 * 获取用户与我相关信息
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/aboutme", method = RequestMethod.POST)
	public String aboutme(@RequestParam Integer page, Integer size, HttpServletRequest request) {
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		Userinfo onlineuser =(Userinfo) request.getSession().getAttribute("user");
		List<Pushinfo> list = pushService.getPushinfoByUser(start, size, onlineuser.getUsername());
		long count = pushService.countByUname(onlineuser.getUsername());
		long pages = (count % size == 0 ? count / size : count / size + 1);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		jsonObject.put("pages", pages);
		jsonObject.put("count", count);
		return jsonObject.toString();
	}
	
	/**
	 * 获取用户与我相关历史信息
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/aboutme_old", method = RequestMethod.POST)
	public String aboutmeOld(@RequestParam Integer page, Integer size, HttpServletRequest request) {
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		Userinfo onlineuser =(Userinfo) request.getSession().getAttribute("user");
		List<Pushinfo> list = pushService.getPushOldinfoByUser(start, size, onlineuser.getUsername());
		long count = pushService.countOldByUname(onlineuser.getUsername());
		long pages = (count % size == 0 ? count / size : count / size + 1);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	
	/**
	 * 发送私信
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/writeletter", method = RequestMethod.POST)
	public String writeLetter(@RequestParam String content, String username, HttpServletRequest request) {
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		Letter letter = new Letter();
		letter.setRowguid(UUID.randomUUID().toString());
		letter.setContent(content);
		letter.setCreatdate(new Date());
		letter.setFromUser(onlineuser.getUsername());
		letter.setToUser(username);
		letter.setIsBack(0);
		if (userService.sendLetter(letter)) {
			// 向用户发送提醒
			Pushinfo pushinfo = new Pushinfo();
			pushinfo.setPushid(UUID.randomUUID().toString());
			pushinfo.setCreatdate(new Date());
			pushinfo.setIsReceived(0);
			pushinfo.setMainid(letter.getRowguid());
			pushinfo.setFromUser(onlineuser.getUsername());
			pushinfo.setToUser(username);
			pushinfo.setType(PushType.LETTER);
			mqSender.sendLetterInfoNews(pushinfo, letter.getContent());
			return "200";
		}
		return "100";
	}
	
	/**
	 * 回复私信
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/writebackletter", method = RequestMethod.POST)
	public String writeBackLetter(@RequestParam String content, String letterguid, HttpServletRequest request) {
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		Letter old = userService.getletterById(letterguid);
		Letter letter = new Letter();
		letter.setRowguid(UUID.randomUUID().toString());
		letter.setContent(content);
		letter.setCreatdate(new Date());
		letter.setFromUser(onlineuser.getUsername());
		letter.setToUser(old.getFromUser());
		letter.setIsBack(0);
		// 修改私信状态为已回复
		userService.backLetter(old);
		if (userService.sendLetter(letter)) {
			// 向用户发送提醒
			Pushinfo pushinfo = new Pushinfo();
			pushinfo.setPushid(UUID.randomUUID().toString());
			pushinfo.setCreatdate(new Date());
			pushinfo.setIsReceived(0);
			pushinfo.setMainid(letter.getRowguid());
			pushinfo.setFromUser(onlineuser.getUsername());
			pushinfo.setToUser(old.getFromUser());
			pushinfo.setType(PushType.LETTER);
			mqSender.sendLetterInfoNews(pushinfo, letter.getContent());
			return "200";
		}
		return "100";
	}
	
	/**
	 * 获取用户关注的人
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getcare", method = RequestMethod.POST)
	public String getCare(HttpServletRequest request) {
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		List<Map<String, Object>> list = userService.getCareUser(onlineuser.getUserid());
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		return jsonObject.toString();
	}
	
	/**
	 * 获取我的私信
	 * @param page
	 * @param size
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/myletter", method = RequestMethod.POST)
	public String myLetter(@RequestParam Integer page, Integer size, HttpServletRequest request) {
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		Userinfo onlineuser = (Userinfo) request.getSession().getAttribute("user");
		List<Letter> list = userService.getLetterByUser(start, size, onlineuser.getUsername());
		// 计算总数
		long count = userService.countLetter(onlineuser.getUsername());
		// 计算总页数
		long pages = (count % size == 0 ? count / size : count / size + 1);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		jsonObject.put("pages", pages);
		jsonObject.put("count", count);
		return jsonObject.toString();
	}
	
	/**
	 * 已读接口
	 * @param pushid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/readnew", method = RequestMethod.POST)
	public String readNew(@RequestParam  String pushid, HttpServletRequest request){
		if(pushService.readNew(pushid)) {
			return "200";
		}
		return "100";
	}	
}
