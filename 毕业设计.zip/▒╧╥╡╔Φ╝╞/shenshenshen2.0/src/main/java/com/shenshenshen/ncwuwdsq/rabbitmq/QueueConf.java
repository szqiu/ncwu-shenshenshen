package com.shenshenshen.ncwuwdsq.rabbitmq;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MQ队列声明
*@author 申中秋
*@date 2019年4月16日下午8:28:04
*/

@Configuration
public class QueueConf {
	
	/**
	 * 推送赞同答案提醒队列
	 * @return
	 */
	@Bean
    public Queue AgreeAnswerQueue() {
        /**
         durable="true" 持久化 rabbitmq重启的时候不需要创建新的队列
         auto-delete 表示消息队列没有在使用时将被自动删除 默认是false
         exclusive  表示该消息队列是否只在当前connection生效,默认是false
         */
        return new Queue("agree-answer-queue",true,false,false);
    }
 
   
    /**
     * 推送反对答案提醒队列
     * @return
     */
	@Bean
    public Queue AgainstAnswerQueue() {
        return new Queue("against-answer-queue",true,false,false);
    }

	/**
	 * 答案评论提醒队列
	 * @return
	 */
	@Bean
    public Queue CommentAnswerQueue() {
        return new Queue("comment-answer-queue",true,false,false);
    }
	
	/**
	 * 答案收藏提醒队列
	 * @return
	 */
	@Bean
    public Queue LikeAnswerQueue() {
        return new Queue("like-answer-queue",true,false,false);
    }
	
	/**
	 * 赞文章提醒队列
	 * @return
	 */
	@Bean
    public Queue ZanArticleQueue() {
        return new Queue("zan-article-queue",true,false,false);
    }
	
	/**
	 * 踩文章提醒队列
	 * @return
	 */
	@Bean
    public Queue CaiArticleQueue() {
        return new Queue("cai-article-queue",true,false,false);
    }
	
	/**
	 * 评论文章提醒队列
	 * @return
	 */
	@Bean
    public Queue CommentArticleQueue() {
        return new Queue("comment-article-queue",true,false,false);
    }
	/**
	 * 收藏文章提醒队列
	 * @return
	 */
	@Bean
    public Queue shoucangArticleQueue() {
        return new Queue("shoucang-article-queue",true,false,false);
    }
	
	/**
	 * 回复答案评论提醒队列
	 * @return
	 */
	@Bean
    public Queue rebackCommentAnswerQueue() {
        return new Queue("rebackcomment-answer-queue",true,false,false);
    }
	
	/**
	 * 回复文章评论提醒队列
	 * @return
	 */
	@Bean
    public Queue rebackCommentArticleQueue() {
        return new Queue("rebackcomment-article-queue",true,false,false);
    }
	
	/**
	 * 私信提醒队列
	 * @return
	 */
	@Bean
    public Queue letterQueue() {
        return new Queue("letter-queue",true,false,false);
    }
}
