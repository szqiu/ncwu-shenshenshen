package com.shenshenshen.ncwuwdsq.consumer;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.rabbitmq.client.Channel;
import com.shenshenshen.ncwuwdsq.controller.WebSocketServer;
import com.shenshenshen.ncwuwdsq.domain.Pushinfo;
import com.shenshenshen.ncwuwdsq.service.api.INewsPushService;
import com.shenshenshen.ncwuwdsq.utils.ShenStringUtils;
/**
 * 服务器消息推送队列消费者
 * @author 申中秋
 * @date 2019年4月16日下午8:55:24
 */
@Component
public class PushConsumer {
	@Autowired
	private INewsPushService newsPushService;
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	/**
	 * 赞同答案推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "agree-answer-queue" })
	public void handleAgreeAnswer(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		System.out.println("FirstConsumer {} handleMessage :" + new String(message.getBody(),"UTF-8"));
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 反对答案推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "against-answer-queue"})
	public void handleAgainstAnswer(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 评论答案推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "comment-answer-queue"})
	public void handleCommentAnswer(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 收藏答案推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "like-answer-queue"})
	public void handleLikeAnswer(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 赞文章推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "zan-article-queue"})
	public void handleZanArticle(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 踩文章推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "cai-article-queue"})
	public void handleCaiArticle(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 评论文章推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "comment-article-queue"})
	public void handleCommentArticle(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 收藏文章推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "shoucang-article-queue"})
	public void handleShoucangArticle(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 回复答案评论推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "rebackcomment-answer-queue"})
	public void handleRebackCommentAnswer(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 回复文章评论推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "rebackcomment-article-queue"})
	public void handleRebackCommentArticle(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
	
	/**
	 * 私信提醒推送消费者
	 * @param message
	 * @param channel
	 * @throws Exception
	 */
	@RabbitListener(queues = { "letter-queue"})
	public void handleLetter(Message message,Channel channel) throws Exception {
		// 处理消息
		String info = new String(message.getBody(), "UTF-8");
		Pushinfo pushinfo = JSON.parseObject(info, Pushinfo.class);
		pushinfo.setPushid(UUID.randomUUID().toString());
		// 加入redis并且设置过期时间
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(pushinfo);
		stringRedisTemplate.opsForValue().set("push_"+pushinfo.getFromUser()+"_"+pushinfo.getPushid(), jsonObject.toString(),1800,TimeUnit.SECONDS);
		// 插入消息推送表
		newsPushService.addPush(pushinfo);
		// 若推送目标用户在线，直接推送消息
		String userstr = stringRedisTemplate.opsForValue().get("online_"+pushinfo.getToUser());
		if(ShenStringUtils.isNotBlank(userstr)){
			WebSocketServer.sendInfo(pushinfo.getPushContant(), pushinfo.getToUser());
		}
		// int i = 1/0;
		channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
		// channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
	}
/*
* 消息的标识，false只确认当前一个消息收到，true确认consumer获得的所有消息
* channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
*
* ack返回false，并重新回到队列
* channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);
*
* 拒绝消息
* channel.basicReject(message.getMessageProperties().getDeliveryTag(), true);
*
*/
}
