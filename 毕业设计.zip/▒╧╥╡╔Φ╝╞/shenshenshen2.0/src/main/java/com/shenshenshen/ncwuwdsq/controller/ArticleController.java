package com.shenshenshen.ncwuwdsq.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.constant.PushType;
import com.shenshenshen.ncwuwdsq.domain.ArticleComment;
import com.shenshenshen.ncwuwdsq.domain.Articleinfo;
import com.shenshenshen.ncwuwdsq.domain.Pushinfo;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.rabbitmq.RabbitMQSender;
import com.shenshenshen.ncwuwdsq.service.api.IAgreeAndAgainstService;
import com.shenshenshen.ncwuwdsq.service.api.IArticleService;
import com.shenshenshen.ncwuwdsq.service.api.IDraftService;
import com.shenshenshen.ncwuwdsq.utils.ShenStringUtils;

/**
 * 文章相关
*@author 申中秋
*@date 2019年4月19日上午10:39:50
*/
@RestController
@RequestMapping(value = "/article")
public class ArticleController {
	@Autowired
	private IArticleService articleService;
	@Autowired
	private IDraftService draftService;
	@Autowired
	private IAgreeAndAgainstService agreeService;
	@Autowired
	private RabbitMQSender mqSender;
	
	/**
	 * 发表文章
	 * @param content
	 * @param title
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/addarticle", method = RequestMethod.POST)
	public String addArticle(@RequestParam String articleid, String content, String title, HttpServletRequest request) {
		Articleinfo articleinfo = new Articleinfo();
		Userinfo userinfo = (Userinfo) request.getSession().getAttribute("user");
		articleinfo.setTitle(title);
		articleinfo.setContant(content);
		articleinfo.setCreatdate(new Date());
		articleinfo.setHatenum(0);
		articleinfo.setLikenum(0);
		articleinfo.setHot(0);
		articleinfo.setAgreenum(0);
		articleinfo.setCommentnum(0);
		articleinfo.setIsDraft(0);
		articleinfo.setCreatuser(userinfo.getUsername());
		if (!"not".equals(articleid)) {
			articleinfo.setArticleid(articleid);
			articleService.update(articleinfo);
			return "发表成功";
		}
		articleinfo.setArticleid(UUID.randomUUID().toString());
		articleService.insert(articleinfo);
		return "发表成功";
	}	

	/**
	 * 保存文章草稿
	 * @param content
	 * @param title
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/savearticle", method = RequestMethod.POST)
	public String saveArticle(@RequestParam String articleid, String content, String title, HttpServletRequest request) {
		Articleinfo articleinfo = new Articleinfo();
		Userinfo userinfo = (Userinfo) request.getSession().getAttribute("user");
		
		articleinfo.setTitle(title);
		articleinfo.setContant(content);
		articleinfo.setCreatdate(new Date());
		articleinfo.setHatenum(0);
		articleinfo.setLikenum(0);
		articleinfo.setHot(0);
		articleinfo.setAgreenum(0);
		articleinfo.setCommentnum(0);
		articleinfo.setIsDraft(1);
		articleinfo.setCreatuser(userinfo.getUsername());
		if (!"not".equals(articleid)) {
			articleinfo.setArticleid(articleid);
			articleService.update(articleinfo);
			return "草稿保存成功";
		}
		articleinfo.setArticleid(UUID.randomUUID().toString());
		articleService.insert(articleinfo);
		return "草稿保存成功";
	}
	
	/**
	 * 修改文章
	 * @param content
	 * @param title
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/editarticle", method = RequestMethod.POST)
	public String editArticle(@RequestParam String articleid, String content, String title, HttpServletRequest request) {
		Articleinfo articleinfo = articleService.getArticleByid(articleid);
		articleinfo.setContant(content);
		articleinfo.setTitle(title);
		if (articleService.aditArticle(articleinfo) > 0) {
			return "200";
		}
		return "100";
	}
	
	/**
	 * 获取文章
	 * @return
	 */
	@RequestMapping(value = "/getarticle", method = RequestMethod.POST)
	public String getArticle(@RequestParam Integer page,Integer size,HttpServletRequest request) {
		// 计算当前分页索引
		Integer start = (page-1)*size;
		List<Articleinfo> list = articleService.getList(start,size);
		
		// 总页数
		long count = articleService.count();
		long pages = count%size == 0?count/size:count/size+1;
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	
	/**
	 * 根据id获取文章草稿
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/draftbyid", method = RequestMethod.POST)
	public String getDraftByid(@RequestParam String articleid, HttpServletRequest request) {
		Articleinfo articleinfo = draftService.getArticleById(articleid);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(articleinfo);
		return jsonObject.toString();
	}
	
	/**
	 * 赞文章
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/zan", method = RequestMethod.POST)
	public String zan(@RequestParam String articleid, HttpServletRequest request) {
		Userinfo onlineuser = (Userinfo)request.getSession().getAttribute("user");
		if (agreeService.is_Agree(onlineuser.getUsername(), articleid)) {
			return "100";
		}
		if (articleService.zan(articleid,onlineuser)) {
			return "200";
		}
		return "300";
	}
	
	/**
	 * 踩文章
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/cai", method = RequestMethod.POST)
	public String cai(@RequestParam String articleid, HttpServletRequest request) {
		Userinfo onlineuser = (Userinfo)request.getSession().getAttribute("user");
		if (agreeService.is_Against(onlineuser.getUsername(), articleid)) {
			return "100";
		}
		if (articleService.cai(articleid,onlineuser)) {
			return "200";
		}
		return "300";
	}
	
	/**
	 * 收藏文章
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/shoucang", method = RequestMethod.POST)
	public String shoucang(@RequestParam String articleid, HttpServletRequest request) {
		Userinfo onlineuser = (Userinfo)request.getSession().getAttribute("user");
		// 判断是否已收藏
		if (agreeService.is_like(onlineuser, articleid)) {
			return "100";
		}
		if (articleService.shoucang(articleid,onlineuser)) {
			return "200";
		}
		return "100";
	}
	
	/**
	 * 获取文章的评论
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getcomment", method = RequestMethod.POST)
	public String getComment(@RequestParam String articleid, HttpServletRequest request) {
		List<ArticleComment> list = articleService.getComment(articleid);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		return jsonObject.toString();
	}
	
	/**
	 * 新增评论
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/addcomment", method = RequestMethod.POST)
	public String addComment(@RequestParam String articleid,String content, HttpServletRequest request) {
		if (ShenStringUtils.isBlank(content)) {
			return "100";
		}
		Userinfo onlineuser = (Userinfo)request.getSession().getAttribute("user");
		ArticleComment comment = new ArticleComment();
		comment.setRowguid(UUID.randomUUID().toString());
		comment.setCreatuser(onlineuser.getUsername());
		comment.setArticleguid(articleid);
		comment.setContant(content);
		comment.setCreatdate(new Date());
		if(articleService.addComment(comment, onlineuser)) {
			  
			return "200";
		}
		return "100";
	}
	
	/**
	 * 回复评论
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/rebackcomment", method = RequestMethod.POST)
	public String rebackComment(@RequestParam String content,String commentid, HttpServletRequest request) {
		if (ShenStringUtils.isBlank(content)) {
			return "100";
		}
		Userinfo onlineuser = (Userinfo)request.getSession().getAttribute("user");
		ArticleComment comment = articleService.getCommentByid(commentid);
		String olduser = comment.getCreatuser();
		comment.setRowguid(UUID.randomUUID().toString());
		comment.setCreatuser(onlineuser.getUsername());
		comment.setToCommentid(commentid);
		comment.setContant("回复 <span style=\"color:blue\">"+olduser+"</span>:"+content);
		comment.setCreatdate(new Date());
		if(articleService.addComment(comment, onlineuser)) {
			// 给被回复这发送提醒
			Pushinfo pushinfo = new Pushinfo();
			pushinfo.setCreatdate(new Date());
			pushinfo.setFromUser(onlineuser.getUsername());
			pushinfo.setIsReceived(0);
			pushinfo.setMainid(comment.getArticleguid());
			pushinfo.setToUser(olduser);
			pushinfo.setType(PushType.BACKCOMMENTARTICLE);
			pushinfo.setPushid(UUID.randomUUID().toString());
			String title = articleService.getTitleByArticleId(comment.getArticleguid());
			mqSender.sendBackCommentArticleInfoNews(pushinfo, title);
			return "200";
		}
		return "100";
	}
	
	/**
	 * 搜索文章
	 * @return
	 */
	@RequestMapping(value = "/searcharticle", method = RequestMethod.POST)
	public String searchArticle(@RequestParam String searchinfo, Integer page,Integer size,HttpServletRequest request) {
		// 计算当前分页索引
		Integer start = (page-1)*size;
		List<Articleinfo> list = articleService.searchArticle(start,size,searchinfo);
		// 总页数
		long count = articleService.countSearch(searchinfo);
		long pages = count%size == 0?count/size:count/size+1;
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}
	
	/**
	 * 根据id获取文章
	 * @param articleid
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getbyid", method = RequestMethod.POST)
	public String getByid(@RequestParam String articleid, HttpServletRequest request) {
		Articleinfo articleinfo = draftService.getArticleById(articleid);
		JSONObject jsonObject = new JSONObject();
		List<Articleinfo> list = new ArrayList<>(4);
		list.add(articleinfo);
		jsonObject.put("list", list);
		return jsonObject.toString();
	}
}
