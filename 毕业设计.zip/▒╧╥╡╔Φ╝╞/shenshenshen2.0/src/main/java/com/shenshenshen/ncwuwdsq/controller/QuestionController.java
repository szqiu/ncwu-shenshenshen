package com.shenshenshen.ncwuwdsq.controller;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.domain.Answerinfo;
import com.shenshenshen.ncwuwdsq.domain.Questioninfo;
import com.shenshenshen.ncwuwdsq.domain.Questiontype;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.service.api.IQuestionAndAnswerService;

/**
 *类说明:问题相关
 *@author 申中秋
 *@date 2019年3月9日 下午2:36:32
 *
 */
@RestController
@RequestMapping(value = "/getall")
public class QuestionController {
	
	
	
	@Autowired
	private IQuestionAndAnswerService questionAndAnswerService;
	/**
	 * 获取最新问题与优秀答案
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getquestionanswer",method=RequestMethod.POST)
	public String getAll(@RequestBody String params,HttpServletRequest request) {
		String curr = request.getParameter("curr");
		String sizestr = request.getParameter("size");
		Integer size = Integer.parseInt(sizestr);
		Integer start = (Integer.parseInt(curr)-1)*size;
		List<Map<String, Object>> questionAnswers = questionAndAnswerService.getAll(start,size);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", questionAnswers);
		// 计算总页数
		long count = questionAndAnswerService.countQuestion();
		long pages = count%size==0?count/size:count/size+1;
		jsonObject.put("pages", pages);
		// TODO
//		/rabbitMQSender.send(UUID.randomUUID().toString(),UUID.randomUUID().toString());
		return jsonObject.toString();
		
	}	
	
	/**
	 * 获取最热问题
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/gethotquestionanswer",method=RequestMethod.POST)
	public String getHot(@RequestBody String params,HttpServletRequest request) {
		String curr = request.getParameter("curr");
		String sizestr = request.getParameter("size");
		Integer size = Integer.parseInt(sizestr);
		Integer start = (Integer.parseInt(curr)-1)*size;
		List<JSONObject> questionAnswers = questionAndAnswerService.getHot(start,size);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", questionAnswers);
		// 计算总页数
		long count = questionAndAnswerService.countQuestion();
		long pages = count%size==0?count/size:count/size+1;
		jsonObject.put("pages", pages);
		
		
		return jsonObject.toString();
		
	}
	
	/**
	 * 获取个性化推荐
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/personlyquestionanswer",method=RequestMethod.POST)
	public String personly(@RequestBody String params,HttpServletRequest request) {
		String curr = request.getParameter("curr");
		String sizestr = request.getParameter("size");
		Integer size = Integer.parseInt(sizestr);
		Integer start = (Integer.parseInt(curr)-1)*size;
		Userinfo onlineuser = (Userinfo)request.getSession().getAttribute("user");
		List<Map<String, Object>> questionAnswers = questionAndAnswerService.getPersonly(start, size, onlineuser);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", questionAnswers);
		// 计算总页数
		long count = questionAndAnswerService.countQuestionPersonly(onlineuser);
		long pages = count%size==0?count/size:count/size+1;
		jsonObject.put("pages", pages);
		
		// TODO
//		/rabbitMQSender.send(UUID.randomUUID().toString(),UUID.randomUUID().toString());
		return jsonObject.toString();
		
	}
	
	@RequestMapping(value = "/count",method={RequestMethod.POST,RequestMethod.GET})
	public String count() {
		return String.valueOf(questionAndAnswerService.countQuestion());
	}
	
	/**
	 * 插入图片接口
	 * @param file
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/uploadimg",method=RequestMethod.POST)
	public String uploadImg(@RequestParam("file") MultipartFile file,HttpServletRequest request) {
		String filename = UUID.randomUUID().toString().substring(0, 16);
		String extName = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
		File file2 = new File("D:/images/"+filename+"."+extName);
		request.getAttributeNames();
		try {
			file.transferTo(file2);
		/*	FileOutputStream outputStream = new FileOutputStream(file2);
			InputStream inputStream = file.getInputStream();
			
			byte[] bytes = new byte[2048];
			int len = 0;
			while((len = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, len);
            }
			outputStream.flush();*/
			// 封装返回数据
			Map<String, Object> map = new HashMap<>();
			Map<String, Object> imginfomap = new HashMap<>();
			map.put("code", "0");
			map.put("msg", "ok");
			imginfomap.put("src", "/shenshenshen/upload/"+filename+"."+extName);
			imginfomap.put("title", filename);
			map.put("data", imginfomap);
			String result = JSONObject.toJSONString(map);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		return "";
	}
	
	/**
	 * 提问接口
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/addquestion",method=RequestMethod.POST)
	public String addQuestion(@RequestBody String params,  HttpServletRequest request) {		
		Questioninfo questioninfo = new Questioninfo();
		String contant = request.getParameter("content");
		String typetext = request.getParameter("type");
		Integer typecode = questionAndAnswerService.getTypeCode(typetext).getTypecode();
		questioninfo.setCreatdate(new Date());
		questioninfo.setQuestionid(UUID.randomUUID().toString());
		questioninfo.setContant(contant);
		questioninfo.setType(typecode);
		questioninfo.setAnswernum(0);
		questioninfo.setHot(0);
		Userinfo userinfo = (Userinfo) request.getSession().getAttribute("user");
		questioninfo.setCreatuser(userinfo.getUsername());
		questioninfo.setIsopen(1);
		questionAndAnswerService.insert(questioninfo);
		return "提问成功";
	}	
	
	/**
	 * 根据id获取问题
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/getquestionbyid",method=RequestMethod.POST)
	public String getQuestionById(@RequestBody String params,HttpServletRequest request) {
		String questionid = request.getParameter("id");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("question", questionAndAnswerService.getQuestionById(questionid));
		jsonObject.put("id", questionid);
		return jsonObject.toString();
	}


	/**
	 * 根据问题id获取所有答案
	 * @param questionid
	 * @return
	 */
	@RequestMapping(value="/getanswer",method=RequestMethod.POST)
	public String getAllAnswer(@RequestParam String questionid,Integer page,Integer size) {
		List<Answerinfo> answerinfos = questionAndAnswerService
				.getAllAnswerByQuestionid(questionid,page,size);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", answerinfos);
		// 计算总页数
		long count = questionAndAnswerService.countAnswerByQid(questionid);
		
		jsonObject.put("pages", count);
		return jsonObject.toString();
	}
	
	/**
	 * 获取所有问题分类
	 * @return
	 */
	@RequestMapping(value="/gettype",method=RequestMethod.POST)
	public String getType() {
		List<Questiontype> list = questionAndAnswerService.getType();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", list);
		return jsonObject.toString();
	}
	
	/**
	 * 获取分类文本值
	 * @param typecode
	 * @return
	 */
	@RequestMapping(value="/gettypetext",method=RequestMethod.POST)
	public String getTypeText(@RequestParam String typecode) {
		Questiontype questiontype = questionAndAnswerService.getTypeText(typecode);
		
		return questiontype.getTypetext();
	}
	

	/**
	 * 搜索问题
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/searchquestionanswer",method=RequestMethod.POST)
	public String search(@RequestBody String params,HttpServletRequest request) {
		String curr = request.getParameter("curr");
		String sizestr = request.getParameter("size");
		String searchinfo = request.getParameter("searchinfo");
		Integer size = Integer.parseInt(sizestr);
		Integer start = (Integer.parseInt(curr)-1)*size;
		List<Map<String, Object>> questionAnswers = questionAndAnswerService.searchQuestion(start,size,searchinfo);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", questionAnswers);
		// 计算总页数
		long count = questionAndAnswerService.countQuestionSearch(searchinfo);
		long pages = count%size==0?count/size:count/size+1;
		jsonObject.put("pages", pages);
		// TODO
//		/rabbitMQSender.send(UUID.randomUUID().toString(),UUID.randomUUID().toString());
		return jsonObject.toString();
		
	}
}
