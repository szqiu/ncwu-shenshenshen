package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Questioninfo;
import com.shenshenshen.ncwuwdsq.domain.QuestioninfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface QuestioninfoMapper {
    int countByExample(QuestioninfoExample example);

    int deleteByExample(QuestioninfoExample example);

    int insert(Questioninfo record);

    int insertSelective(Questioninfo record);

    List<Questioninfo> selectByExample(QuestioninfoExample example);

    int updateByExampleSelective(@Param("record") Questioninfo record, @Param("example") QuestioninfoExample example);

    int updateByExample(@Param("record") Questioninfo record, @Param("example") QuestioninfoExample example);
}