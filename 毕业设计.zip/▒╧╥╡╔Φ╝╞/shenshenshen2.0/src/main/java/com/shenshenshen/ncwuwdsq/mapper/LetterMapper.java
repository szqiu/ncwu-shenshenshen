package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Letter;
import com.shenshenshen.ncwuwdsq.domain.LetterExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LetterMapper {
    int countByExample(LetterExample example);

    int deleteByExample(LetterExample example);

    int insert(Letter record);

    int insertSelective(Letter record);

    List<Letter> selectByExample(LetterExample example);

    int updateByExampleSelective(@Param("record") Letter record, @Param("example") LetterExample example);

    int updateByExample(@Param("record") Letter record, @Param("example") LetterExample example);
}