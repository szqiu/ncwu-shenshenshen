package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Articleinfo;
import com.shenshenshen.ncwuwdsq.domain.ArticleinfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ArticleinfoMapper {
    int countByExample(ArticleinfoExample example);

    int deleteByExample(ArticleinfoExample example);

    int insert(Articleinfo record);

    int insertSelective(Articleinfo record);

    List<Articleinfo> selectByExampleWithBLOBs(ArticleinfoExample example);

    List<Articleinfo> selectByExample(ArticleinfoExample example);

    int updateByExampleSelective(@Param("record") Articleinfo record, @Param("example") ArticleinfoExample example);

    int updateByExampleWithBLOBs(@Param("record") Articleinfo record, @Param("example") ArticleinfoExample example);

    int updateByExample(@Param("record") Articleinfo record, @Param("example") ArticleinfoExample example);
}