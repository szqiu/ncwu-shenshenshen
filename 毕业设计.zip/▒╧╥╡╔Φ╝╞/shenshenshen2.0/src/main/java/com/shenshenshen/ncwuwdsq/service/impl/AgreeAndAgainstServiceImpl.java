package com.shenshenshen.ncwuwdsq.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shenshenshen.ncwuwdsq.domain.Answerinfo;
import com.shenshenshen.ncwuwdsq.domain.AnswerinfoExample;
import com.shenshenshen.ncwuwdsq.domain.Questioninfo;
import com.shenshenshen.ncwuwdsq.domain.QuestioninfoExample;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgainstAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgainstAnswerArticleExample;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgreeAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.RecordUserAgreeAnswerArticleExample;
import com.shenshenshen.ncwuwdsq.domain.RecordUserLikeAnswerArticle;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.mapper.AnswerinfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.QuestioninfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.RecordUserAgainstAnswerArticleMapper;
import com.shenshenshen.ncwuwdsq.mapper.RecordUserAgreeAnswerArticleMapper;
import com.shenshenshen.ncwuwdsq.mapper.RecordUserLikeAnswerArticleMapper;
import com.shenshenshen.ncwuwdsq.service.api.IAgreeAndAgainstService;

/**
 * 赞同业务实现类
 * 
 * @author 申中秋
 * @date 2019年4月11日下午12:12:16
 */
@Service
public class AgreeAndAgainstServiceImpl implements IAgreeAndAgainstService {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private RecordUserAgreeAnswerArticleMapper agreeAnserMapper;
	@Autowired
	private RecordUserAgainstAnswerArticleMapper againstAnswerMapper;
	@Autowired
	private RecordUserLikeAnswerArticleMapper likeMapper;
	@Autowired
	private QuestioninfoMapper questioninfoMapper;
	@Autowired
	private AnswerinfoMapper answerinfoMapper;

	@Override
	public List<Map<String, Object>> getAgreeRecordByUid(String userid, Integer start, Integer size) {
		String sql = "select a.type,a.to_user,a.date,b.creatuser,c.questionid,c.contant,d.title,d.articleid from record_user_agree_answer_article a "
				+ " left join answerinfo b on a.answerid = b.answerid "
				+ " left join questioninfo c on b.questionid = c.questionid "
				+ " left join articleinfo d on a.articleid = d.articleid "
				+ " where a.agree_user = ? order by a.date desc limit ?,?";
		return jdbcTemplate.queryForList(sql, new Object[] { userid, start, size });
	}

	@Override
	public long countAgreeByUid(String username) {
		RecordUserAgreeAnswerArticleExample example = new RecordUserAgreeAnswerArticleExample();
		example.createCriteria().andAgreeUserEqualTo(username);
		return agreeAnserMapper.countByExample(example);
	}

	@Override
	@Transactional(rollbackFor = Exception.class) // 开启事务 加入线程锁
	public void agree(String answerid, Userinfo user) {
		synchronized (this) {
			RowMapper<Answerinfo> mapper = new BeanPropertyRowMapper<>(Answerinfo.class);
			String sql = "select * from answerinfo where answerid = ?";
			Answerinfo answerinfo = jdbcTemplate.queryForObject(sql, mapper, answerid);
			AnswerinfoExample example = new AnswerinfoExample();
			example.createCriteria().andAnsweridEqualTo(answerid);
			// 插入赞同记录
			RecordUserAgreeAnswerArticle agreeAnswer = new RecordUserAgreeAnswerArticle();
			agreeAnswer.setRowguid(UUID.randomUUID().toString());
			agreeAnswer.setAnswerid(answerid);
			agreeAnswer.setDate(new Date());
			agreeAnswer.setAgreeUser(user.getUsername());
			agreeAnswer.setToUser(answerinfo.getCreatuser());
			agreeAnswer.setType(0);
			agreeAnserMapper.insert(agreeAnswer);
			// 更新答案信息
			answerinfo.setAgreenum(answerinfo.getAgreenum() + 1);
			answerinfo.setHot(answerinfo.getHot() + 5);
			answerinfoMapper.updateByExample(answerinfo, example);
			// 更新问题热度
			Questioninfo questioninfo = new Questioninfo();
			RowMapper<Questioninfo> qmapper = new BeanPropertyRowMapper<>(Questioninfo.class);
			String qsql = "select * from questioninfo where questionid = ?";
			try {
				questioninfo = jdbcTemplate.queryForObject(qsql, qmapper, answerinfo.getQuestionid());
			} catch (DataAccessException e) {
				System.err.println("jdbcTemplate操作异常");
			}
			questioninfo.setHot(questioninfo.getHot() + 5);
			QuestioninfoExample qExample = new QuestioninfoExample();
			qExample.createCriteria().andQuestionidEqualTo(questioninfo.getQuestionid());
			questioninfoMapper.updateByExample(questioninfo, qExample);
		}

	}

	@Override
	public long countUserAgree(String username) {
		RecordUserAgreeAnswerArticleExample example = new RecordUserAgreeAnswerArticleExample();
		example.createCriteria().andToUserEqualTo(username);
		return agreeAnserMapper.countByExample(example);
	}

	@Override
	@Transactional(rollbackFor = Exception.class) // 开启事务 加入线程锁
	public void against(String answerid, Userinfo user) {
		synchronized (this) {// 查询答案信息
			RowMapper<Answerinfo> mapper = new BeanPropertyRowMapper<>(Answerinfo.class);
			String sql = "select * from answerinfo where answerid = ?";
			Answerinfo answerinfo = null;
			try {
				answerinfo = jdbcTemplate.queryForObject(sql, mapper, answerid);
			} catch (DataAccessException e) {

				System.err.println("jdbcTemplate操作异常");
			}
			// 插入反对记录
			RecordUserAgainstAnswerArticle against = new RecordUserAgainstAnswerArticle();
			against.setAgainstUser(user.getUsername());
			against.setAnswerid(answerid);
			against.setDate(new Date());
			against.setToUser(answerinfo.getCreatuser());
			against.setRowguid(UUID.randomUUID().toString());
			against.setType(0);
			againstAnswerMapper.insert(against);
			// 更新答案信息
			answerinfo.setHot(answerinfo.getHot() + 3);
			answerinfo.setAgainnum(answerinfo.getAgainnum() + 1);
			AnswerinfoExample example = new AnswerinfoExample();
			example.createCriteria().andAnsweridEqualTo(answerinfo.getAnswerid());
			answerinfoMapper.updateByExample(answerinfo, example);
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class) // 开启事务 加入同步锁
	public void like(String answerid, Userinfo user) {
		synchronized (this) {// 查询答案信息
			RowMapper<Answerinfo> mapper = new BeanPropertyRowMapper<>(Answerinfo.class);
			String sql = "select * from answerinfo where answerid = ?";
			Answerinfo answerinfo = jdbcTemplate.queryForObject(sql, mapper, answerid);
			// 插入收藏记录
			RecordUserLikeAnswerArticle likeAnswer = new RecordUserLikeAnswerArticle();
			likeAnswer.setAnswerid(answerid);
			likeAnswer.setRowguid(UUID.randomUUID().toString());
			likeAnswer.setLikedate(new Date());
			likeAnswer.setLikefromUser(user.getUsername());
			likeAnswer.setToUser(answerinfo.getCreatuser());
			likeAnswer.setType(0);
			likeMapper.insert(likeAnswer);
			// 更新问题信息
			answerinfo.setLikenum(answerinfo.getLikenum() + 1);
			answerinfo.setHot(answerinfo.getHot() + 10);
			AnswerinfoExample example = new AnswerinfoExample();
			example.createCriteria().andAnsweridEqualTo(answerinfo.getAnswerid());
			answerinfoMapper.updateByExample(answerinfo, example);
		}
	}

	@Override
	public List<Map<String, Object>> getAgainstRecordByUid(String username, Integer start, Integer size) {
		String sql = "select a.type,a.to_user,a.date,c.questionid,b.creatuser,c.contant,d.title,d.articleid from record_user_against_answer_article a "
				+ " left join answerinfo b on a.answerid = b.answerid "
				+ " left join questioninfo c on b.questionid = c.questionid "
				+ " left join articleinfo d on a.articleid = d.articleid " + " where a.against_user = ? limit ?,?";
		return jdbcTemplate.queryForList(sql, new Object[] { username, start, size });
	}

	@Override
	public long countAgainstByUid(String username) {
		RecordUserAgainstAnswerArticleExample example = new RecordUserAgainstAnswerArticleExample();
		example.createCriteria().andToUserEqualTo(username);
		return againstAnswerMapper.countByExample(example);
	}

	@Override
	public boolean is_Agree(String username, String mainid) {
		String sql = "select rowguid from record_user_agree_answer_article "
				+ " where agree_user = ? and (answerid =? or articleid =?)";
		try {
			jdbcTemplate.queryForMap(sql, username, mainid, mainid);
		} catch (DataAccessException e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean is_Against(String username, String mainid) {
		String sql = "select rowguid from record_user_against_answer_article "
				+ " where against_user = ? and (answerid =? or articleid =?)";
		try {
			jdbcTemplate.queryForMap(sql, username, mainid, mainid);
		} catch (DataAccessException e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean is_like(Userinfo user, String mainid) {
		String sql = "select rowguid from record_user_like_answer_article "
				+ " where likefrom_user =? and (answerid =? or articleid =?)";
		try {
			jdbcTemplate.queryForMap(sql, user.getUsername(), mainid, mainid);
		} catch (DataAccessException e) {
			return false;
		}
		return true;
	}
}
