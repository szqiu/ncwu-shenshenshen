package com.shenshenshen.ncwuwdsq.domain;

public class Questiontype {
    private Integer typecode;

    private String typetext;

    public Integer getTypecode() {
        return typecode;
    }

    public void setTypecode(Integer typecode) {
        this.typecode = typecode;
    }

    public String getTypetext() {
        return typetext;
    }

    public void setTypetext(String typetext) {
        this.typetext = typetext == null ? null : typetext.trim();
    }
}