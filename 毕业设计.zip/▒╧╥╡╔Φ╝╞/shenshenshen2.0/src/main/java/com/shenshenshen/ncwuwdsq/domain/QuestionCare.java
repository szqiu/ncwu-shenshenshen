package com.shenshenshen.ncwuwdsq.domain;

import java.util.Date;

public class QuestionCare {
    private String rowguid;

    private String beCaredQuestionid;

    private String userid;

    private Date date;

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid == null ? null : rowguid.trim();
    }

    public String getBeCaredQuestionid() {
        return beCaredQuestionid;
    }

    public void setBeCaredQuestionid(String beCaredQuestionid) {
        this.beCaredQuestionid = beCaredQuestionid == null ? null : beCaredQuestionid.trim();
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}