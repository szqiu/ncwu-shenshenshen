package com.shenshenshen.ncwuwdsq.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.domain.Answerinfo;
import com.shenshenshen.ncwuwdsq.domain.AnswerinfoExample;
import com.shenshenshen.ncwuwdsq.domain.Draftinfo;
import com.shenshenshen.ncwuwdsq.domain.DraftinfoExample;
import com.shenshenshen.ncwuwdsq.domain.Questioninfo;
import com.shenshenshen.ncwuwdsq.domain.QuestioninfoExample;
import com.shenshenshen.ncwuwdsq.domain.Questiontype;
import com.shenshenshen.ncwuwdsq.domain.QuestiontypeExample;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.mapper.AnswerinfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.DraftinfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.QuestioninfoMapper;
import com.shenshenshen.ncwuwdsq.mapper.QuestiontypeMapper;
import com.shenshenshen.ncwuwdsq.service.api.IQuestionAndAnswerService;
import com.shenshenshen.ncwuwdsq.utils.ShenStringUtils;

import redis.clients.jedis.Jedis;

/**
 *类说明:问题答案业务实现类
 *@author 申中秋
 *@date 2019年3月15日 下午2:10:02
 *
 */
@Service
public class QuestionAndAnswerServiceImpl implements IQuestionAndAnswerService{


	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private QuestioninfoMapper questioninfoMapper;
	@Autowired
	private AnswerinfoMapper answerinfoMapper;
	
	@Autowired
	private DraftinfoMapper draftMapper;
	@Autowired
	private QuestiontypeMapper typeMapper;
	/**
	 * 新增问题
	 * @param question
	 */
	@Override
	public void insert(Questioninfo questioninfo) {
		questioninfoMapper.insert(questioninfo);
	}
	
	/**
	 * 按时间获取问题跟优秀答案
	 * @param start
	 * @param size
	 * @return
	 */
	public List<Map<String, Object>> getAll(Integer start, Integer size) {
		QuestioninfoExample questioninfoExample = new QuestioninfoExample();
		questioninfoExample.setOrderByClause("creatdate desc limit "+start+", "+size);
		List<Questioninfo> questions = questioninfoMapper.selectByExample(questioninfoExample);
		List<Map<String, Object>> questionAnswers = new ArrayList<>();
		// 遍历问题，找出最优答案，并封装
		for (Questioninfo questioninfo : questions) {
			Map<String, Object> map = new HashMap<>();
			map.put("question", questioninfo);
			String sql = "select * from answerinfo where questionid = ? and is_draft = 0 order by hot desc LIMIT 0,1";
			RowMapper<Answerinfo> mapper = new BeanPropertyRowMapper<>(Answerinfo.class);
			List<Answerinfo> bestanswer = jdbcTemplate.query(sql, mapper, questioninfo.getQuestionid());
			if (bestanswer.size()>0) {
				map.put("answer", bestanswer.get(0));
			} else {
				Answerinfo answerinfo = new Answerinfo();
				answerinfo.setContant("该问题尚未有答案");

				map.put("answer", answerinfo);
			}
			questionAnswers.add(map);			
		}
		// List<Map<String, Object>> list = jdbcTemplate.queryForList("select * from questioninfo a left join answerinfo b on a.questionid = b.questionid ", new Object[]{});
		return questionAnswers;
	}

	/**
	 * 计算问题总数，供分页使用
	 * @return
	 */
	@Override
	public long countQuestion() {
		return questioninfoMapper.countByExample(new QuestioninfoExample());
	}

	// 根据id获取问题
	@Override
	public Questioninfo getQuestionById(String id) {	
		QuestioninfoExample example = new QuestioninfoExample();
		example.createCriteria().andQuestionidEqualTo(id);
		List<Questioninfo> list = questioninfoMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * 添加答案
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public int addAnswer(Answerinfo answerinfo) {
		if (answerinfo.getIsDraft() == 1) {
			// 插入草稿记录
			Draftinfo draftinfo = new Draftinfo();
			draftinfo.setDraftid(UUID.randomUUID().toString());
			draftinfo.setMainid(answerinfo.getAnswerid());
			draftinfo.setType(0);
			draftinfo.setCreatuser(answerinfo.getCreatuser());
			draftMapper.insert(draftinfo);
		} 
		// 更新问题信息
		String sql = "select hot,answernum from questioninfo where questionid = ?";
		Map<String, Object> map = jdbcTemplate.queryForMap(sql,answerinfo.getQuestionid());
		Questioninfo questioninfo = new Questioninfo();
		questioninfo.setAnswernum((Integer)map.get("answernum") + 1);
		questioninfo.setHot((Integer)map.get("hot") + 10);
		QuestioninfoExample questioninfoExample = new QuestioninfoExample();
		questioninfoExample.createCriteria().andQuestionidEqualTo(answerinfo.getQuestionid());
		questioninfoMapper.updateByExampleSelective(questioninfo, questioninfoExample);
		return answerinfoMapper.insert(answerinfo);
	}

	
	@Override
	public List<Answerinfo> getAllAnswerByQuestionid(String questionid,Integer page,Integer size) {
		AnswerinfoExample answerinfoExample = new AnswerinfoExample();
		answerinfoExample.setOrderByClause(" hot desc limit "+page+", "+size);
		answerinfoExample.createCriteria().andQuestionidEqualTo(questionid).andIsDraftEqualTo(0);
		List<Answerinfo> answerinfos = answerinfoMapper.selectByExampleWithBLOBs(answerinfoExample);
		return answerinfos;
	}

	

	@Override
	public long countAnswerByQid(String qid) {
		AnswerinfoExample answerinfoExample = new AnswerinfoExample();
		answerinfoExample.createCriteria().andQuestionidEqualTo(qid).andIsDraftEqualTo(0);
		return answerinfoMapper.countByExample(answerinfoExample);
	}

	

	@Override
	public List<Map<String, Object>> getQuestionByUser(String creatuser, Integer start, Integer size) {
		String sql = "select questionid,creatdate, contant from questioninfo where creatuser = ? limit ?,?";
		return jdbcTemplate.queryForList(sql, new Object[]{creatuser,start,size});
	}

	@Override
	public long countQuestionByUname(String username) {
		QuestioninfoExample example = new QuestioninfoExample();
		example.createCriteria().andCreatuserEqualTo(username);
		return questioninfoMapper.countByExample(example);
	}

	@Override
	public List<Map<String, Object>> getAnswerByUser(String username, Integer start, Integer size) {
		String sql = "select a.questionid,b.contant qcontant, a.creatdate,a.answerid from answerinfo a "
				+ " left join questioninfo b on a.questionid = b.questionid where a.creatuser = ? and is_draft = 0 order by creatdate desc limit ?,?";
		return jdbcTemplate.queryForList(sql, new Object[]{username,start,size} );
	}

	@Override
	public long countAnswerByUname(String username) {
		AnswerinfoExample example = new AnswerinfoExample();
		example.createCriteria().andCreatuserEqualTo(username).andIsDraftEqualTo(0);
		return answerinfoMapper.countByExample(example);
	}


	@Override
	public List<Questiontype> getType() {
		QuestiontypeExample example = new QuestiontypeExample();
		return typeMapper.selectByExample(example);
	}

	@Override
	public Questiontype getTypeText(String typecode) {
		QuestiontypeExample example = new QuestiontypeExample();
		Integer code = Integer.parseInt(typecode);
		example.createCriteria().andTypecodeEqualTo(code);
		List<Questiontype> list = typeMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public Questiontype getTypeCode(String typetext) {
		
		QuestiontypeExample example = new QuestiontypeExample();
		example.createCriteria().andTypetextEqualTo(typetext);
		List<Questiontype> list = typeMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public List<Map<String, Object>> getHotQuestionAndAnswer() {
		// 按热度获取top10
		QuestioninfoExample example = new QuestioninfoExample();
		example.setOrderByClause(" hot desc limit 0,10");
		example.createCriteria().andHotGreaterThan(1);
		example.createCriteria().andAnswernumGreaterThan(0);
		List<Questioninfo> hotquestions = questioninfoMapper.selectByExample(example);
		// 查询问题的最热答案
		List<Map<String, Object>> maps = new ArrayList<>();
		for (Questioninfo questioninfo : hotquestions) {
			AnswerinfoExample answerinfoExample = new AnswerinfoExample();
			answerinfoExample.createCriteria().andQuestionidEqualTo(questioninfo.getQuestionid())
			.andIsDraftEqualTo(0);
			answerinfoExample.setOrderByClause(" hot desc limit 0,1");
			List<Answerinfo> bestanswer = answerinfoMapper.selectByExampleWithBLOBs(answerinfoExample);
			Map<String, Object> map = new HashMap<>(2);
			map.put("question", questioninfo);
			if (bestanswer != null && bestanswer.size() > 0) {
				map.put("bestanswer", bestanswer.get(0));
				maps.add(map);
			}
			
		}
		return maps;
	}

	@Override
	public List<JSONObject> getHot(Integer start, Integer size) {
		Jedis jedis = new Jedis();
		List<JSONObject> list = new ArrayList<>(32);
		for (int i = 0; i < 15; i++) {
			String info = jedis.get("hot_"+i);
			if (ShenStringUtils.isNotBlank(info)) {
				JSONObject jsonObject = JSONObject.parseObject(info);				
				list.add(jsonObject);
			}
			
		}
		jedis.close();
		return list;
	}

	@Override
	public Map<String, Object> getAnswerById(String answerid) {
		String sql = "select a.contant answer,a.creatuser creatuser,b.contant question from answerinfo a "
				+ " left join questioninfo b on a.questionid = b.questionid "
				+ " where a.answerid = ?";
		return jdbcTemplate.queryForMap(sql, answerid);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public int updateAnswer(Answerinfo answerinfo) {
		// 如果不是草稿，就从草稿记录中删除
		if (answerinfo.getIsDraft() == 0) {
			DraftinfoExample example = new DraftinfoExample();
			example.createCriteria().andMainidEqualTo(answerinfo.getAnswerid());
			draftMapper.deleteByExample(example);
		}
		// 查询旧答案信息
		String sql = "select questionid from answerinfo where answerid = ?";
		Map<String, Object> map = jdbcTemplate.queryForMap(sql,answerinfo.getAnswerid());
		// 更新答案信息
		answerinfo.setQuestionid((String)map.get("questionid"));
		AnswerinfoExample answerinfoExample = new AnswerinfoExample();
		answerinfoExample.createCriteria().andAnsweridEqualTo(answerinfo.getAnswerid());
		return answerinfoMapper.updateByExampleWithBLOBs(answerinfo, answerinfoExample);
	}

	@Override
	public Questioninfo getQuestionByAnswerId(String answerid) {
		
		
		return null;
	}

	@Override
	public List<Map<String, Object>> getPersonly(Integer start, Integer size, Userinfo onlineuser) {
		// 用户偏爱分类
		String liketype = onlineuser.getLiketype();
		String[] types = liketype.split(",");
		QuestioninfoExample questioninfoExample = new QuestioninfoExample();
		questioninfoExample.setOrderByClause("creatdate desc limit "+start+", "+size);
		List<Integer> codes = new ArrayList<>();
		for (String type : types) {
			Integer typecode = Integer.parseInt(type);
			codes.add(typecode);
		}
		questioninfoExample.createCriteria().andTypeIn(codes);
		List<Questioninfo> questions = questioninfoMapper.selectByExample(questioninfoExample);
		List<Map<String, Object>> questionAnswers = new ArrayList<>();
		// 遍历问题，找出最优答案，并封装
		for (Questioninfo questioninfo : questions) {
			Map<String, Object> map = new HashMap<>();
			map.put("question", questioninfo);
			String sql = "select * from answerinfo where questionid = ? and is_draft = 0 order by hot desc LIMIT 0,1";
			RowMapper<Answerinfo> mapper = new BeanPropertyRowMapper<>(Answerinfo.class);
			List<Answerinfo> bestanswer = jdbcTemplate.query(sql, mapper, questioninfo.getQuestionid());
			if (bestanswer.size()>0) {
				map.put("answer", bestanswer.get(0));
			} else {
				Answerinfo answerinfo = new Answerinfo();
				answerinfo.setContant("该问题尚未有答案");

				map.put("answer", answerinfo);
			}
			questionAnswers.add(map);			
		}
		// List<Map<String, Object>> list = jdbcTemplate.queryForList("select * from questioninfo a left join answerinfo b on a.questionid = b.questionid ", new Object[]{});
		return questionAnswers;
	}
	
	@Override
	public long countQuestionPersonly(Userinfo onlineuser) {
		// 用户偏爱分类
		String liketype = onlineuser.getLiketype();
		String[] types = liketype.split(",");
		List<Integer> codes = new ArrayList<>();
		for (String type : types) {
			Integer typecode = Integer.parseInt(type);
			codes.add(typecode);
		}
		QuestioninfoExample example = new QuestioninfoExample();
		example.createCriteria().andTypeIn(codes);
		return questioninfoMapper.countByExample(example);
	}

	@Override
	public List<Map<String, Object>> searchQuestion(Integer start, Integer size, String searchinfo) {
		QuestioninfoExample questioninfoExample = new QuestioninfoExample();
		questioninfoExample.setOrderByClause("creatdate desc limit "+start+", "+size);
		questioninfoExample.createCriteria().andContantLike("%"+searchinfo+"%");
		List<Questioninfo> questions = questioninfoMapper.selectByExample(questioninfoExample);
		List<Map<String, Object>> questionAnswers = new ArrayList<>();
		// 遍历问题，找出最优答案，并封装
		for (Questioninfo questioninfo : questions) {
			Map<String, Object> map = new HashMap<>();
			map.put("question", questioninfo);
			String answersql = "select * from answerinfo where questionid = ? and is_draft = 0 order by hot desc LIMIT 0,1";
			RowMapper<Answerinfo> mapper = new BeanPropertyRowMapper<>(Answerinfo.class);
			List<Answerinfo> bestanswer = jdbcTemplate.query(answersql, mapper, questioninfo.getQuestionid());
			if (bestanswer.size()>0) {
				map.put("answer", bestanswer.get(0));
			} else {
				Answerinfo answerinfo = new Answerinfo();
				answerinfo.setContant("该问题尚未有答案");

				map.put("answer", answerinfo);
			}
			questionAnswers.add(map);			
		}
		// List<Map<String, Object>> list = jdbcTemplate.queryForList("select * from questioninfo a left join answerinfo b on a.questionid = b.questionid ", new Object[]{});
		return questionAnswers;
	}

	@Override
	public long countQuestionSearch(String searchinfo) {
		QuestioninfoExample example = new QuestioninfoExample();
		example.createCriteria().andContantLike("%"+searchinfo+"%");
		return questioninfoMapper.countByExample(example);
	}

	@Override
	public Answerinfo getAnswerByAid(String answerid) {
		AnswerinfoExample example = new AnswerinfoExample();
		example.createCriteria().andAnsweridEqualTo(answerid);
		List<Answerinfo> list = new ArrayList<>(4);
		list = answerinfoMapper.selectByExampleWithBLOBs(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public int eidtAnswer(Answerinfo answerinfo) {
		AnswerinfoExample example = new AnswerinfoExample();
		example.createCriteria().andAnsweridEqualTo(answerinfo.getAnswerid());
		return answerinfoMapper.updateByExampleWithBLOBs(answerinfo, example);
	}

	
}
