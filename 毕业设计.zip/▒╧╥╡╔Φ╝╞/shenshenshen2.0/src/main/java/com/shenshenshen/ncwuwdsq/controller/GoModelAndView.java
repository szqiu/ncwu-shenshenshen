package com.shenshenshen.ncwuwdsq.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 访问静态页面
*@author 申中秋
*@date 2019年3月25日下午1:59:50
*/
@Controller
public class GoModelAndView {
	
	@RequestMapping(value = "/gologin", method = {RequestMethod.GET,RequestMethod.POST})
	public String goLogin() {
		return "login";
	}
	
	@RequestMapping(value = "/person", method = RequestMethod.GET)
	public String goPersion() {
		return "personly";
	}
}
