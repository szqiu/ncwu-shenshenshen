package com.shenshenshen.ncwuwdsq.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 主页设置
*@author 申中秋
*@date 2019年3月21日下午5:02:01
*/
@Configuration
public class MainView implements WebMvcConfigurer{

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		 registry.addViewController( "/" ).setViewName( "forward:/flownews.html" );
	        registry.setOrder( Ordered.HIGHEST_PRECEDENCE );		
	}
	
}
