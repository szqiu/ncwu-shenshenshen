package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.UserCare;
import com.shenshenshen.ncwuwdsq.domain.UserCareExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserCareMapper {
    int countByExample(UserCareExample example);

    int deleteByExample(UserCareExample example);

    int deleteByPrimaryKey(String rowguid);

    int insert(UserCare record);

    int insertSelective(UserCare record);

    List<UserCare> selectByExample(UserCareExample example);

    UserCare selectByPrimaryKey(String rowguid);

    int updateByExampleSelective(@Param("record") UserCare record, @Param("example") UserCareExample example);

    int updateByExample(@Param("record") UserCare record, @Param("example") UserCareExample example);

    int updateByPrimaryKeySelective(UserCare record);

    int updateByPrimaryKey(UserCare record);
}