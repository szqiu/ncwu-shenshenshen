package com.shenshenshen.ncwuwdsq.service.api;

import java.util.List;

import com.shenshenshen.ncwuwdsq.domain.Comment;

/**
 * 评论业务接口
*@author 申中秋
*@date 2019年4月9日下午7:46:53
*/
public interface ICommentService {
	/**
	 * 新增答案评论
	 * @param comment
	 */
	public void addAnswerComment(Comment comment);

	/**
	 * 获取答案下的所有评论
	 * @param answerid
	 * @return
	 */
	public List<Comment> getCommentByQid(String answerid);

	/**
	 * 根据id获取评论
	 * @param commentid
	 * @return
	 */
	public Comment getCommentByid(String commentid);
}
