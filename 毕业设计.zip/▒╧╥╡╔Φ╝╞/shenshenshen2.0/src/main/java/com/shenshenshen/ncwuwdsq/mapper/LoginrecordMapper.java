package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Loginrecord;
import com.shenshenshen.ncwuwdsq.domain.LoginrecordExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LoginrecordMapper {
    int countByExample(LoginrecordExample example);

    int deleteByExample(LoginrecordExample example);

    int insert(Loginrecord record);

    int insertSelective(Loginrecord record);

    List<Loginrecord> selectByExample(LoginrecordExample example);

    int updateByExampleSelective(@Param("record") Loginrecord record, @Param("example") LoginrecordExample example);

    int updateByExample(@Param("record") Loginrecord record, @Param("example") LoginrecordExample example);
}