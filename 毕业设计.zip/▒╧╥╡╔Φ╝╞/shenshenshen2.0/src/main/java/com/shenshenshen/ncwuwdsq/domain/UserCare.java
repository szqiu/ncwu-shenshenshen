package com.shenshenshen.ncwuwdsq.domain;

import java.util.Date;

public class UserCare {
    private String rowguid;

    private String beCaredUserid;

    private String userid;

    private Date date;

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid == null ? null : rowguid.trim();
    }

    public String getBeCaredUserid() {
        return beCaredUserid;
    }

    public void setBeCaredUserid(String beCaredUserid) {
        this.beCaredUserid = beCaredUserid == null ? null : beCaredUserid.trim();
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}