package com.shenshenshen.ncwuwdsq.service.api;

import java.util.List;
import java.util.Map;

import com.shenshenshen.ncwuwdsq.domain.Letter;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;

/**用户业务层接口
*@author 申中秋
*@date 2019年3月25日下午5:15:55
*/
public interface IUserService {
	/**
	 * 注册用户
	 * @param userinfo
	 * @return
	 */
	public boolean registUser(Userinfo userinfo);
	
	/**
	 * 验证用户名是否可用
	 * @param username
	 * @return
	 */
	public boolean confirmUsername(String username);

	/**
	 * 验证登录名
	 * @param loginid
	 * @return
	 */
	public boolean confirmLoginid(String loginid);

	/**
	 * 获取用户id
	 * @param userinfo
	 * @return
	 */
	public String getUserguid(Userinfo userinfo);

	/**
	 * 用户登录方法
	 * @param userinfo
	 * @return
	 */
	public Userinfo login(Userinfo userinfo);

	/**
	 * 用户登出
	 * @param userinfo
	 * @return
	 */
	public boolean loginOut(Userinfo userinfo);

	/**
	 * 根据昵称查找用户
	 * @param username
	 * @return
	 */
	public Userinfo getUserByUname(String username);

	/**
	 * 用户关注
	 * @param onlineuser
	 * @param becaredUser
	 * @return 
	 */
	public boolean careForUser(Userinfo onlineuser, Userinfo becaredUser);

	/**
	 * 取消用户关注
	 * @param onlineuser
	 * @param becaredUser
	 * @return
	 */
	public boolean notCareForUser(Userinfo onlineuser, Userinfo becaredUser);
	/**
	 * 判断是否已关注
	 * @param onlineuser
	 * @param becaredUser
	 * @return
	 */
	public boolean isCareFor(Userinfo onlineuser, Userinfo becaredUser);

	/**
	 * 更新用户信息
	 * @param onlineuser
	 * @return
	 */
	public boolean updateUserInfo(Userinfo onlineuser);
	
	/**
	 * 发送私信
	 * @param letter
	 * @return
	 */
	public boolean sendLetter(Letter letter);

	public List<Map<String, Object>> getCareUser(String userid);

	/**
	 * 分页获取我的私信
	 * @param size 
	 * @param start 
	 * @param username
	 * @return
	 */
	public List<Letter> getLetterByUser(Integer start, Integer size, String username);

	/**
	 * 获取我的私信数
	 * @param username
	 * @return
	 */
	public long countLetter(String username);

	/**
	 * 修改私信状态为已回复
	 * @param letter
	 */
	public void backLetter(Letter letter);

	/**
	 * 根据id获取私信
	 * @param letterguid
	 * @return
	 */
	public Letter getletterById(String letterguid);

	
}
