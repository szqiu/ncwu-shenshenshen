package com.shenshenshen.ncwuwdsq.controller;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.constant.PushType;
import com.shenshenshen.ncwuwdsq.domain.Answerinfo;
import com.shenshenshen.ncwuwdsq.domain.Comment;
import com.shenshenshen.ncwuwdsq.domain.Pushinfo;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.rabbitmq.RabbitMQSender;
import com.shenshenshen.ncwuwdsq.service.api.IAgreeAndAgainstService;
import com.shenshenshen.ncwuwdsq.service.api.ICommentService;
import com.shenshenshen.ncwuwdsq.service.api.IQuestionAndAnswerService;
import com.shenshenshen.ncwuwdsq.utils.ShenStringUtils;

/**
 * 答案相关
 * 
 * @author 申中秋
 * @date 2019年3月22日下午5:49:48
 */
@RestController
@RequestMapping(value = "/answer")
public class AnswerController {

	@Autowired
	private IQuestionAndAnswerService questionAndAnswerService;
	@Autowired
	private ICommentService commentService;
	@Autowired
	private IAgreeAndAgainstService agreeAndAgainstService;
	@Autowired
	private RabbitMQSender mqSender;

	/**
	 * 添加答案
	 * 
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/addanswer", method = RequestMethod.POST)
	public String addAnswer(@RequestBody String params, HttpServletRequest request) {
		String answer = request.getParameter("content");
		String questionid = request.getParameter("questionid");
		String answerid = request.getParameter("answerid");
		Answerinfo answerinfo = new Answerinfo();
		Userinfo userinfo = (Userinfo) request.getSession().getAttribute("user");
		answerinfo.setContant(answer);
		answerinfo.setCreatdate(new Date());
		answerinfo.setCreatuser(userinfo.getUsername());
		answerinfo.setHot(0);
		answerinfo.setLikenum(0);
		answerinfo.setAgainnum(0);
		answerinfo.setIsDraft(0);
		answerinfo.setAgreenum(0);
		answerinfo.setCommentnum(0);
		if (!"not".equals(answerid)) {
			answerinfo.setAnswerid(answerid);
			if (questionAndAnswerService.updateAnswer(answerinfo) > 0) {
				return "ok";
			}
			;
			return "erro";
		}
		answerinfo.setQuestionid(questionid);
		answerinfo.setAnswerid(UUID.randomUUID().toString());
		if (questionAndAnswerService.addAnswer(answerinfo) > 0) {
			return "ok";
		}
		;
		return "erro";
	}
	
	/**
	 * 修改答案
	 * 
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/editanswer", method = RequestMethod.POST)
	public String editAnswer(@RequestBody String params, HttpServletRequest request) {
		String answer = request.getParameter("content");
		String answerid = request.getParameter("answerid");
		Answerinfo answerinfo = questionAndAnswerService.getAnswerByAid(answerid);
		
		answerinfo.setContant(answer);
		
		if (questionAndAnswerService.eidtAnswer(answerinfo) > 0) {
			return "200";
		}
		
		return "100";
	}

	/**
	 * 保存答案草稿
	 * 
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/saveanswer", method = RequestMethod.POST)
	public String saveAnswer(@RequestBody String params, HttpServletRequest request) {
		String answer = request.getParameter("content");
		String questionid = request.getParameter("questionid");
		String answerid = request.getParameter("answerid");
		Answerinfo answerinfo = new Answerinfo();
		Userinfo userinfo = (Userinfo) request.getSession().getAttribute("user");
		answerinfo.setContant(answer);
		answerinfo.setCreatdate(new Date());
		answerinfo.setCreatuser(userinfo.getUsername());
		answerinfo.setHot(0);
		answerinfo.setLikenum(0);
		answerinfo.setAgainnum(0);
		answerinfo.setAgreenum(0);
		answerinfo.setIsDraft(1);
		answerinfo.setCommentnum(0);
		if (!"not".equals(answerid)) {
			answerinfo.setAnswerid(answerid);
			if (questionAndAnswerService.updateAnswer(answerinfo) > 0) {
				return "ok";
			}
			return "erro";
		}
		answerinfo.setAnswerid(UUID.randomUUID().toString());
		answerinfo.setQuestionid(questionid);
		if (questionAndAnswerService.addAnswer(answerinfo) > 0) {
			return "ok";
		}
		;
		return "erro";
	}

	/**
	 * 根据id获取答案草稿
	 * 
	 * @param params
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getdraft", method = RequestMethod.POST)
	public String getDraft(@RequestParam String answerid, HttpServletRequest request) {
		System.out.println(answerid);
		Map<String, Object> map = questionAndAnswerService.getAnswerById(answerid);
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(map);
		return jsonObject.toString();
	}

	/**
	 * 根据问题id获取所有答案
	 * 
	 * @param questionid
	 * @return
	 */
	@RequestMapping(value = "/getanswer", method = RequestMethod.POST)
	public String getAllAnswer(@RequestParam String questionid, Integer page, Integer size) {
		// 计算当前分页索引
		Integer start = (page - 1) * size;
		List<Answerinfo> answerinfos = questionAndAnswerService.getAllAnswerByQuestionid(questionid, start, size);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", answerinfos);
		// 计算总页数
		long count = questionAndAnswerService.countAnswerByQid(questionid);
		long pages = count % size == 0 ? count / size : count / size + 1;
		jsonObject.put("pages", pages);
		return jsonObject.toString();
	}

	/**
	 * 插入图片接口
	 * @param file
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/uploadimg", method = RequestMethod.POST)
	public String uploadImg(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
		String filename = UUID.randomUUID().toString().substring(0, 16);
		String extName = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
		File file2 = new File("D:/images/" + filename + "." + extName);
		request.getAttributeNames();
		try {
			file.transferTo(file2);
			// 封装返回信息
			Map<String, Object> map = new HashMap<>();
			Map<String, Object> imagemap = new HashMap<>();
			map.put("code", "0");
			map.put("msg", "ok");
			imagemap.put("src", "/shenshenshen/" + filename + "." + extName);
			imagemap.put("title", filename);
			map.put("data", imagemap);
			String result = JSONObject.toJSONString(map);
			return result;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * 根据id获取该答案的所有评论
	 * 
	 * @param answerid
	 * @return
	 */
	@RequestMapping(value = "/getcomment", method = RequestMethod.POST)
	public String getComment(@RequestParam String answerid) {
		List<Comment> comments = commentService.getCommentByQid(answerid);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", comments);
		return jsonObject.toString();
	}

	/**
	 * 添加评论接口
	 * 
	 * @param answerid
	 * @param content
	 * @return
	 */
	@RequestMapping(value = "/addcomment", method = RequestMethod.POST)
	public String addComment(@RequestParam String answerid, String content, HttpServletRequest request) {
		if (ShenStringUtils.isBlank(content)) {
			return "100";
		}
		Userinfo user = (Userinfo) request.getSession().getAttribute("user");
		Comment comment = new Comment();
		comment.setCreatuser(user.getUsername());
		comment.setAnswerguid(answerid);
		comment.setContant(content);
		comment.setCreatdate(new Date());
		comment.setRowguid(UUID.randomUUID().toString());
		commentService.addAnswerComment(comment);
		// 向队列里加入推送消息
		Pushinfo pushinfo = new Pushinfo();
		Map<String, Object> map = questionAndAnswerService.getAnswerById(answerid);
		pushinfo.setCreatdate(new Date());
		pushinfo.setFromUser(user.getUsername());
		pushinfo.setToUser((String) map.get("creatuser"));
		pushinfo.setIsReceived(0);
		pushinfo.setMainid(answerid);
		pushinfo.setType(PushType.COMMENTANSWER);
		// 向队列里插入消息推送
		mqSender.sendCommentAnswerInfoNews(pushinfo, (String) map.get("question"));
		return "200";
	}
	
	/**
	 * 回复评论接口
	 * @param answerid
	 * @param content
	 * @return
	 */
	@RequestMapping(value = "/rebackcomment", method = RequestMethod.POST)
	public String rebackComment(@RequestParam String commentid, String content, HttpServletRequest request) {
		if (ShenStringUtils.isBlank(content)) {
			System.out.println(content.length());
			return "100";
		}
		Userinfo user = (Userinfo) request.getSession().getAttribute("user");
		Comment comment = commentService.getCommentByid(commentid);
		String commentuser = comment.getCreatuser();
		comment.setCreatuser(user.getUsername());
		comment.setContant("回复 <span style=\"color:blue\">"+commentuser+"</span>:"+content);
		comment.setCreatdate(new Date());
		comment.setRowguid(UUID.randomUUID().toString());
		comment.setToCommentid(comment.getRowguid());
		commentService.addAnswerComment(comment);
		// 向被回复者推送消息
		Pushinfo pushinfo = new Pushinfo();
		Map<String, Object> map = questionAndAnswerService.getAnswerById(comment.getAnswerguid());
		pushinfo.setCreatdate(new Date());
		pushinfo.setFromUser(user.getUsername());
		pushinfo.setToUser(commentuser);
		pushinfo.setIsReceived(0);
		pushinfo.setMainid(comment.getAnswerguid());
		pushinfo.setType(PushType.COMMENTANSWER);
		mqSender.sendBackCommentAnswerInfoNews(pushinfo, (String)map.get("question"));
		return "200";
	}
	
	/**
	 * 根据id获取评论
	 * 
	 * @param answerid
	 * @return
	 */
	@RequestMapping(value = "/getcommentbyid", method = RequestMethod.POST)
	public String getCommentById(@RequestParam String commentid) {
		Comment comment = commentService.getCommentByid(commentid);
		JSONObject jsonObject = (JSONObject) JSON.toJSON(comment);
		return jsonObject.toString();
	}

	/**
	 * 赞同接口
	 * 
	 * @param answerid
	 * @return
	 */
	@RequestMapping(value = "/agree", method = RequestMethod.POST)
	public String agree(@RequestParam String answerid, HttpServletRequest request) {
		Userinfo user = (Userinfo) request.getSession().getAttribute("user");
		if (agreeAndAgainstService.is_Agree(user.getUsername(), answerid)) {
			return "100";
		}
		agreeAndAgainstService.agree(answerid, user);
		// 向队列里加入推送消息
		Pushinfo pushinfo = new Pushinfo();
		Map<String, Object> map = questionAndAnswerService.getAnswerById(answerid);
		pushinfo.setCreatdate(new Date());
		pushinfo.setFromUser(user.getUsername());
		pushinfo.setToUser((String) map.get("creatuser"));
		pushinfo.setIsReceived(0);
		pushinfo.setMainid(answerid);
		pushinfo.setType(PushType.AGREEANSWER);
		// 向队列里插入消息推送
		mqSender.sendAgreeInfoNews(pushinfo, (String) map.get("question"));
		return "200";
	}

	/**
	 * 反对接口
	 * 
	 * @param answerid
	 * @return
	 */
	@RequestMapping(value = "/against", method = RequestMethod.POST)
	public String against(@RequestParam String answerid, HttpServletRequest request) {
		Userinfo user = (Userinfo) request.getSession().getAttribute("user");
		if (agreeAndAgainstService.is_Against(user.getUsername(), answerid)) {
			return "100";
		}
		agreeAndAgainstService.against(answerid, user);
		// 向作者推送消息
		Pushinfo pushinfo = new Pushinfo();
		Map<String, Object> map = questionAndAnswerService.getAnswerById(answerid);
		pushinfo.setCreatdate(new Date());
		pushinfo.setFromUser(user.getUsername());
		pushinfo.setToUser((String) map.get("creatuser"));
		pushinfo.setIsReceived(0);
		pushinfo.setMainid(answerid);
		pushinfo.setType(PushType.AGAINSTANSWER);
		// 向队列里插入消息推送
		mqSender.sendAgainstInfoNews(pushinfo, (String) map.get("question"));
		return "200";
	}

	/**
	 * 收藏接口
	 * 
	 * @param answerid
	 * @return
	 */
	@RequestMapping(value = "/like", method = RequestMethod.POST)
	public String like(@RequestParam String answerid, HttpServletRequest request) {
		Userinfo user = (Userinfo) request.getSession().getAttribute("user");
		// 判断是否已经收藏
		if (agreeAndAgainstService.is_like(user,answerid)) {
			return "100";
		}
		agreeAndAgainstService.like(answerid, user);
		// 向队列里加入推送消息
		Pushinfo pushinfo = new Pushinfo();
		Map<String, Object> map = questionAndAnswerService.getAnswerById(answerid);
		pushinfo.setCreatdate(new Date());
		pushinfo.setFromUser(user.getUsername());
		pushinfo.setToUser((String) map.get("creatuser"));
		pushinfo.setIsReceived(0);
		pushinfo.setMainid(answerid);
		pushinfo.setType(PushType.LIKEANSWER);
		// 向队列里插入消息推送
		mqSender.sendLikeAnswerInfoNews(pushinfo, (String) map.get("question"));
		return "200";
	}
}
