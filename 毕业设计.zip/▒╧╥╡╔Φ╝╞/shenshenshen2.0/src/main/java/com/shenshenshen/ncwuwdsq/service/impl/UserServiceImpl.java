package com.shenshenshen.ncwuwdsq.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.shenshenshen.ncwuwdsq.domain.Letter;
import com.shenshenshen.ncwuwdsq.domain.LetterExample;
import com.shenshenshen.ncwuwdsq.domain.UserCare;
import com.shenshenshen.ncwuwdsq.domain.UserCareExample;
import com.shenshenshen.ncwuwdsq.domain.Userinfo;
import com.shenshenshen.ncwuwdsq.domain.UserinfoExample;
import com.shenshenshen.ncwuwdsq.mapper.LetterMapper;
import com.shenshenshen.ncwuwdsq.mapper.UserCareMapper;
import com.shenshenshen.ncwuwdsq.mapper.UserinfoMapper;
import com.shenshenshen.ncwuwdsq.service.api.IUserService;

/**
 * 用户业务层实现类
 * 
 * @author 申中秋
 * @date 2019年3月25日下午5:16:18
 */
@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserinfoMapper userinfoMapper;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private RedisTemplate<String, String> redisTemplate;
	@Autowired
	private UserCareMapper userCareMapper;
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	@Autowired
	private LetterMapper letterMapper;
	
	@Override
	public boolean registUser(Userinfo userinfo) {
		userinfo.setUserid(UUID.randomUUID().toString());
		try {
			userinfoMapper.insert(userinfo);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} 

	}

	@Override
	public boolean confirmUsername(String username) {
		// 判断昵称是否可以使用
		UserinfoExample example = new UserinfoExample();
		example.createCriteria().andUsernameEqualTo(username);
		List<Userinfo> list = userinfoMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return false;
		}
		return true;
	}

	@Override
	public boolean confirmLoginid(String loginid) {
		// 去redis中匹配登录名是否可以使用
		UserinfoExample example = new UserinfoExample();
		example.createCriteria().andLoginidEqualTo(loginid);
		List<Userinfo> list = userinfoMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return false;
		}
		return true;
	}

	@Override
	public String getUserguid(Userinfo userinfo) {

		return null;
	}

	@Override
	public Userinfo login(Userinfo userinfo) {
		UserinfoExample example = new UserinfoExample();
		example.createCriteria().andLoginidEqualTo(userinfo.getLoginid());
		List<Userinfo> list = userinfoMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			if (!list.get(0).getPassword().equals(userinfo.getPassword())) {
				return null;
			}
			// 将登录成功用户放入redis
			JSONObject jsonObject = (JSONObject) JSON.toJSON(list.get(0));
			stringRedisTemplate.opsForValue().set("online_" + list.get(0).getUsername(), jsonObject.toString());
			return list.get(0);
		}
		return null;
	}

	@Override
	public boolean loginOut(Userinfo userinfo) {
		// 从redis中删除当前用户
		stringRedisTemplate.delete("online_" + userinfo.getUsername());
		return true;
	}

	@Override
	public Userinfo getUserByUname(String username) {
		UserinfoExample example = new UserinfoExample();
		example.createCriteria().andUsernameEqualTo(username);
		List<Userinfo> users = userinfoMapper.selectByExample(example);
		if (users != null && users.size() > 0) {
			return users.get(0);
		}
		return null;
	}

	@Override
	public boolean careForUser(Userinfo onlineuser, Userinfo becaredUser) {
		UserCare userCare = new UserCare();
		userCare.setBeCaredUserid(becaredUser.getUserid());
		userCare.setUserid(onlineuser.getUserid());
		userCare.setDate(new Date());
		userCare.setRowguid(UUID.randomUUID().toString());
		if (userCareMapper.insert(userCare) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean notCareForUser(Userinfo onlineuser, Userinfo becaredUser) {
		UserCareExample example = new UserCareExample();
		example.createCriteria().andBeCaredUseridEqualTo(becaredUser.getUserid())
				.andUseridEqualTo(onlineuser.getUserid());
		if (userCareMapper.deleteByExample(example) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean isCareFor(Userinfo onlineuser, Userinfo becaredUser) {
		UserCareExample example = new UserCareExample();
		example.createCriteria().andBeCaredUseridEqualTo(becaredUser.getUserid())
				.andUseridEqualTo(onlineuser.getUserid());
		List<UserCare> list = userCareMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updateUserInfo(Userinfo onlineuser) {
		UserinfoExample example = new UserinfoExample();
		example.createCriteria().andUseridEqualTo(onlineuser.getUserid());
		if (userinfoMapper.updateByExample(onlineuser, example) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean sendLetter(Letter letter) {
		
		if(letterMapper.insert(letter) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<Map<String, Object>> getCareUser(String userid) {
		String sql = "select a.be_cared_userid,b.username from user_care a "
				+ " left join userinfo b on a.be_cared_userid = b.userid"
				+ "  where a.userid=?";
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, userid);
		for (Map<String, Object> map : list) {
			
			if (redisTemplate.opsForValue().get("online_"+map.get("username")) != null) {
				map.put("ifonline",1);
			}else{
				map.put("ifonline", 0);
			}
			
		}
		return list;
	}

	@Override
	public List<Letter> getLetterByUser(Integer start, Integer size, String username) {
		LetterExample example = new LetterExample();
		example.setOrderByClause(" creatdate desc limit "+start + ","+size);
		example.createCriteria().andToUserEqualTo(username);
		return letterMapper.selectByExample(example);
	}

	@Override
	public long countLetter(String username) {
		LetterExample example = new LetterExample();
		example.createCriteria().andToUserEqualTo(username).andIsBackEqualTo(0);
		return letterMapper.countByExample(example);
	}

	@Override
	public void backLetter(Letter letter) {
		LetterExample example = new LetterExample();
		example.createCriteria().andRowguidEqualTo(letter.getRowguid());
		letter.setIsBack(1);
		letterMapper.updateByExampleSelective(letter, example);
		
	}

	@Override
	public Letter getletterById(String letterguid) {
		LetterExample example = new LetterExample();
		example.createCriteria().andRowguidEqualTo(letterguid);
		List<Letter> list = letterMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}
}
