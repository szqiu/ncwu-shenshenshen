package com.shenshenshen.ncwuwdsq.config;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * @author 申中秋
 * @date 2019年4月27日下午2:53:56
 */
@Component
public class StopShenshenshen implements DisposableBean,ExitCodeGenerator{
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	@Override
	public int getExitCode() {
		
		return 5;
	}
	@Override
	public void destroy() throws Exception {
		stringRedisTemplate.opsForValue().set("close", "aaa");
		System.out.println("sssss");
		
	}

}
