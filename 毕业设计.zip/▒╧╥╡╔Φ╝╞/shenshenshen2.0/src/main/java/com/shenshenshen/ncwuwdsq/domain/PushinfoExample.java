package com.shenshenshen.ncwuwdsq.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PushinfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public PushinfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andPushidIsNull() {
            addCriterion("pushid is null");
            return (Criteria) this;
        }

        public Criteria andPushidIsNotNull() {
            addCriterion("pushid is not null");
            return (Criteria) this;
        }

        public Criteria andPushidEqualTo(String value) {
            addCriterion("pushid =", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidNotEqualTo(String value) {
            addCriterion("pushid <>", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidGreaterThan(String value) {
            addCriterion("pushid >", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidGreaterThanOrEqualTo(String value) {
            addCriterion("pushid >=", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidLessThan(String value) {
            addCriterion("pushid <", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidLessThanOrEqualTo(String value) {
            addCriterion("pushid <=", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidLike(String value) {
            addCriterion("pushid like", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidNotLike(String value) {
            addCriterion("pushid not like", value, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidIn(List<String> values) {
            addCriterion("pushid in", values, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidNotIn(List<String> values) {
            addCriterion("pushid not in", values, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidBetween(String value1, String value2) {
            addCriterion("pushid between", value1, value2, "pushid");
            return (Criteria) this;
        }

        public Criteria andPushidNotBetween(String value1, String value2) {
            addCriterion("pushid not between", value1, value2, "pushid");
            return (Criteria) this;
        }

        public Criteria andFromUserIsNull() {
            addCriterion("from_user is null");
            return (Criteria) this;
        }

        public Criteria andFromUserIsNotNull() {
            addCriterion("from_user is not null");
            return (Criteria) this;
        }

        public Criteria andFromUserEqualTo(String value) {
            addCriterion("from_user =", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserNotEqualTo(String value) {
            addCriterion("from_user <>", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserGreaterThan(String value) {
            addCriterion("from_user >", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserGreaterThanOrEqualTo(String value) {
            addCriterion("from_user >=", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserLessThan(String value) {
            addCriterion("from_user <", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserLessThanOrEqualTo(String value) {
            addCriterion("from_user <=", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserLike(String value) {
            addCriterion("from_user like", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserNotLike(String value) {
            addCriterion("from_user not like", value, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserIn(List<String> values) {
            addCriterion("from_user in", values, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserNotIn(List<String> values) {
            addCriterion("from_user not in", values, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserBetween(String value1, String value2) {
            addCriterion("from_user between", value1, value2, "fromUser");
            return (Criteria) this;
        }

        public Criteria andFromUserNotBetween(String value1, String value2) {
            addCriterion("from_user not between", value1, value2, "fromUser");
            return (Criteria) this;
        }

        public Criteria andToUserIsNull() {
            addCriterion("to_user is null");
            return (Criteria) this;
        }

        public Criteria andToUserIsNotNull() {
            addCriterion("to_user is not null");
            return (Criteria) this;
        }

        public Criteria andToUserEqualTo(String value) {
            addCriterion("to_user =", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserNotEqualTo(String value) {
            addCriterion("to_user <>", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserGreaterThan(String value) {
            addCriterion("to_user >", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserGreaterThanOrEqualTo(String value) {
            addCriterion("to_user >=", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserLessThan(String value) {
            addCriterion("to_user <", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserLessThanOrEqualTo(String value) {
            addCriterion("to_user <=", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserLike(String value) {
            addCriterion("to_user like", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserNotLike(String value) {
            addCriterion("to_user not like", value, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserIn(List<String> values) {
            addCriterion("to_user in", values, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserNotIn(List<String> values) {
            addCriterion("to_user not in", values, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserBetween(String value1, String value2) {
            addCriterion("to_user between", value1, value2, "toUser");
            return (Criteria) this;
        }

        public Criteria andToUserNotBetween(String value1, String value2) {
            addCriterion("to_user not between", value1, value2, "toUser");
            return (Criteria) this;
        }

        public Criteria andMainidIsNull() {
            addCriterion("mainid is null");
            return (Criteria) this;
        }

        public Criteria andMainidIsNotNull() {
            addCriterion("mainid is not null");
            return (Criteria) this;
        }

        public Criteria andMainidEqualTo(String value) {
            addCriterion("mainid =", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidNotEqualTo(String value) {
            addCriterion("mainid <>", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidGreaterThan(String value) {
            addCriterion("mainid >", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidGreaterThanOrEqualTo(String value) {
            addCriterion("mainid >=", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidLessThan(String value) {
            addCriterion("mainid <", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidLessThanOrEqualTo(String value) {
            addCriterion("mainid <=", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidLike(String value) {
            addCriterion("mainid like", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidNotLike(String value) {
            addCriterion("mainid not like", value, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidIn(List<String> values) {
            addCriterion("mainid in", values, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidNotIn(List<String> values) {
            addCriterion("mainid not in", values, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidBetween(String value1, String value2) {
            addCriterion("mainid between", value1, value2, "mainid");
            return (Criteria) this;
        }

        public Criteria andMainidNotBetween(String value1, String value2) {
            addCriterion("mainid not between", value1, value2, "mainid");
            return (Criteria) this;
        }

        public Criteria andCreatdateIsNull() {
            addCriterion("creatdate is null");
            return (Criteria) this;
        }

        public Criteria andCreatdateIsNotNull() {
            addCriterion("creatdate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatdateEqualTo(Date value) {
            addCriterion("creatdate =", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateNotEqualTo(Date value) {
            addCriterion("creatdate <>", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateGreaterThan(Date value) {
            addCriterion("creatdate >", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateGreaterThanOrEqualTo(Date value) {
            addCriterion("creatdate >=", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateLessThan(Date value) {
            addCriterion("creatdate <", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateLessThanOrEqualTo(Date value) {
            addCriterion("creatdate <=", value, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateIn(List<Date> values) {
            addCriterion("creatdate in", values, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateNotIn(List<Date> values) {
            addCriterion("creatdate not in", values, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateBetween(Date value1, Date value2) {
            addCriterion("creatdate between", value1, value2, "creatdate");
            return (Criteria) this;
        }

        public Criteria andCreatdateNotBetween(Date value1, Date value2) {
            addCriterion("creatdate not between", value1, value2, "creatdate");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(Integer value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(Integer value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(Integer value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(Integer value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(Integer value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<Integer> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<Integer> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(Integer value1, Integer value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andPushContantIsNull() {
            addCriterion("push_contant is null");
            return (Criteria) this;
        }

        public Criteria andPushContantIsNotNull() {
            addCriterion("push_contant is not null");
            return (Criteria) this;
        }

        public Criteria andPushContantEqualTo(String value) {
            addCriterion("push_contant =", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantNotEqualTo(String value) {
            addCriterion("push_contant <>", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantGreaterThan(String value) {
            addCriterion("push_contant >", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantGreaterThanOrEqualTo(String value) {
            addCriterion("push_contant >=", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantLessThan(String value) {
            addCriterion("push_contant <", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantLessThanOrEqualTo(String value) {
            addCriterion("push_contant <=", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantLike(String value) {
            addCriterion("push_contant like", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantNotLike(String value) {
            addCriterion("push_contant not like", value, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantIn(List<String> values) {
            addCriterion("push_contant in", values, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantNotIn(List<String> values) {
            addCriterion("push_contant not in", values, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantBetween(String value1, String value2) {
            addCriterion("push_contant between", value1, value2, "pushContant");
            return (Criteria) this;
        }

        public Criteria andPushContantNotBetween(String value1, String value2) {
            addCriterion("push_contant not between", value1, value2, "pushContant");
            return (Criteria) this;
        }

        public Criteria andIsReceivedIsNull() {
            addCriterion("is_received is null");
            return (Criteria) this;
        }

        public Criteria andIsReceivedIsNotNull() {
            addCriterion("is_received is not null");
            return (Criteria) this;
        }

        public Criteria andIsReceivedEqualTo(Integer value) {
            addCriterion("is_received =", value, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedNotEqualTo(Integer value) {
            addCriterion("is_received <>", value, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedGreaterThan(Integer value) {
            addCriterion("is_received >", value, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedGreaterThanOrEqualTo(Integer value) {
            addCriterion("is_received >=", value, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedLessThan(Integer value) {
            addCriterion("is_received <", value, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedLessThanOrEqualTo(Integer value) {
            addCriterion("is_received <=", value, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedIn(List<Integer> values) {
            addCriterion("is_received in", values, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedNotIn(List<Integer> values) {
            addCriterion("is_received not in", values, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedBetween(Integer value1, Integer value2) {
            addCriterion("is_received between", value1, value2, "isReceived");
            return (Criteria) this;
        }

        public Criteria andIsReceivedNotBetween(Integer value1, Integer value2) {
            addCriterion("is_received not between", value1, value2, "isReceived");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}