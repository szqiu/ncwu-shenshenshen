package com.shenshenshen.ncwuwdsq.domain;

import java.util.Date;

public class Comment {
    private String rowguid;

    private String contant;

    private Date creatdate;

    private String creatuser;

    private String answerguid;

    private String toCommentid;

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid == null ? null : rowguid.trim();
    }

    public String getContant() {
        return contant;
    }

    public void setContant(String contant) {
        this.contant = contant == null ? null : contant.trim();
    }

    public Date getCreatdate() {
        return creatdate;
    }

    public void setCreatdate(Date creatdate) {
        this.creatdate = creatdate;
    }

    public String getCreatuser() {
        return creatuser;
    }

    public void setCreatuser(String creatuser) {
        this.creatuser = creatuser == null ? null : creatuser.trim();
    }

    public String getAnswerguid() {
        return answerguid;
    }

    public void setAnswerguid(String answerguid) {
        this.answerguid = answerguid == null ? null : answerguid.trim();
    }

    public String getToCommentid() {
        return toCommentid;
    }

    public void setToCommentid(String toCommentid) {
        this.toCommentid = toCommentid == null ? null : toCommentid.trim();
    }
}