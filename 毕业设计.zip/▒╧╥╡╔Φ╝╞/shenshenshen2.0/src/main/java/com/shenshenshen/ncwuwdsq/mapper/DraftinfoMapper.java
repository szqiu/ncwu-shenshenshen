package com.shenshenshen.ncwuwdsq.mapper;

import com.shenshenshen.ncwuwdsq.domain.Draftinfo;
import com.shenshenshen.ncwuwdsq.domain.DraftinfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DraftinfoMapper {
    int countByExample(DraftinfoExample example);

    int deleteByExample(DraftinfoExample example);

    int deleteByPrimaryKey(String draftid);

    int insert(Draftinfo record);

    int insertSelective(Draftinfo record);

    List<Draftinfo> selectByExample(DraftinfoExample example);

    Draftinfo selectByPrimaryKey(String draftid);

    int updateByExampleSelective(@Param("record") Draftinfo record, @Param("example") DraftinfoExample example);

    int updateByExample(@Param("record") Draftinfo record, @Param("example") DraftinfoExample example);

    int updateByPrimaryKeySelective(Draftinfo record);

    int updateByPrimaryKey(Draftinfo record);
}