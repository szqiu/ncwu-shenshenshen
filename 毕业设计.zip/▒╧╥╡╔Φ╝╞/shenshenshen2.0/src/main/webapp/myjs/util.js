function getPath() {
	var url = document.location.href;
	var root = url.split("/");
	return root[2]+"/"+root[3];
}