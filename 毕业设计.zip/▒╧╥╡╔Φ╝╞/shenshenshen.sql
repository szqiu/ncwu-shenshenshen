/*
Navicat MySQL Data Transfer

Source Server         : testing
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : shenshenshen

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-05-09 15:56:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for answerinfo
-- ----------------------------
DROP TABLE IF EXISTS `answerinfo`;
CREATE TABLE `answerinfo` (
  `answerid` varchar(50) NOT NULL,
  `creatuser` varchar(255) DEFAULT NULL,
  `creatdate` datetime DEFAULT NULL,
  `questionid` varchar(255) DEFAULT NULL,
  `hot` int(11) DEFAULT NULL,
  `agreenum` int(11) DEFAULT NULL,
  `againnum` int(11) DEFAULT NULL,
  `likenum` int(11) DEFAULT NULL,
  `contant` text,
  `commentnum` int(11) DEFAULT NULL,
  `is_draft` int(2) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of answerinfo
-- ----------------------------
INSERT INTO `answerinfo` VALUES ('96c69a38-c4fe-4393-8463-90b29a3e3ff0', '加菲猫', '2019-04-24 21:02:38', '2ab46893-acaa-45f7-bbfb-33328aa38c3a', '527', '71', '27', '7', '按时大苏打<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/48.gif\" alt=\"[伤心]\">', '3', '0');
INSERT INTO `answerinfo` VALUES ('ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-24 21:04:17', '61c61fb7-b7e4-472b-87b2-74af4db7c213', '715', '102', '16', '15', '按时大苏打按时大苏打<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">啊', '1', '0');
INSERT INTO `answerinfo` VALUES ('505bbe4d-dff6-4321-9927-9c7d13eb0dff', '加菲猫', '2019-04-24 21:10:33', 'ecd660d8-368e-4b6d-930a-0af8f636d41b', '44', '2', '1', '1', '<p>146665‘；；；了解客户开具根据国家和国际</p><p><img src=\"/shenshenshen/upload/1e13db13-5792-42.gif\" alt=\"1e13db13-5792-42\"><br></p><p><br></p>', '3', '0');
INSERT INTO `answerinfo` VALUES ('f63762f6-de9b-4805-a6a6-b3b3a4434648', '加菲猫', '2019-04-24 21:12:33', '4ae2299b-5c0f-4f72-8cd7-9a9e78c8ef14', '76', '14', '2', '0', '<p>7778888哦哦哦刚好经过加工后</p><p>官方合法合规</p><p>控件</p><p><img src=\"/shenshenshen/upload/cf4c96de-18cf-4d.png\" alt=\"cf4c96de-18cf-4d\"><br></p>', '0', '0');
INSERT INTO `answerinfo` VALUES ('5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '加菲猫', '2019-04-24 21:14:42', '39751e7d-ee99-48f3-9461-aeac020795d3', '25', '5', '0', '0', '<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\"><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/63.gif\" alt=\"[给力]\"><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/0.gif\" alt=\"[微笑]\"><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/2.gif\" alt=\"[哈哈]\">', '0', '0');
INSERT INTO `answerinfo` VALUES ('28a3cca4-bc71-4a12-bece-7847570edfb7', 'shenshenshen', '2019-04-25 18:35:00', 'c887f09f-3834-49b1-acc2-5441992b93a7', '80', '16', '0', '0', 'aaaaaaaa<img alt=\"[鼓掌]\" src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/39.gif\">', '0', '0');
INSERT INTO `answerinfo` VALUES ('ee296d46-a18f-4573-bb35-156e84637712', '加菲猫', '2019-04-26 16:11:48', '2ab46893-acaa-45f7-bbfb-33328aa38c3a', '78', '1', '2', '6', '啊是大啊是大', '1', '0');
INSERT INTO `answerinfo` VALUES ('e51267d7-2fe6-461f-a248-aea6b7c202f5', '加菲猫', '2019-04-29 09:19:02', '39751e7d-ee99-48f3-9461-aeac020795d3', '0', '0', '0', '0', '中心城中心', '0', '0');
INSERT INTO `answerinfo` VALUES ('a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '加菲猫', '2019-04-29 09:26:41', '3380a568-c866-45a5-8537-dac3d69abec3', '133', '26', '1', '0', '啊是擦是', '0', '0');
INSERT INTO `answerinfo` VALUES ('ce5a78c8-1e80-4a19-816e-2368a1a682ab', '加菲猫', '2019-05-03 18:51:47', '9a5aef04-96ba-4a05-8740-f2ed7c496390', '684', '56', '2', '37', '那你<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/50.gif\" alt=\"[熊猫]\">', '4', '0');
INSERT INTO `answerinfo` VALUES ('fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '加菲猫', '2019-05-03 19:18:18', '654338eb-91fa-4b02-8389-7f922a3c3d53', '282', '3', '2', '24', '阿三', '3', '0');
INSERT INTO `answerinfo` VALUES ('6a33608e-1e74-443e-87b5-4a31234e742c', '阿菲菲', '2019-05-03 19:19:56', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '64', '4', '1', '2', '阿三', '3', '0');
INSERT INTO `answerinfo` VALUES ('f254fed0-7f9a-4f74-8c67-f49ea329531f', '阿菲菲', '2019-05-03 19:28:27', '9c6345d3-8721-4177-8669-5900e860f893', '8', '1', '1', '0', '啊啊啊的', '0', '0');
INSERT INTO `answerinfo` VALUES ('57a3f71b-a945-4ae4-89ff-655b3339981a', '阿菲菲', '2019-05-03 19:28:45', '12d8dcdf-93f8-448b-8238-8138cb05a8a5', '13', '2', '1', '0', '撒旦v', '0', '0');
INSERT INTO `answerinfo` VALUES ('9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '阿菲菲', '2019-05-03 19:29:10', '62b27fb1-10bf-443f-b9b9-81afcfdc3ecb', '123', '22', '1', '1', '啊是擦', '0', '0');
INSERT INTO `answerinfo` VALUES ('08fcf5d1-0442-4b48-809d-82d6211bcfa6', '阿菲菲', '2019-05-04 11:07:07', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '62', '1', '1', '4', '杀杀杀', '2', '0');
INSERT INTO `answerinfo` VALUES ('b5bdc021-ca35-44da-923e-a11e0f9d5706', '加菲猫', '2019-05-04 11:12:17', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '62', '1', '1', '4', 'asda&nbsp;', '2', '0');
INSERT INTO `answerinfo` VALUES ('e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '阿菲菲', '2019-05-04 11:20:12', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '53', '10', '1', '0', '啊', '0', '0');
INSERT INTO `answerinfo` VALUES ('e1648ec0-5a2f-45cd-a9b4-653662488995', '阿菲菲', '2019-05-04 11:20:36', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '13', '2', '1', '0', '嗷嗷', '0', '0');
INSERT INTO `answerinfo` VALUES ('bfd642fe-28d7-4fa2-9921-f971e620a080', '阿菲菲', '2019-05-04 11:20:53', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '633', '122', '2', '1', '阿三', '1', '0');
INSERT INTO `answerinfo` VALUES ('a8b99812-0bb3-43c7-831e-bda9a7cf1ead', '阿菲菲', '2019-05-04 11:30:41', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '0', '0', '0', '0', '执行', '0', '0');
INSERT INTO `answerinfo` VALUES ('380045ae-5f9f-4009-b818-daedf5adc931', '阿菲菲', '2019-05-04 11:33:27', 'f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '8', '1', '1', '0', '自行车', '0', '0');
INSERT INTO `answerinfo` VALUES ('23290b33-8fc4-496b-a261-2d3d1368037b', '阿菲菲', '2019-05-04 13:46:55', '437da0bb-56bb-4b26-ae58-0ae0f60f9cae', '36', '2', '2', '2', '啊是大', '0', '0');
INSERT INTO `answerinfo` VALUES ('b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 13:49:17', '29c64f35-071d-4f7e-8fd0-62537c4a8405', '691', '1', '1', '41', '看看', '39', '0');
INSERT INTO `answerinfo` VALUES ('7b12111b-0ae9-4965-b049-52a10e97e34f', '阿菲菲', '2019-05-05 19:19:26', '29c64f35-071d-4f7e-8fd0-62537c4a8405', '35', '1', '1', '2', '阿三打撒', '1', '0');
INSERT INTO `answerinfo` VALUES ('96f6fc1e-d3e5-46b9-9608-93ac676e77dd', '阿菲菲', '2019-05-07 09:32:25', '33d20f62-384d-482e-a2d4-84e0bf5cf899', '0', '0', '0', '0', '啊是擦的', '0', '0');
INSERT INTO `answerinfo` VALUES ('f1527a22-cc55-4ea2-94d7-df5d2fe4114b', '阿菲菲', '2019-05-07 09:32:51', '33d20f62-384d-482e-a2d4-84e0bf5cf899', '0', '0', '0', '0', '啊是大', '0', '0');
INSERT INTO `answerinfo` VALUES ('eb83d74f-5387-4525-addb-efcde4e18266', '阿菲菲', '2019-05-08 14:32:09', '29c64f35-071d-4f7e-8fd0-62537c4a8405', '0', '0', '0', '0', '新城大厦v但是', '0', '0');
INSERT INTO `answerinfo` VALUES ('caf9e628-b02e-4f03-a1c1-b6fa5d446744', '阿菲菲', '2019-05-07 13:46:15', '29c64f35-071d-4f7e-8fd0-62537c4a8405', '20', '0', '0', '2', '啊我去上的', '0', '0');
INSERT INTO `answerinfo` VALUES ('80ae0b1e-4fd0-4f69-99c4-9bbd3fd8c661', '阿菲菲', '2019-05-07 13:46:31', '29c64f35-071d-4f7e-8fd0-62537c4a8405', '20', '0', '0', '2', '说的', '0', '0');
INSERT INTO `answerinfo` VALUES ('a81b9581-2fef-48cf-97f1-3806a4d00b56', '阿菲菲', '2019-05-08 14:22:52', '29c64f35-071d-4f7e-8fd0-62537c4a8405', '0', '0', '0', '0', '啊是大阿斯顿擦拭的', '0', '1');
INSERT INTO `answerinfo` VALUES ('64d9bf39-4334-4e4e-98a6-bcdcc5427aea', '阿菲菲', '2019-05-08 14:25:27', '437da0bb-56bb-4b26-ae58-0ae0f60f9cae', '0', '0', '0', '0', '按时大苏打大苏打飒飒打撒打撒阿斯顿发射点咋说', '0', '0');
INSERT INTO `answerinfo` VALUES ('6b46ed87-c502-4b6d-9d27-8ecd62a1a562', '阿菲菲', '2019-05-08 14:22:12', '29c64f35-071d-4f7e-8fd0-62537c4a8405', '0', '0', '0', '0', '<p>觉得高房价的方式打开链接但是看见</p><p>地方大师傅大锅饭大锅饭是</p><p>的反对广泛受到广泛大锅饭</p>', '0', '1');
INSERT INTO `answerinfo` VALUES ('2cb80a06-9873-4d4f-8c6d-0f5a4e72b426', '阿菲菲', '2019-05-08 14:24:54', '52da7601-d30b-45fc-8918-35a67c2c4d62', '0', '0', '0', '0', '啊实打实大苏打撒旦大神按时大苏打', '0', '1');
INSERT INTO `answerinfo` VALUES ('c964cc38-071a-4e43-a872-2f03258791d3', '阿菲菲', '2019-05-08 14:30:50', '52da7601-d30b-45fc-8918-35a67c2c4d62', '0', '0', '0', '0', '阿斯顿发射点按时大苏打按时大苏打', '0', '1');
INSERT INTO `answerinfo` VALUES ('7b8ba33d-7936-44f6-90eb-a51d0e290e37', '阿菲菲', '2019-05-08 14:31:38', '52da7601-d30b-45fc-8918-35a67c2c4d62', '0', '0', '0', '0', '啊实打实大苏打啊是大阿三打撒阿三打撒', '0', '1');
INSERT INTO `answerinfo` VALUES ('e4c3bcdc-7596-4e5d-859d-bb87884f0194', '阿菲菲', '2019-05-08 14:32:37', '52da7601-d30b-45fc-8918-35a67c2c4d62', '0', '0', '0', '0', '<p>啊实打实大苏打撒旦</p><p>啊是大</p><p>按时大苏打</p>', '0', '1');
INSERT INTO `answerinfo` VALUES ('97773900-2b4c-4d34-b1da-aaf2ffb126e6', '阿菲菲', '2019-05-08 14:33:46', '52da7601-d30b-45fc-8918-35a67c2c4d62', '0', '0', '0', '0', '阿萨十大大苏打实打实啊是大是', '0', '1');
INSERT INTO `answerinfo` VALUES ('2109d820-26f3-4969-a6e7-e6caf0c80680', '阿菲菲', '2019-05-08 14:38:55', '52da7601-d30b-45fc-8918-35a67c2c4d62', '0', '0', '0', '0', '按时大苏打', '0', '1');
INSERT INTO `answerinfo` VALUES ('2be58751-aa34-4e4f-9740-47f7589f28fe', '阿菲菲', '2019-05-08 14:53:11', '52da7601-d30b-45fc-8918-35a67c2c4d62', '0', '0', '0', '0', '啊实打实大苏打阿三打撒按时大苏打', '0', '0');

-- ----------------------------
-- Table structure for articleinfo
-- ----------------------------
DROP TABLE IF EXISTS `articleinfo`;
CREATE TABLE `articleinfo` (
  `articleid` varchar(255) NOT NULL,
  `contant` text,
  `creatdate` datetime DEFAULT NULL,
  `creatuser` varchar(255) DEFAULT NULL,
  `hot` int(11) DEFAULT NULL,
  `likenum` int(11) DEFAULT NULL,
  `hatenum` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `agreenum` int(11) DEFAULT NULL,
  `is_draft` int(2) DEFAULT '0',
  `commentnum` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of articleinfo
-- ----------------------------
INSERT INTO `articleinfo` VALUES ('b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '<p>这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年</p>', '2019-04-19 14:12:08', '加菲猫', '1152', '26', '58', '<b>阿三发射点</b>', '28', '0', '23');
INSERT INTO `articleinfo` VALUES ('28d7d198-f6bc-40f4-937a-bc3bde235280', '<p>这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年</p>', '2019-04-19 14:12:29', '加菲猫', '8', '0', '1', '<b>阿三发射点2</b>', '1', '0', '0');
INSERT INTO `articleinfo` VALUES ('a639c2d9-942c-414b-9422-5e6f15a6400f', '<p>这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年</p>', '2019-04-19 14:12:36', '加菲猫', '49', '1', '4', '<b>阿三发射点3</b>', '4', '0', '1');
INSERT INTO `articleinfo` VALUES ('459af1f1-a907-4800-8d62-3a5824d9f913', '<p>这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年</p>', '2019-04-19 14:12:43', '加菲猫', '8', '0', '1', '<b>阿三发射点4</b>', '1', '0', '0');
INSERT INTO `articleinfo` VALUES ('a97ee283-c951-44b2-bdd0-c5b022c8baea', '<p>这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年这是阿斯顿你疯啦三年</p>', '2019-04-19 14:12:47', '加菲猫', '25', '1', '1', '<b>阿三发射点5</b>', '1', '0', '1');
INSERT INTO `articleinfo` VALUES ('4e6a1ad1-16bb-419c-ba33-4a05ae33e91d', '<p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>v按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>按时大苏打实打实大苏打</p><p>vvvvv</p>', '2019-04-19 15:11:38', '加菲猫', '0', '0', '0', '啊啊啊啊', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('623767d0-5f15-404e-8dfa-fb739c21fa36', '按时大苏打', '2019-04-19 15:13:54', '加菲猫', '0', '0', '0', '啊撒打算', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('c558076d-e133-4a2e-b493-9bec571216b1', '按时大苏打按时大苏打', '2019-04-19 15:14:04', '加菲猫', '0', '0', '0', '啊撒打算', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('8e87b24f-1234-475c-b913-9d154d740912', '威威3333333', '2019-04-19 15:15:51', '加菲猫', '0', '0', '0', '啊是大', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('4669bc01-e935-4e69-a4e8-e202b7e4ff4e', '<p>阿斯顿发射点发生阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫阿斯顿发射点发生我打发士大夫士大夫v</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p>阿斯顿发射点发生我打发士大夫士大夫</p><p><img src=\"/shenshenshen/upload/db28637e-ba6f-40.png\" alt=\"db28637e-ba6f-40\"><br></p>', '2019-04-19 20:55:18', '加菲猫', '8', '0', '1', '<p>阿斯顿发射点发生我打发士大夫士大夫</p>', '1', '0', '0');
INSERT INTO `articleinfo` VALUES ('e74b29ac-9e5b-4b29-b04d-51ea05f430d4', '<p>Map&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; mapMap&lt;String, Object&gt; map擦手纸的v产生的</p>', '2019-04-19 21:38:20', '加菲猫', '0', '0', '0', '按时大苏打', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('97d3b3b2-3d83-4278-a710-184b612e12cf', '<p>p擦手纸的v产生的自行p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大p擦手纸的v产生的自行车自行车按时大苏打按时大苏打啊是大啊哇撒撒旦啊是大苏打按时大苏打啊是大啊哇撒撒旦啊是大&nbsp;</p><p><img src=\"/shenshenshen/upload/4191e259-388b-4b.gif\" alt=\"4191e259-388b-4b\"><br></p>', '2019-04-20 12:27:24', '加菲猫', '0', '0', '0', '按时大苏打', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('72c32729-3b40-4558-9ba7-788f5149de49', '啊啊啊啊阿萨德', '2019-04-20 12:27:41', '加菲猫', '0', '0', '0', '啊啊啊', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('af879c30-124d-4b7e-af25-afb751f037ad', '<p><br></p><p>啊实打实大苏打按时大苏打嗷嗷、</p><p><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/20.gif\" alt=\"[嘘]\"><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/21.gif\" alt=\"[衰]\"><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/33.gif\" alt=\"[睡]\"><br></p>', '2019-04-20 12:43:49', '加菲猫', '0', '0', '0', '按时大苏打', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('fd81ac28-d69b-437b-88f2-abc5ff02d08e', '按时大苏打', '2019-04-20 12:43:06', '加菲猫', '0', '0', '0', '按时大苏打', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('82e1d40e-2f6d-4c95-9aba-e1e94df33ffd', '<p>asdasd asdasd&nbsp;</p>', '2019-04-20 17:21:31', '加菲猫', '0', '0', '0', 'asda&nbsp;', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('e2626f4c-3179-45e2-ae34-5df19d8ece30', 'asdasd&nbsp;', '2019-04-20 17:21:21', '加菲猫', '526', '26', '2', 'asdasd&nbsp;', '2', '0', '3');
INSERT INTO `articleinfo` VALUES ('38ebb34b-71d1-492a-a786-f407fc8b1388', '<p>ss按时大苏打按时大苏打</p><p><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/62.gif\" alt=\"[浮云]\"><br></p><p><img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/63.gif\" alt=\"[给力]\"><br></p>', '2019-04-24 18:05:39', '加菲猫', '8', '0', '1', 'xdxd按时大苏打', '1', '0', '0');
INSERT INTO `articleinfo` VALUES ('39677e8c-f435-4f36-9f41-444e7473c45d', '是当天发生手动阀手动阀按时大苏打啊是大啊', '2019-04-26 16:28:51', '加菲猫', '0', '0', '0', 'Deere', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('1b085133-b37e-44f6-8dda-52bf5205dc77', 'ascasc&nbsp;', '2019-05-04 14:57:04', '加菲猫', '8', '0', '1', 'zxc&nbsp;', '1', '0', '0');
INSERT INTO `articleinfo` VALUES ('c5db833c-5f27-44a5-a7cd-0307e9dd3050', 'asdas', '2019-05-04 15:33:50', '加菲猫', '8', '0', '1', 'asdas&nbsp;', '1', '0', '0');
INSERT INTO `articleinfo` VALUES ('bd359937-76a2-4685-a12b-291dbd0525f2', '啊是大自行车自行车', '2019-05-07 09:40:20', '阿菲菲', '8', '0', '1', '啊是大', '1', '0', '0');
INSERT INTO `articleinfo` VALUES ('851fea3c-7ace-4f83-bdaf-72cb03b400ec', '啊是大', '2019-05-08 14:32:05', '阿菲菲', '0', '0', '0', '啊是大', '0', '0', '0');
INSERT INTO `articleinfo` VALUES ('82d19fa0-1c90-4998-8bef-9cee2b3f34f8', 'aaaaaa', '2019-05-07 15:02:44', '加菲猫', '35', '1', '1', 'aaaaa', '1', '0', '2');

-- ----------------------------
-- Table structure for article_comment
-- ----------------------------
DROP TABLE IF EXISTS `article_comment`;
CREATE TABLE `article_comment` (
  `rowguid` varchar(255) NOT NULL,
  `creatuser` varchar(255) DEFAULT NULL,
  `creatdate` datetime DEFAULT NULL,
  `articleguid` varchar(255) DEFAULT NULL,
  `contant` varchar(255) DEFAULT NULL,
  `to_commentid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of article_comment
-- ----------------------------
INSERT INTO `article_comment` VALUES ('0ca76bfe-166a-441e-b56b-54e6388e234f', '加菲猫', '2019-04-26 17:27:40', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '按时大苏打', null);
INSERT INTO `article_comment` VALUES ('4cf3ca74-1a62-4c11-adcd-2a18b80beb2d', '加菲猫', '2019-04-26 17:27:55', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '热尔侮辱他为人', null);
INSERT INTO `article_comment` VALUES ('177d06b6-2743-4071-9d7c-f08e0c9c1ef1', '加菲猫', '2019-04-26 17:28:01', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '阿三打撒', null);
INSERT INTO `article_comment` VALUES ('5a4c75c6-16fc-4898-9e4e-69b651d78662', '加菲猫', '2019-04-26 17:28:41', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '使得否', null);
INSERT INTO `article_comment` VALUES ('d78573ef-4966-4953-88f3-ae304a2ff896', '加菲猫', '2019-04-26 17:35:38', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '阿斯顿发射点', null);
INSERT INTO `article_comment` VALUES ('93f93b05-cc5d-47eb-9d50-bfad61ed798f', '加菲猫', '2019-04-26 17:35:41', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '按时大苏打', null);
INSERT INTO `article_comment` VALUES ('261c108d-000a-492b-960a-a0428f0a0632', '加菲猫', '2019-04-26 19:08:37', 'a639c2d9-942c-414b-9422-5e6f15a6400f', '阿三', null);
INSERT INTO `article_comment` VALUES ('1f763d7d-5c8e-4b3f-8989-43b2aac5e670', '阿菲菲', '2019-05-04 15:36:27', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', 'kk', null);
INSERT INTO `article_comment` VALUES ('73654563-263e-4147-80d0-e03702164aef', '阿菲菲', '2019-05-04 15:55:18', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '啊是大', null);
INSERT INTO `article_comment` VALUES ('d4c7d3dc-b5c7-4ffa-9558-080067094d67', '阿菲菲', '2019-05-04 16:02:48', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '阿三', null);
INSERT INTO `article_comment` VALUES ('267a30fb-a5b9-4dd6-904c-a13ae1ede05d', '阿菲菲', '2019-05-05 08:28:15', 'a97ee283-c951-44b2-bdd0-c5b022c8baea', '哈哈', null);
INSERT INTO `article_comment` VALUES ('47431fab-4a7e-4320-962a-e293e2823903', '阿菲菲', '2019-05-07 08:55:16', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', 'hello', null);
INSERT INTO `article_comment` VALUES ('a5db737d-f608-4368-b71c-2ee519602cde', '阿菲菲', '2019-05-07 14:57:32', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '', null);
INSERT INTO `article_comment` VALUES ('b409de8e-6a2a-46cb-b83e-a8743d2fe7c3', '阿菲菲', '2019-05-07 14:59:43', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '', null);
INSERT INTO `article_comment` VALUES ('8499d57f-f3ec-42b2-8f92-388d3cafa6e6', '阿菲菲', '2019-05-07 14:59:44', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '', null);
INSERT INTO `article_comment` VALUES ('7b3d0c2a-6a17-4173-8049-4a369ba48f07', '阿菲菲', '2019-05-07 15:00:19', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '', null);
INSERT INTO `article_comment` VALUES ('3fd29f80-4300-48d5-8e16-2a56f05f4a26', '阿菲菲', '2019-05-07 15:00:31', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '', null);
INSERT INTO `article_comment` VALUES ('cb695af7-2432-47e2-9945-8f1e9be85e1c', '阿菲菲', '2019-05-07 15:03:11', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8', '啊是大', null);
INSERT INTO `article_comment` VALUES ('6cc5be8c-558c-440d-9c01-1f184f72e6b2', '阿菲菲', '2019-05-07 15:03:17', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8', '啊是大', null);
INSERT INTO `article_comment` VALUES ('ae6c1080-8ee0-40af-901e-a199b9ef9915', '阿菲菲', '2019-05-08 13:13:26', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '使得否', null);
INSERT INTO `article_comment` VALUES ('ab663074-3bbf-4821-9ab0-af949fe18224', '阿菲菲', '2019-05-08 13:18:37', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '回复 <span style=\"color:blue\">阿菲菲</span>:<i>啊是大</i>', 'ae6c1080-8ee0-40af-901e-a199b9ef9915');
INSERT INTO `article_comment` VALUES ('de5706f5-fba4-4896-a313-6a6706d12412', '阿菲菲', '2019-05-08 13:18:45', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '回复 <span style=\"color:blue\">阿菲菲</span>:啊是大', 'ae6c1080-8ee0-40af-901e-a199b9ef9915');
INSERT INTO `article_comment` VALUES ('6edb1605-76da-4822-b79f-7bb46d56ec70', '加菲猫', '2019-05-08 13:38:06', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', 'asd', null);
INSERT INTO `article_comment` VALUES ('3c6816ab-02ad-4076-831d-a3a2c717ff14', '阿菲菲', '2019-05-08 13:38:14', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '阿萨十大', null);
INSERT INTO `article_comment` VALUES ('dd1b9f29-73db-4325-85f5-288c0f2373b3', '加菲猫', '2019-05-08 13:38:18', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '回复 <span style=\"color:blue\">阿菲菲</span>:asd&nbsp;', '3c6816ab-02ad-4076-831d-a3a2c717ff14');
INSERT INTO `article_comment` VALUES ('5027ff43-4ea4-4e29-a598-53ee8321213d', '阿菲菲', '2019-05-08 13:47:17', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '按时大苏打', null);
INSERT INTO `article_comment` VALUES ('4ce4fd40-35fd-43ca-bbce-8a46e566f59f', '加菲猫', '2019-05-08 13:47:21', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '回复 <span style=\"color:blue\">阿菲菲</span>:asdasdasdas', '5027ff43-4ea4-4e29-a598-53ee8321213d');
INSERT INTO `article_comment` VALUES ('e5ef9de0-a37e-442a-9cd9-68ba30e4f805', '阿菲菲', '2019-05-09 14:15:46', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '按时大苏打', null);
INSERT INTO `article_comment` VALUES ('dc97b18a-f9e6-48f5-930f-c07380348b1b', '加菲猫', '2019-05-09 14:16:49', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '回复 <span style=\"color:blue\">阿菲菲</span>:asdas&nbsp;', 'e5ef9de0-a37e-442a-9cd9-68ba30e4f805');
INSERT INTO `article_comment` VALUES ('4b460d7e-32fe-4026-8066-fa4c099f5ec1', '加菲猫', '2019-05-09 14:18:58', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '回复 <span style=\"color:blue\">阿菲菲</span>:asdas&nbsp;', 'e5ef9de0-a37e-442a-9cd9-68ba30e4f805');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `rowguid` varchar(255) DEFAULT NULL,
  `contant` varchar(500) DEFAULT NULL,
  `creatdate` datetime DEFAULT NULL,
  `creatuser` varchar(255) DEFAULT NULL,
  `answerguid` varchar(255) DEFAULT NULL,
  `to_commentid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('574f7717-d3f5-46a8-a436-8622a3e5f7b0', '222555', '2019-04-24 21:10:45', '加菲猫', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', null);
INSERT INTO `comment` VALUES ('79d2c885-99f5-4ba9-8c12-3cf4024d94c8', '44545', '2019-04-24 21:13:07', '加菲猫', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', null);
INSERT INTO `comment` VALUES ('bce1749c-4b25-4ae4-a84c-57a6bb2c7949', '按时大苏打', '2019-04-25 18:28:00', '加菲猫', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', null);
INSERT INTO `comment` VALUES ('2afabc7e-2011-404e-80ad-e0d18e3915e1', '阿斯蒂芬', '2019-04-26 14:23:41', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', null);
INSERT INTO `comment` VALUES ('bd512084-9e54-43ef-bb67-41dac0697091', '啊是大', '2019-04-26 16:11:35', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', null);
INSERT INTO `comment` VALUES ('1b9dbe6e-d36b-4504-b21e-b4531af3b6b1', '啊啊啊啊啊啊啊', '2019-04-26 16:27:53', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', null);
INSERT INTO `comment` VALUES ('c5d5afbc-e3b4-476b-bcff-b3c2c405ac5a', '啊是大', '2019-04-26 17:28:11', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', null);
INSERT INTO `comment` VALUES ('54683859-2f56-4f37-981d-40a4287453ce', '吱吱吱吱', '2019-04-29 09:18:52', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', null);
INSERT INTO `comment` VALUES ('21a07b2d-181e-4722-b791-febf47428a0d', '阿三', '2019-05-03 19:09:55', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', null);
INSERT INTO `comment` VALUES ('e2edcc26-5169-4324-8418-b546699adfcf', '啊是擦', '2019-05-03 19:56:39', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', null);
INSERT INTO `comment` VALUES ('0b04fe72-bd40-495c-8941-e15ae90461ab', '阿三', '2019-05-03 20:04:13', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', null);
INSERT INTO `comment` VALUES ('46ee599f-01f6-4ae2-9af5-7ac3ce4af229', '啊是大&nbsp;', '2019-05-03 20:05:17', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', null);
INSERT INTO `comment` VALUES ('a32d922f-4737-45ad-aea1-605d068d4556', '速度', '2019-05-03 20:06:33', '阿菲菲', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', null);
INSERT INTO `comment` VALUES ('2f2ad0b6-748e-4f70-ab53-48bae0c5af19', '杀杀杀', '2019-05-04 10:49:35', '阿菲菲', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', null);
INSERT INTO `comment` VALUES ('369eb862-8411-4d16-af2e-c3583ee95646', 'vv&nbsp;', '2019-05-04 10:49:50', '阿菲菲', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', null);
INSERT INTO `comment` VALUES ('07ab5fc7-c7aa-4f51-8c7b-a81a854725f2', 'cc', '2019-05-04 10:50:00', '加菲猫', '6a33608e-1e74-443e-87b5-4a31234e742c', null);
INSERT INTO `comment` VALUES ('bd694012-ed4b-45a3-8b2e-c2078d41fcbd', '阿三', '2019-05-04 11:12:37', '阿菲菲', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', null);
INSERT INTO `comment` VALUES ('2e623e0b-51cb-4979-8d06-f6b66ef1842d', 'mmm', '2019-05-04 11:16:25', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', null);
INSERT INTO `comment` VALUES ('a0f95d2f-1050-476a-86a4-a99a3af5622a', '<p>看看</p><p><br></p>', '2019-05-04 11:16:31', '阿菲菲', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', null);
INSERT INTO `comment` VALUES ('a102921d-04ca-45d4-acc2-478e1c88e477', 'AD&nbsp;', '2019-05-04 11:16:45', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', null);
INSERT INTO `comment` VALUES ('d12146d4-d6f1-4b59-9109-ff530faf999f', 'ASC&nbsp;', '2019-05-04 11:16:49', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', null);
INSERT INTO `comment` VALUES ('dc10b088-1a89-4053-96e9-9986e94b3455', '密码', '2019-05-04 14:19:45', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('62aa04da-ff60-494d-972c-4623084f32b8', '啊是大', '2019-05-04 15:55:09', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', null);
INSERT INTO `comment` VALUES ('93a6788f-2be1-4dcb-b0a5-439737b712d4', '<p>酷酷酷</p><p><br></p>', '2019-05-05 12:29:17', '阿菲菲', 'ee296d46-a18f-4573-bb35-156e84637712', null);
INSERT INTO `comment` VALUES ('72fc2565-d750-4131-9c8f-4c053170d5b0', '阿三', '2019-05-05 19:17:06', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('ae6fcf8b-af9d-4939-9b44-ed7e26a2e9a0', '阿三', '2019-05-05 19:19:35', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', null);
INSERT INTO `comment` VALUES ('87af8624-b498-4312-bafa-45fd704680f1', 'asd&nbsp;', '2019-05-07 13:47:32', '加菲猫', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', null);
INSERT INTO `comment` VALUES ('00627e14-1731-4c1f-9df2-0d8c6b4316ea', '啊', '2019-05-07 14:02:19', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('ff3447ca-5bc6-4c64-982c-4c3ab8c285c1', '啊是大', '2019-05-07 14:02:29', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', null);
INSERT INTO `comment` VALUES ('ef2dfd80-4eba-4471-926c-0e91fd8c6ea0', '回复加菲猫:asd&nbsp;', '2019-05-07 14:31:39', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'ef2dfd80-4eba-4471-926c-0e91fd8c6ea0');
INSERT INTO `comment` VALUES ('53ac54d3-ea8e-44e1-8c4b-b62c6400e33d', '回复加菲猫:<br>', '2019-05-07 14:31:45', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '53ac54d3-ea8e-44e1-8c4b-b62c6400e33d');
INSERT INTO `comment` VALUES ('ec8a0057-3882-4ff5-b5ad-27b596fd2a83', '回复加菲猫:<br>', '2019-05-07 14:31:47', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'ec8a0057-3882-4ff5-b5ad-27b596fd2a83');
INSERT INTO `comment` VALUES ('f2c30a17-4335-498f-84bd-ac64567d6425', '回复阿菲菲:<br>', '2019-05-07 14:34:16', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'f2c30a17-4335-498f-84bd-ac64567d6425');
INSERT INTO `comment` VALUES ('274e5a1d-3b02-4216-94a7-a85d88d17193', '回复阿菲菲:<br>', '2019-05-07 14:34:22', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '274e5a1d-3b02-4216-94a7-a85d88d17193');
INSERT INTO `comment` VALUES ('bd9f2452-22ba-4392-ba37-78c2387257bf', '回复阿菲菲:<br>', '2019-05-07 14:34:23', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'bd9f2452-22ba-4392-ba37-78c2387257bf');
INSERT INTO `comment` VALUES ('ef8d3fb0-996a-4292-995b-64ecf41dab04', '回复阿菲菲:<br>', '2019-05-07 14:34:24', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'ef8d3fb0-996a-4292-995b-64ecf41dab04');
INSERT INTO `comment` VALUES ('8217a86c-7df2-4891-a920-a34ba9f648c5', '回复阿菲菲:啊是大啊', '2019-05-07 14:34:53', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '8217a86c-7df2-4891-a920-a34ba9f648c5');
INSERT INTO `comment` VALUES ('7bd557a8-d824-476f-b3a1-61d95e541e13', '回复加菲猫:啊是大', '2019-05-07 14:35:07', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '7bd557a8-d824-476f-b3a1-61d95e541e13');
INSERT INTO `comment` VALUES ('81e073c5-a5d0-4c59-9ca3-c7593a123ec0', '回复 <span style=\"color:blue\">阿菲菲</span>:啊是大', '2019-05-07 14:37:13', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '81e073c5-a5d0-4c59-9ca3-c7593a123ec0');
INSERT INTO `comment` VALUES ('5dff42bd-7512-40ed-9910-e4e8cd352e9c', '回复 <span style=\"color:blue\">阿菲菲</span>:<br>', '2019-05-07 14:38:05', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '5dff42bd-7512-40ed-9910-e4e8cd352e9c');
INSERT INTO `comment` VALUES ('038b03e2-31bf-4574-94a3-dd0f9c2299f0', '啊是大', '2019-05-07 14:43:57', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('b672f103-bcdf-47c6-9b49-4a4c7d28623a', '回复 <span style=\"color:blue\">阿菲菲</span>:啊是大', '2019-05-07 14:45:53', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'b672f103-bcdf-47c6-9b49-4a4c7d28623a');
INSERT INTO `comment` VALUES ('30c4f2d0-e29c-49fe-ae66-b080d9ac1f0e', '回复 <span style=\"color:blue\">阿菲菲</span>:<br>', '2019-05-07 14:52:27', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '30c4f2d0-e29c-49fe-ae66-b080d9ac1f0e');
INSERT INTO `comment` VALUES ('c59b4b67-e6f4-41fc-a9cc-8092878433c3', '回复 <span style=\"color:blue\">加菲猫</span>:<br>', '2019-05-07 14:52:39', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'c59b4b67-e6f4-41fc-a9cc-8092878433c3');
INSERT INTO `comment` VALUES ('3d34c7ea-b4b6-475f-beef-c63fad2ba409', '<br>', '2019-05-07 14:52:57', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('3cf5aec9-fe08-4136-9d52-1da5ca6ba32a', '回复 <span style=\"color:blue\">加菲猫</span>:<br>', '2019-05-07 14:53:00', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '3cf5aec9-fe08-4136-9d52-1da5ca6ba32a');
INSERT INTO `comment` VALUES ('f53e8049-2a0a-4246-a8c4-e7c22d779d5a', '<br>', '2019-05-07 14:53:10', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('40e28372-ef06-42b9-8dfe-f9ccdb6142e9', '回复 <span style=\"color:blue\">加菲猫</span>:<br>', '2019-05-07 14:53:12', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '40e28372-ef06-42b9-8dfe-f9ccdb6142e9');
INSERT INTO `comment` VALUES ('54c2019f-59fe-4f83-b1a0-8d9796141123', '<br>', '2019-05-07 14:53:39', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('835a8ca6-d4bb-4ac5-8bdb-ec9850d5fd18', '<br>', '2019-05-07 14:53:41', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('f184d619-e99f-4e55-9f80-15e49476ff35', '回复 <span style=\"color:blue\">加菲猫</span>:<br>', '2019-05-07 14:53:43', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'f184d619-e99f-4e55-9f80-15e49476ff35');
INSERT INTO `comment` VALUES ('6c4f6cb9-2a4c-419d-b4f0-809000659413', '<br>', '2019-05-07 14:54:13', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('986ab360-d81b-4440-bd7d-e38f75af357d', '<br>', '2019-05-07 14:54:15', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('cc324203-a6e9-4ab6-8d0f-77f51c7f8232', '<br>', '2019-05-07 14:54:16', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('8032b611-cfe8-465a-b225-6dfee1697af2', '<br>', '2019-05-07 14:54:16', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('05335d8b-6dd0-4c00-a90a-9ed39b8172f1', '<br>', '2019-05-07 14:54:17', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('776d5002-1029-4d9f-953f-b35bd30ad89d', '<br>', '2019-05-07 14:54:18', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('78d8ea67-ca82-4b0e-896a-896017241f58', '<br>', '2019-05-07 14:54:18', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('74810009-571e-440a-b0f7-3627c2fc1434', '<br>', '2019-05-07 14:54:19', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('9050d206-976c-4b71-8668-530b31a9596e', '<br>', '2019-05-07 14:57:10', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('f3beb3a6-976f-47ee-9f3a-ffb4566bce11', '现场v', '2019-05-07 15:16:36', '阿菲菲', '0ca76bfe-166a-441e-b56b-54e6388e234f', null);
INSERT INTO `comment` VALUES ('22b9d461-292d-4437-8ebb-fda041ca231a', '现场v', '2019-05-07 15:16:37', '阿菲菲', '0ca76bfe-166a-441e-b56b-54e6388e234f', null);
INSERT INTO `comment` VALUES ('c3057278-e359-462d-8e13-3109ad190f77', '现场v', '2019-05-07 15:16:37', '阿菲菲', '0ca76bfe-166a-441e-b56b-54e6388e234f', null);
INSERT INTO `comment` VALUES ('269a019d-21ae-4c9d-988c-b4808a6d87c0', '现场v', '2019-05-07 15:16:37', '阿菲菲', '0ca76bfe-166a-441e-b56b-54e6388e234f', null);
INSERT INTO `comment` VALUES ('cd751812-301d-4543-9150-97388fef59d9', '现场v', '2019-05-07 15:16:37', '阿菲菲', '0ca76bfe-166a-441e-b56b-54e6388e234f', null);
INSERT INTO `comment` VALUES ('c63fd96c-0989-457b-9e57-107b62404c06', 'asd&nbsp;', '2019-05-08 13:31:00', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('ca6168ec-9e1a-4732-a480-c741c17d1b9d', '回复 <span style=\"color:blue\">加菲猫</span>:啊是大', '2019-05-08 13:31:46', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'ca6168ec-9e1a-4732-a480-c741c17d1b9d');
INSERT INTO `comment` VALUES ('903f832b-3b3a-4ebd-8f14-8e767cc0e215', '啊大苏打实打实下达', '2019-05-08 13:46:54', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);
INSERT INTO `comment` VALUES ('bdbe2874-7391-4143-83ef-950e0c4c40e3', '回复 <span style=\"color:blue\">阿菲菲</span>:asdas&nbsp;', '2019-05-08 13:47:04', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', 'bdbe2874-7391-4143-83ef-950e0c4c40e3');
INSERT INTO `comment` VALUES ('c20e5adc-6365-4573-afeb-179dd9ab93f9', '啊是大', '2019-05-08 14:03:52', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', null);

-- ----------------------------
-- Table structure for draftinfo
-- ----------------------------
DROP TABLE IF EXISTS `draftinfo`;
CREATE TABLE `draftinfo` (
  `draftid` varchar(255) NOT NULL,
  `type` int(11) DEFAULT NULL COMMENT '0答案1文章',
  `mainid` varchar(255) DEFAULT NULL,
  `creatuser` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`draftid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of draftinfo
-- ----------------------------
INSERT INTO `draftinfo` VALUES ('da84d9b3-56f6-4380-98a0-fa4f86d33efe', '0', '2109d820-26f3-4969-a6e7-e6caf0c80680', '阿菲菲');

-- ----------------------------
-- Table structure for letter
-- ----------------------------
DROP TABLE IF EXISTS `letter`;
CREATE TABLE `letter` (
  `rowguid` varchar(255) NOT NULL,
  `from_user` varchar(255) DEFAULT NULL,
  `to_user` varchar(255) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `creatdate` datetime DEFAULT NULL,
  `is_back` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of letter
-- ----------------------------
INSERT INTO `letter` VALUES ('8e25840c-8ae7-4abe-bbe2-2cea37335c0f', '阿菲菲', '加菲猫', '请问人情味热', '2019-05-08 16:17:23', '1');
INSERT INTO `letter` VALUES ('2df26a41-0384-4ccd-8140-e96d88aaa1ca', '加菲猫', '加菲猫', 'asdas&nbsp;', '2019-05-09 12:20:12', '1');
INSERT INTO `letter` VALUES ('2a380e41-8b68-4cba-af3b-b5228ff69ed0', '加菲猫', '加菲猫', 'asdasd&nbsp;', '2019-05-09 12:20:26', '1');
INSERT INTO `letter` VALUES ('4406be75-ef1d-47dc-b2f5-fb2dfeb77573', '加菲猫', '阿菲菲', 'asdasd&nbsp;', '2019-05-09 12:20:39', '1');
INSERT INTO `letter` VALUES ('7f67ade5-b067-46a6-b1aa-e6a00d812e5b', '阿菲菲', '加菲猫', '啊是大', '2019-05-09 14:11:35', '1');
INSERT INTO `letter` VALUES ('c5ad4745-5cdd-4e6a-b841-56a25a9a58f1', '加菲猫', '阿菲菲', 'asd&nbsp;', '2019-05-09 14:11:47', '1');
INSERT INTO `letter` VALUES ('1beab1b5-f994-4d40-b6a1-f96ff270cfe8', '阿菲菲', '加菲猫', '啊是大', '2019-05-09 15:07:00', '1');
INSERT INTO `letter` VALUES ('a00675f0-3d03-405b-beb5-cf6712f6b99f', '阿菲菲', '加菲猫', '按时大苏打', '2019-05-09 15:11:16', '1');
INSERT INTO `letter` VALUES ('15b672a7-1a0a-40c0-9ed5-367704e77e28', '加菲猫', '阿菲菲', 'asda&nbsp;', '2019-05-09 15:12:43', '0');
INSERT INTO `letter` VALUES ('45de1609-6054-4aea-9e0f-325230fecc00', '加菲猫', '阿菲菲', '11111111', '2019-05-09 15:21:46', '0');
INSERT INTO `letter` VALUES ('1c754f06-9a74-4924-bd90-69eb96cf9f0b', '加菲猫', '阿菲菲', '2222222', '2019-05-09 15:21:50', '1');
INSERT INTO `letter` VALUES ('9861b778-0692-4334-a8e5-0eb669e5ce08', '阿菲菲', '加菲猫', '按时大苏打', '2019-05-09 15:22:05', '0');
INSERT INTO `letter` VALUES ('c09a32e3-9652-46b7-a2cd-3b2bf4ae578e', '阿菲菲', '加菲猫', '啊是大', '2019-05-09 15:23:57', '0');

-- ----------------------------
-- Table structure for loginrecord
-- ----------------------------
DROP TABLE IF EXISTS `loginrecord`;
CREATE TABLE `loginrecord` (
  `rowguid` varchar(255) NOT NULL,
  `loginid` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `logindate` datetime DEFAULT NULL,
  `logoutdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of loginrecord
-- ----------------------------

-- ----------------------------
-- Table structure for pushinfo
-- ----------------------------
DROP TABLE IF EXISTS `pushinfo`;
CREATE TABLE `pushinfo` (
  `pushid` varchar(255) DEFAULT NULL,
  `from_user` varchar(255) DEFAULT NULL,
  `to_user` varchar(255) DEFAULT NULL,
  `mainid` varchar(255) DEFAULT NULL,
  `creatdate` datetime DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `push_contant` varchar(255) DEFAULT NULL,
  `is_received` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of pushinfo
-- ----------------------------
INSERT INTO `pushinfo` VALUES ('7504fadd-bca7-4a83-9bd1-451e4f39a72d', '加菲猫', '阿菲菲', 'a00582d2-8938-42af-9110-35f7ad2eb59c', '2019-04-23 19:31:53', '0', '加菲猫赞同了你在问题“当今的世界有谁完全不依赖美国？”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9c61e034-cee0-4ef9-93e3-1cdd121b785b', '加菲猫', '阿菲菲', 'a00582d2-8938-42af-9110-35f7ad2eb59c', '2019-04-23 19:31:54', '0', '加菲猫赞同了你在问题“当今的世界有谁完全不依赖美国？”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4b5ae289-a364-4d9e-a889-8908615ac41c', '加菲猫', '阿菲菲', 'a00582d2-8938-42af-9110-35f7ad2eb59c', '2019-04-23 19:31:55', '0', '加菲猫赞同了你在问题“当今的世界有谁完全不依赖美国？”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2284dedd-0415-4556-b30e-b8957f64abf5', '加菲猫', '加菲猫', '1ab4c1af-0709-46a4-a4c4-c7e89ca12cb9', '2019-04-24 18:02:13', '0', '加菲猫赞同了你在问题“瞬间大幅回升空间东方航空？”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('201a90b4-b8f6-48ab-af51-cf9622e517e1', '加菲猫', '加菲猫', '1ab4c1af-0709-46a4-a4c4-c7e89ca12cb9', '2019-04-24 18:02:13', '0', '加菲猫赞同了你在问题“瞬间大幅回升空间东方航空？”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c5049296-10e7-462b-abdc-66ba1fe31c7d', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-24 21:04:41', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2d119d60-4e5e-42d0-8c8c-6edd05df43f5', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-24 21:04:42', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1109255e-8ac9-4716-b91d-af96655033d1', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-24 21:04:42', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bdbd07c8-8dfb-4b00-9eed-2dd557c7673d', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-24 21:04:43', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d40fc052-85e9-4729-99ed-c08805f2b460', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-24 21:04:44', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('165bed56-0046-4798-a6de-94da518c04f9', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-24 21:04:45', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e8dbd7d0-f881-4dde-8d97-50888cb5b221', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-24 21:04:45', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('50b74812-1241-4f81-b5db-725717cfa3ed', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-24 21:04:45', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4afb5c5a-25ba-4288-bace-a40b409ffbbe', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-24 21:04:45', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('853ae7aa-92d4-48e1-b852-12caa6194bac', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-24 21:04:46', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0ab955e9-6f3b-4c15-88a4-8c1d3e568f6d', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-24 21:04:46', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7bfb8d2b-1495-4a73-935b-d9052ab23809', '加菲猫', '加菲猫', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', '2019-04-24 21:10:41', '0', '加菲猫赞同了你在问题“阿三打撒21阿3&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1e81e7a1-9629-41d0-bf32-685ade8b9f26', '加菲猫', '加菲猫', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', '2019-04-24 21:10:41', '0', '加菲猫赞同了你在问题“阿三打撒21阿3&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('440de5e0-9261-4ce8-8934-49323a87c9f5', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-24 21:14:09', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('208f3e3c-4019-4460-aa52-c79745df94c0', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-24 21:14:09', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4770cf93-8bdb-40cf-a3b1-b6e56417bfb0', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-24 21:14:09', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a6d086a6-d916-473b-9f66-3096ab89231b', 'shenshenshen', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-25 18:34:28', '0', 'shenshenshen赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3a4f738e-9c6a-4730-930f-c22f78ef2a1c', 'shenshenshen', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-25 18:34:34', '0', 'shenshenshen赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('74c9ad3c-00e2-414e-9a6c-74a1cdb7c19b', 'shenshenshen', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-25 18:34:38', '0', 'shenshenshen赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2072bc20-004b-4ed7-addc-1646521f1ac4', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 14:23:37', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f5a8b957-3bbb-48cc-a7ae-7401f8551f86', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('98b2e44b-a6ca-496a-b9a9-d9a0cc719d61', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('34e55868-d22f-4535-92d6-b60c466cd942', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cd1b4041-6e7c-4567-b818-87752cad044d', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bc53b0d0-f525-45f2-973f-48cd7865e54f', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:40', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('473d1d1c-1a11-4d50-ae1c-b93cbc2cc6d4', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:37:26', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bcac4beb-149f-42f4-94fc-b2f842416c5e', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:37:26', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('acb1f89c-d8a0-4bc1-adf7-e085eb6cdd1e', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:37:41', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fd616491-e410-4fc7-b711-be320cb26b20', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:38:30', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9a208a08-d900-4068-bd12-8856410d7115', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:38:30', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('62cc1ed5-9f79-47db-ab25-1f5366ce68bc', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:39:08', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ed089f74-4a51-4bbb-abfc-463aa4c39113', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:39:10', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a0d7e824-25d6-496c-a048-221e5a6f869c', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:39:14', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6d0a45bb-32da-46b6-871d-4be8b2162a94', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:05:03', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2c1e3228-0b81-471e-9df8-cbae3bbc09cd', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:05:24', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('62e574c3-5d7f-415e-84b2-4da854e4cbe5', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:06:22', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f63cf747-0a71-4549-9661-894dcb49df0b', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:11', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('384f123f-53cf-45b6-8920-66b12dc0ce39', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:11', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8be59510-4666-4e6b-a2d1-8fd65f776785', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:11', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9b25e419-1ecc-4629-aba8-6468474e5c3d', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f14e94c8-2f5b-46dd-b3d6-8a05edd3a404', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ab601001-7c26-43f2-874b-1ea9bf91e50c', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bb6d1151-f11c-4934-bf8d-7b067599bc96', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4cd66a93-f2c4-4ef9-89a4-e6fd9582e83b', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:14', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4fa09475-0e97-461f-b42e-c70dc3bbb869', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:14', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7b374044-3d27-487f-bc08-4076e3fbd487', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 14:39:53', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('48609f29-0411-44ce-b9aa-12e1a6a5bac8', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 14:39:53', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b878f0ae-66a8-493a-82d0-8abf5f42de9c', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 14:42:47', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('632d3d11-1ce8-4c9a-b8db-1f39f220f99f', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-27 14:44:24', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8d465707-e012-4bfa-99c4-f075952ff9c0', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 14:45:29', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8129c622-f9db-441c-8bfa-260cfb2fa041', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 19:36:51', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bdd95380-8413-417f-9378-ccdeec24f4df', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('76894313-a054-4691-b0ef-5d74bc0cda97', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('91196ef6-4122-42d4-a33c-993b3a50f474', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0fdb0239-3897-44de-a76b-0a33f668297c', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('89868bb2-49b1-49c6-92b9-fdbd673dfdc3', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8af12d1b-e3e5-4b8c-b800-ca2ff8cabfb9', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9e74268e-e34e-43a6-a19e-94f27d083f9a', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8906d52d-1ccc-4402-9d43-ed57a759898a', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('20ad596f-ae02-4a18-aa7b-6c559b6a65cb', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('87f35b68-8430-4f37-ab9a-e3c9917c4e13', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f5252fb4-1c42-4778-83e3-3f5b7427d139', '加菲猫', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '0', '加菲猫赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cc297aac-8ba8-47d8-92a4-451aceb4dd6b', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f8cace18-df7f-4eb9-90e3-cfd55ca06587', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('397efb14-6fea-426b-b456-f5faa51b8664', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4c7b8957-27f8-4afb-8025-089ea6fa5a95', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e37c8867-8bc4-46e2-afea-ed7a7648903f', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('479047fc-3e8d-4d96-869f-1a70b159a238', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('84e4949b-2cdf-42fd-92b4-8e2a500b68c9', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9b7d4bcc-6a21-4edc-9f03-c12750238a21', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('678d4a0d-0694-4cfc-ac93-2ddd7cf1fbb0', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('eebd0206-d8b3-4177-8c71-784464afd732', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f50ac133-af52-4c86-a7bb-990e5f8f147b', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ec056ce5-3430-43a9-a2a7-6257fcabb2de', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9e091e0d-d237-4eb7-98aa-f64e92dbba0f', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5a0288c1-12c4-45bf-9dc5-ea03dcefc8b3', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a24513dc-671c-4b42-a5df-c1392113e528', '加菲猫', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', '0', '加菲猫赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bdaac493-5b41-48f0-8c4a-0101a6d8aef2', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:33:33', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5d718570-1514-4d7f-ae0c-d7830dbb5512', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:33:34', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5558c520-edb2-4062-a065-daac4c6e8d19', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:33:34', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a2553d8a-6111-41fc-9b21-2decbf5fb64b', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:53:57', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ecb6198a-0f9c-49d3-a357-9e914072b029', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:00', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bb3c7551-6274-4af2-a215-949a8056e256', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8826f5b6-073b-445d-bdc7-6a96f93ed179', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('454bf9dc-a5e0-4204-932a-d7820dd5de58', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bf1455a1-a81a-4b8c-876f-e3503a26caf6', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('593b2e63-23de-4339-8d73-acf817ff7fd2', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d64defc4-5ba7-4fcf-b6e0-2c9637709cb2', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1358d63f-d13a-49e3-b3f2-fb61927e44ea', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7d899b75-d4e1-493d-87e9-c7b8548faa8b', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('908ef7e6-2e4b-4f4f-912c-b8fc963b5edd', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('71d52c67-de86-4677-9a1d-487a56bb2e07', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b85054d6-1c8f-4582-b028-92c1b1bbca1c', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f14f260f-8e78-4158-9543-109179c8f0ba', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fcffb0ea-7d95-4e99-8604-66600671133f', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d9dd5491-db33-4439-98ce-c3baeab37bee', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2ea30e02-fb8d-4cfb-a0b7-46aa0ff19076', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b5c6bf08-5991-4d7c-8c66-098a47d141a3', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cf71a28d-846d-4946-834f-ad71c0a6a634', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6bda4652-5c29-4717-b16d-bfbf4fbd342e', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b17a135e-0eda-4386-b5f1-8a51483efcca', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f6248d94-2e5d-4158-8e87-eab8dd8b85fd', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b9bb0e6a-7994-46db-8485-fe8c33934042', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ad83b214-9dd9-42b6-bdc6-3a7993fd47eb', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('eaa6efc8-f91b-4a88-bdd2-969b03d81ac2', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ea391441-90ba-440c-bbd2-615c1b9931f6', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fb1a228f-c1fb-4464-9b89-f8108dbae9c7', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:57:58', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3a7a5b9e-7bd6-4c6d-92e2-b07aa230bfc3', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:57:58', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('656e2ce8-30c9-46f2-8156-1feb544d2d7f', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:46:11', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c3da5d04-701e-4cf7-8c44-c0eb5d83720b', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:51', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2092225f-0ca4-45d4-9075-07600f258486', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:53', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('250af918-8acf-43a7-bbaa-c604554368ba', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:54', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d449d871-c773-4413-a4ea-c7d46fe6d5f3', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:58', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('77064ca6-9f17-48ce-9e09-873408991b15', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:59', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('113e9a63-6df6-4eec-9048-785fee135ae4', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 11:00:34', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('473df9a8-f32c-4cc5-b1cd-0f2359b0bda9', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 12:19:02', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('20963787-b3e6-41eb-aab7-9adf1c4572dd', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:19:36', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('30ec704f-2e86-4d54-a1dc-4181c1e795dc', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 12:20:06', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b97977e5-db54-45af-827e-ec484a1ef009', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:20:11', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('168cba35-6217-4738-8679-ff1903211c34', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:21:12', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a902035a-96be-4204-a6c6-61f596f6af66', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:21:16', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fa0c24cb-70de-4a55-a204-d693b1bef688', '天天敲', '加菲猫', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '0', '天天敲赞同了你在问题“阿萨啊啊1323让微软<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/50.gif\" alt=\"[熊猫]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0840ba1e-e0a0-4b6a-9c4d-56d1780600ad', '天天敲', '加菲猫', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '0', '天天敲赞同了你在问题“阿萨啊啊1323让微软<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/50.gif\" alt=\"[熊猫]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d481eb4d-2937-413a-85db-c93deda2e999', '天天敲', '加菲猫', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '0', '天天敲赞同了你在问题“阿萨啊啊1323让微软<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/50.gif\" alt=\"[熊猫]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('53f3831a-7fc8-4675-910e-ea1681b84112', '天天敲', '加菲猫', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '0', '天天敲赞同了你在问题“阿萨啊啊1323让微软<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/50.gif\" alt=\"[熊猫]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9710fcc2-b6cd-45ed-8294-ac8db3989c55', '天天敲', '加菲猫', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '0', '天天敲赞同了你在问题“阿萨啊啊1323让微软<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/50.gif\" alt=\"[熊猫]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ed0274cb-e180-4535-9e8e-b6f24dd5edd5', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-02 10:21:35', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2798a287-2169-4cf9-87b1-99da91c2057c', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:40:54', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6dcc763a-b566-4555-a604-cc38acc79208', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:08', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0282964d-5aeb-43a8-ab73-df430915c45d', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:15', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('45ebb762-5937-4359-97a4-d3bebeaed51b', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:17', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('456c7e4b-9203-4f34-8f87-615c89d8ffc6', '加菲猫', '加菲猫', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-03 17:41:18', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c6c008e3-75c8-45b1-8917-9eaee1eb0a93', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:39', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('02636424-de30-4e98-bdb2-917533880afe', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 17:41:49', '1', '加菲猫反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d0a755c6-db45-4b51-a9ea-ee47784f6d9e', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 17:46:41', '1', '加菲猫反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('df018e22-981a-43f9-a483-e6cc9e545e9a', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:08:11', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8f1b8c85-a74d-463b-a55f-9309d6db1e9e', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 18:08:46', '1', '加菲猫反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('980a16f1-b9bf-42ad-ad24-86aaf7175b97', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:09:34', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('14bd7771-f017-4a47-91d3-a2ab893b63ec', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:21:51', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9d589799-5cce-4464-94af-7bdead583d74', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:22:44', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('999b0fe0-ccc0-44ce-bd1f-8f0a4e999b7f', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:23:48', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('103699fc-5871-4e8b-bbe3-b2a7a16612b0', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:25:08', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6165f0f7-1167-40bd-9a52-8bb9cf786703', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:27:34', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c5bbed4c-9ad1-4b30-98c0-df52dbd6bb70', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:27:44', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1b372e05-807a-48af-aa8d-1c404d17311b', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:47:10', '1', '加菲猫反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('71352c03-1aff-4f29-abc9-afbe1ad61230', '加菲猫', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:09:42', '1', '加菲猫反对了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('397aad1e-cb54-4a5b-962a-df837bbd0a03', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:15:57', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('34cc5281-e320-4a2e-a895-99387fd76d32', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:00', '1', '加菲猫反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('af6e235c-16c6-4d8b-9ccd-d824bf3b7a3b', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:02', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1a15821a-11d4-4262-8524-7810a16d3424', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:04', '1', '加菲猫反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6b85c4af-82e5-4991-8a36-65618c74df8f', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:08', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1ad8aa75-dd96-4d45-824c-0406c4417f36', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:16', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('541ef3a0-eada-4931-a6d1-3ef5b3810ee0', '加菲猫', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:16:45', '0', '加菲猫赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('05af9675-a7e2-46d7-925c-934544622459', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:17:50', '1', '加菲猫反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3370c006-0338-43bb-9f72-da1271ee1735', '加菲猫', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:18:27', '0', '加菲猫赞同了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6a5d7ada-b0a1-4e70-b17d-43fb0db79b5b', '加菲猫', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:18:36', '0', '加菲猫赞同了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4e961b82-cf09-423f-ae69-b254f0f843ba', '加菲猫', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:18:39', '1', '加菲猫反对了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e5d7fe5a-cb56-4456-8041-4155e2e4b68a', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:19:02', '0', '阿菲菲赞同了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f591f341-1aa3-4f52-90f0-587fdbddab5e', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:19:04', '1', '阿菲菲反对了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('262d0673-895a-4c9f-a5a7-286f419658ae', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:06', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('060d299d-244a-4087-b871-6d8292a729c5', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:07', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2116b6a0-6011-45c3-a806-b4d0c672203c', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:09', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5315119e-fc77-4989-b71f-b2dad2f0a984', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:09', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ff07fa1d-b8f3-4dd0-8f17-ccb11de29498', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:09', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6dd3caeb-a5d7-4fea-a068-1105c65030a2', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3e2844a3-e278-4519-9cc5-9031829dc702', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a7d2248a-2cbb-4278-bae9-7d755e91f97e', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('03731d91-58dc-4f76-a529-b86293ec50cb', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('17c6e124-1ec9-4a99-984a-469b1299c6a8', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('770a11fc-b5b8-4c1c-b321-c0ad995ec6c8', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:11', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6464bdc9-3b5f-4aff-99d8-57f60c085615', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:11', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c10849e2-c734-47c9-a728-c977e9474511', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:11', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('74d8954a-766d-4a23-a2c2-2435f08d4c5b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:11', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7e6aec0b-5fc7-4ce9-a087-b78c9e8cef8c', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:12', '1', '阿菲菲反对了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('21c41d0e-f2bb-40c9-a4d5-4e3499c9ece0', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:35', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('62c6fb27-6f70-4f37-8cae-406e0b20c91e', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:37', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bace9eaa-65cd-403f-a6bb-167626296080', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1934c9e0-edcd-41a9-94c1-8d72a23c03f2', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d09463ef-10d7-4998-b2d4-8d8c524a83e4', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('72a78409-3de0-4c33-9920-a3d5614f6db8', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9339308b-50f4-4898-9077-a1961ec36630', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0dbc3f34-a637-485b-aed1-ff10b7b2bd73', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8c1a71e3-055e-43b2-9d8a-f1825d76ba15', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fed5e929-4c4f-4b57-bb46-3577a07eb2c9', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1e617ac1-aa59-4f9c-8af9-3e7bd5d7aaad', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('510e8783-4ff7-479d-9789-0d64d007b155', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1f37c979-52ac-4b41-bebf-e9e4f7b39354', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9d8bd0a4-c94d-4e8e-87a4-c960a60c61b7', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a66c3b82-e8f7-4a43-b3cc-2cc69f1d1834', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8242b535-6efa-494c-becb-e58a3d94e6a8', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ac7ff043-517b-46b7-b481-c8c18ed47dd7', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('09b9c8e1-800f-4b50-9d7d-6d27d351d057', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e85ae99f-97e8-426b-a56c-96c5c47d25c0', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3f7170cc-19f7-4400-b1b2-9d0d66c62f81', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6fc2bf8b-ee18-4d53-8178-f7ee65dda4f0', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f2beba41-5417-424d-a3df-54bc9f1dbeb2', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f216e00c-3269-4cb7-a83b-8f7c8b030998', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ab72cb86-70ab-4448-be5f-4442b5ff48d2', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('766ee210-d06d-4f37-a5d0-ac11a907d35f', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6985acef-84cd-4dd0-896f-dc4046e4ced0', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3e7226c8-66ac-405f-a10f-e5d8af7f0d36', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3e4464cc-f4d9-4d7f-a2e6-e61484f32265', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7ed3f95d-028d-4122-951c-c32b3ac19903', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('704b9628-f29b-4715-832f-20b598a3ebb2', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ed4ad962-4138-41df-879b-02113f6ac643', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('67ab8dfd-96da-4c78-b9a6-198e59946e9d', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0f730077-ec58-4b2c-9124-e444e47f8b51', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('992829cf-1c8e-4fdb-b182-ab97a1fcff8c', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('71f1d07f-3de7-4206-90fd-7d43a150c73a', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0de62227-39cd-4739-bdb4-1d3f96a888a1', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4ed236be-0577-4894-a898-861eac11a4a0', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f5bff9f5-a2c2-4da4-9193-7c27b7b76d51', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6dbe5ad2-cb16-4caa-89db-ed93d2e15cb0', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f1d2c555-a148-45bd-94e1-f724de82e26f', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:45', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a210dd88-65b0-4d14-9713-75d828e172b7', '阿菲菲', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:19:58', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ada4668c-16c8-4f37-8dfa-40e7525471c7', '阿菲菲', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:01', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4cfd98fe-d6c5-41f1-9c59-7d80408e39f5', '阿菲菲', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:03', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('69451b44-a926-424b-a6ad-14e43de4f178', '阿菲菲', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('91506912-2515-4b57-b046-07d25f3ff2dc', '阿菲菲', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:07', '1', '阿菲菲反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('645fb68a-771f-4534-a82f-a03e2ad93f0b', '阿菲菲', '阿菲菲', 'f254fed0-7f9a-4f74-8c67-f49ea329531f', '2019-05-03 19:28:31', '0', '阿菲菲赞同了你在问题“按时大苏打<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/12.gif\" alt=\"[泪]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('af0aa263-be01-4e4d-9807-d3d1c7ac7733', '阿菲菲', '阿菲菲', 'f254fed0-7f9a-4f74-8c67-f49ea329531f', '2019-05-03 19:28:34', '1', '阿菲菲反对了你在问题“按时大苏打<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/12.gif\" alt=\"[泪]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7ee37373-083f-415b-85db-0dda2b55386e', '阿菲菲', '阿菲菲', '57a3f71b-a945-4ae4-89ff-655b3339981a', '2019-05-03 19:28:51', '0', '阿菲菲赞同了你在问题“撒大苏打飒飒的<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/12.gif\" alt=\"[泪]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cffbccb7-b582-4d18-a54e-9834708910d3', '阿菲菲', '阿菲菲', '57a3f71b-a945-4ae4-89ff-655b3339981a', '2019-05-03 19:28:54', '0', '阿菲菲赞同了你在问题“撒大苏打飒飒的<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/12.gif\" alt=\"[泪]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dc99a9e0-8bf4-4861-8889-2ce2b690dc4c', '阿菲菲', '阿菲菲', '57a3f71b-a945-4ae4-89ff-655b3339981a', '2019-05-03 19:28:59', '1', '阿菲菲反对了你在问题“撒大苏打飒飒的<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/12.gif\" alt=\"[泪]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e30e957d-3c31-4ecb-aa82-f3462a1f0708', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:39', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4068c69b-ebf5-461c-8336-16e73f207e1c', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:42', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ad0bca0d-8f6b-4ce3-ae12-3a7a5f7a021c', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:43', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fa1913de-4071-4570-834a-dce090c1c647', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c2d73a47-4381-4c7d-a1ab-c41266804e27', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('27f26ae2-5b3f-41d0-a7c4-6afaf9f53077', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fa37e4d0-8861-4870-8912-3d10b66a66c8', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8ff2dc06-2591-4e5f-b143-a02a3140dd2e', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('26af5091-4227-4e3b-ae5a-da9c78bc0045', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8b96995f-45d2-4d73-9ce2-35dca844c860', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6ae33801-55ce-482c-87a5-2f216e0b9fde', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('131708dc-b820-4174-a787-59d01f3abde6', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9f3c29af-5004-45b0-8153-2c1cf89eceb5', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('73c8e4f2-4756-4566-bb83-8c1a88d19fa9', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e7c512ef-7540-4b99-9036-873a7b4560f6', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1f022f57-c12e-4b92-b137-0d067438520b', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2f3cddc0-e707-47c7-81a2-9516906dd6c7', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('06c2ba89-6f75-4f5a-8e8d-3c1911faa432', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bb6094fb-e56b-4b99-a14b-d63713a82c23', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('25da5262-9d21-4078-8c2f-605b5a7b2f23', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7cff2cdf-fb52-446b-b3b9-7c3e515983a8', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '0', '加菲猫赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b668aa24-39d5-46f8-9c19-a914b29deba0', '加菲猫', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '1', '加菲猫反对了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('35640c23-d2e2-4e75-b0cb-210cb5730928', '加菲猫', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:13', '0', '加菲猫赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('46d48962-44a2-4e6b-95ad-d2c6b50ca95e', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:19', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6ff2dce1-d358-40b8-af7f-63117cfb42e1', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:20', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7c792452-d7a8-4119-ba68-eccb35165251', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:21', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b0aa8594-5250-4d3f-8d7a-3dd93abec459', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:21', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a6b8c44f-487b-42ee-81a9-802e1a4ca06f', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:21', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('828e2fc9-86d4-4084-b3c3-8091fbb0322e', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('af1c2be4-7753-4d46-b7d8-906dfaba5518', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c690f6f8-02dd-45fd-ae7d-86f8290e9d71', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9c01d851-eb02-4fd4-864b-184ba8486ede', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('727ca3b1-ab30-4982-8239-40184333c534', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('29af8a2c-387b-4135-b1e2-c26981c12c82', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('58dd4fd3-181f-4a8d-87e1-1b9e5a2c06d7', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e4fbd882-02ad-4b52-8c63-c0bde2f61cfa', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d56e6cc3-5688-42aa-b2b6-a0752fbac345', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7e348ae2-2c95-4a00-9843-fa9caaac31fb', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('747e6713-91c5-4426-b6ce-7d59d72b0965', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('85877508-2905-4617-a85b-2bf9dc1cd0b6', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:24', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bd9cb87d-5062-4337-bee6-6346fbc80326', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:24', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('39e39821-11c3-4083-9e38-27e03cfcbfd7', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:24', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ce3facee-b31f-4128-85fc-f2787afd45c8', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:24', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c03b6cdb-99a1-4269-9034-137ceeb9e5b0', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:28', '1', '阿菲菲反对了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('26fc7aae-f49b-47d3-8e28-f7f591681636', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:38', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e8c37090-16c3-463c-ba38-1e9c1d216ee8', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:41', '1', '加菲猫反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9384edf4-4250-460f-b5a2-3a84055ede1f', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:43', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('acb87d3d-c28b-429f-b2b6-7f2345bd316c', '加菲猫', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:45', '0', '加菲猫赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('65221fad-eedf-4ebd-a72d-e48e7281a368', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 20:04:13', '0', '阿菲菲评论了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bc523e98-2521-4771-8e7e-06c26b7748b8', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 20:05:17', '0', '阿菲菲评论了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('aa4040b8-6616-4aee-8009-4b59ad831003', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 20:06:33', '0', '阿菲菲评论了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dae11bbf-6b1b-4238-b5f7-ba208a5607ef', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 10:49:35', '0', '阿菲菲评论了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b2c00e1f-2ae9-4ede-a9af-b7f923bc32d2', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 10:49:50', '0', '阿菲菲评论了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6fcedb82-a47e-4803-8b17-51bb4c652e13', '加菲猫', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-04 10:50:00', '0', '加菲猫评论了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c99043c6-6e6f-4df3-8bb4-d3b83264819a', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 11:04:25', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('006bdba8-4840-4563-be80-6776707ddfe7', '加菲猫', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-04 11:04:29', '2', '加菲猫收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6a4148ae-693c-4a24-9406-491acca46d75', '加菲猫', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 11:04:35', '2', '加菲猫收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cbb94fc7-f4b8-43a4-8837-22e9a929a993', '阿菲菲', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-04 11:07:12', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b1d83be4-20a2-4b57-97b4-144bc9ae50d9', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:07:18', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e810b7a0-54fd-47e3-82f1-289561854e89', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:12:33', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('276920c2-a310-49b7-ba70-0da8fb79a45d', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:12:34', '1', '阿菲菲反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('10bbae35-419f-42e3-8d74-eb1e5eb39db9', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:12:37', '6', '阿菲菲评论了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e06c59d5-01f3-455a-86e7-30f171a77d90', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:12:41', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5247534a-b078-4a46-b131-21c4deec19c8', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:12:48', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b1f8abed-927b-44b7-ae53-6537b2610308', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:12:49', '1', '阿菲菲反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1f8d81ef-9e0e-4e02-9048-33e45366a175', '阿菲菲', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-04 11:16:25', '6', '阿菲菲评论了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c8c4d97b-b9c1-48c1-85e6-f069d273e779', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:16:31', '6', '阿菲菲评论了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e5d76f9b-2c68-481d-825a-bee3ec17098b', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:16:40', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b2c5f619-3a34-49c5-9e4f-de9fdf81e495', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:16:41', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4affb847-1bd4-43ee-8d58-bd8de0561ea9', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:16:41', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a9dc46db-7707-4f3b-a12f-165bc5698cd1', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:16:45', '6', '阿菲菲评论了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e7db2b6b-a7bc-4694-aecb-12412bbd6b61', '阿菲菲', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:16:49', '6', '阿菲菲评论了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4a11d92f-18fb-4c36-b2bf-5c51f59e26fe', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0a540eaf-9443-4be4-a7f9-263c1f2ab60e', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8b180c4b-4b9c-415f-81f7-184d3ac5ffd5', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ebbaaa9f-3635-49e6-a2be-d4698cf07941', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5c78c07d-35f1-4410-91a7-e979ff8d818c', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8cb2afbc-834e-423e-bd57-bc5a0d0cbb15', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d72761e0-b19f-45f1-abae-08b6131543c2', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6abb6e52-87f1-4766-a28f-d9863faa91dd', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0dd0b1dc-336a-4fe1-994a-ca7b32b1555d', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d0abcb96-f486-4a82-9ac7-2795bba0716e', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('18c97589-3ad6-4bcd-958b-53e3b7eb116b', '阿菲菲', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:16', '1', '阿菲菲反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('91c87d57-f3a9-4b30-88e1-fd7984fcaccc', '阿菲菲', '阿菲菲', 'e1648ec0-5a2f-45cd-a9b4-653662488995', '2019-05-04 11:20:38', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c7bb8a56-dce0-4439-a03e-6fcc4e577dd0', '阿菲菲', '阿菲菲', 'e1648ec0-5a2f-45cd-a9b4-653662488995', '2019-05-04 11:20:42', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d796cfa8-91ea-492e-9095-002dd60a69c1', '阿菲菲', '阿菲菲', 'e1648ec0-5a2f-45cd-a9b4-653662488995', '2019-05-04 11:20:45', '1', '阿菲菲反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('674aba1c-6373-457c-8a0a-ea7b04c4cbc2', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:58', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b772506a-1af1-4171-8382-6b4fc34a7410', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:58', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f934bb04-e190-4dd8-909c-9d2c74e681be', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dafe1d2a-1434-40c7-a4b9-68bc81c4b46e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1de40106-6af2-4279-8fbb-ecc52512b7ee', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dc27de0a-2530-4bfb-8806-5b9f7f2b291c', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a987bea0-7b5c-4ae5-84d9-8451b4512f50', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ccc332b8-7a86-4f84-afaa-8803a16d0af9', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b6c293ad-921a-4b28-9771-6903549286f5', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c9d9eb6c-6ce4-4fc2-b13f-7db8cfb471a0', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2a0a2c75-54c1-46d1-bba2-e3930174e935', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('780d72f0-9b5d-4187-a691-b990858377dc', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2cdd0445-e75c-4dec-a5de-7c7aa16fd292', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e12ef30f-d7c8-46ed-8ae6-20628528823f', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:02', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1d52c057-452e-4643-ab1d-12d0491c0189', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:03', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c34d1b01-df07-4e86-b102-81c3d737e9ec', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:03', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a79f2f41-8cf6-4d22-8fd6-dd5995508af2', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f391e197-bb21-4ea9-a0cf-4594f9d1a8d3', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('77ac0d6c-77da-43a4-ad9d-edde875f3f31', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('997b192d-8d6c-42bf-9734-ba12b9f8e670', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('45232f8f-7168-4c61-9bd9-97980abf30bb', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c9ee8aa6-ef6f-4b09-8afc-13a464a8d5f5', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1b39d023-518e-490e-bf89-f5266a9a0932', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('22d15228-d458-49a9-abe4-5f022fe402be', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('66b9a372-a391-467b-9e53-5d2281ed17fd', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2dc92d7d-aa5d-4ba8-8098-d7fc94d417e2', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a247c98b-2f7c-4c83-abfb-a8164164a82c', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f6b07cde-f867-477f-b36a-1882f3e5ad5c', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('65cfdd7f-5c85-4fb6-86c9-8191e45a966e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cf3b4f16-be1c-436a-9ddc-5c5a033d2630', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ddfc64c1-3f83-4dce-be7a-42113abcbec8', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('09b0a9dd-2c47-4231-b75e-f5ab88cca2cb', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cc6905dd-cba4-44ea-a8de-8e97453c8d02', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('34d77888-9b47-4f82-9495-834e2b4be3af', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('916a792c-4b6f-4a1d-8792-8e5cb4eab1ca', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5a13202c-a251-4372-a436-8b8dd876319e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('727503ad-d9d3-40ac-9eb9-3f8948e35929', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('edcd85ba-2457-4590-9832-81a3704ebe77', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('930c3e93-2414-44fc-948c-71ac09e09f69', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d7361c9a-6b23-41b5-b6f0-361906b94721', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1c943ed2-09aa-4ea4-b61a-bc7610ad1cd7', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f62ad63d-711a-43fb-858e-88dd0b11d3a2', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bfd8fe65-a386-4d38-bd07-a53b9e3b45f6', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cd59f997-d38a-4b65-977d-c4148485bcf1', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('47010c04-544c-4439-bf9e-b8746a8aea14', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4499920d-1ad2-4550-9a86-3f0d6327a8ae', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ae029679-d5ea-4979-ab23-0fe1f5cfd3d5', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('81ee94da-5cb9-48d8-bd05-acbaca9a8a15', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fb2c598c-1f44-4a6b-9687-77d1cbe03c9a', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('84de8d6f-ce30-4eb7-a281-3d5b02b4c36d', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('51e711f4-c42e-4be7-bea9-3bf50046d27e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('269b28be-7e7d-4d07-9e16-915133cca8fa', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4b94b86c-a1ca-482d-9331-1c3ee72e3f4c', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('afb62610-473d-4ac1-bf12-0bf248305287', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('704b0e14-8631-491d-befe-551df4da3ec5', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('610b5a61-8094-4bfb-88fe-f281560c25d8', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('28a236f0-8fd9-4d7e-a507-bb2e6d9d587f', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('15e31cea-bc3e-4383-84dd-a2e6f881cadc', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('712804c8-330b-49a1-898d-508916be4cba', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('788f0e8f-9b2e-4ab3-a23f-8623d8acc3fa', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f0991024-bd1b-475a-ac4b-19d8291a7d7b', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7b5a2f37-4032-455e-9f78-75349c0be2be', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6ca50f21-37a1-470b-8423-710f017e02f4', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3282df0b-b22e-425f-a08c-ff552ac2010e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('97ace82e-18bb-4487-9a2f-f67c1d4ba457', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d9b80366-fca9-466c-be8f-26a5f264b329', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ac4de0fc-633d-44e4-a44c-b4447c017edc', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('610ad84f-1a6d-42f1-8f18-8a0fb9f072d8', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e87cdd77-dda8-4244-b606-75aadf412430', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9b4887d4-e344-4458-8298-0577b00dafcc', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b3547c7b-f25e-48fb-a8a5-99ca4f672974', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('88bee8e9-9466-4c01-933e-c443e2f05657', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8ee11733-34f2-4330-b00c-49d83de8bbb5', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('23818ceb-f69d-4e11-a472-bbd041f40c8d', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('75cb06ea-9f05-43c5-965e-d67bbe4c879e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('daeb8b18-822c-4c19-9d90-3e21e2411380', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2ebf3a18-7f09-4de3-9c4f-aec0b63e588f', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b415c3de-6628-477b-a94e-a56eca6c6285', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('687786bd-57cf-46f8-a999-105ed0efc3b2', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bfd0925e-2b3d-4fe3-9869-14fdc7f04d5b', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2b426e14-24ad-4c60-a085-650c73a5a7db', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('eaa6791b-61db-4a85-baef-04b943b09446', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b3af478b-7e7b-425e-b3ec-a1116a80c6cd', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('45f69aef-8f1e-4b87-bf39-0c6113ee350b', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('84786ca8-47a8-4eeb-8a73-afe44370159c', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fb4bd6c5-481e-4a2c-98cc-81ed314e40c5', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('63236d94-4cca-48a8-b8fa-f78fc489199a', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9e98b629-276b-4b9c-aa64-94df7e8a276a', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:17', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f59e4ec9-090e-4df3-a8e2-63690fb72119', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:17', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('eb6bfc33-18cb-43cf-a574-b9f59af025b7', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:17', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c0f19ca4-c856-4765-85ee-259543fe4752', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9496868a-c8ec-4ee8-942e-901daafbde76', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('25c31b53-58a4-4c23-806e-cc6e506842fc', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3980681f-a491-434f-a7fd-b1aadbfa1bfc', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b3797739-286a-42a6-94fd-e3845861dd33', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cb9e4bbc-7e0f-420a-9576-be0a616c1052', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('872d1d28-23c7-4869-8d4f-8323c7d7c8d7', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b4a3406e-474b-4ddb-8924-f687b0ab2c12', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('17fe9dcd-74e0-4414-a4ea-d61f1e7b5434', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:20', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7adb503b-f5bb-46b1-ab7d-976826cb50f1', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:20', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2e2bfaf0-f4ca-45c2-b90a-ccc0b930251b', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:20', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ae1da983-9c8c-4b7d-a48b-9d11b0c96d84', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:21', '1', '阿菲菲反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('95e27ad4-e4cb-46bb-862e-9c695f85252d', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:30:44', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cb2405cd-0509-4619-844f-630e1309d7a3', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:30:48', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b4ea74a3-4193-44fd-b7a1-55b6fcc5de10', '阿菲菲', '加菲猫', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:31:03', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cbd86cbf-9324-4fa8-a6fa-183ae5f4de0a', '阿菲菲', '阿菲菲', '380045ae-5f9f-4009-b818-daedf5adc931', '2019-05-04 11:33:34', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('56726f62-6592-499b-8f30-0d08e2845693', '阿菲菲', '阿菲菲', '380045ae-5f9f-4009-b818-daedf5adc931', '2019-05-04 11:33:36', '1', '阿菲菲反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ae16ab2a-b212-491b-bcb3-e751703d23f6', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:37:55', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0614d366-ecc9-4a5c-b92e-0072f8981a6d', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:37:57', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('27e86cb1-c45a-4faf-ab04-5e28bde11138', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:02', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('71d76e6a-dc1b-4467-a58a-291ed915a32e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:05', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('017502c8-c074-4b7c-9147-dad4e490840a', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:13', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('337c0fe7-7a86-4b9f-82cd-af0a6eb3c2fc', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:14', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f6c0a55d-4482-4b99-a48f-04c038da4c50', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:15', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('56d75acf-1a0e-4fb3-a797-1cf90e8d471d', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:15', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b8d1898a-3bf7-4cac-85f8-d3b4d161bcc0', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:15', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e3fb75ed-3d04-4dc2-b3c4-783ad1d26f65', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:16', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('91184139-6974-4565-bbf2-cb3ffd615046', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:16', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0a055f26-9297-4e30-ac3f-eef72cd02448', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:16', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('edf5c345-707e-4bc6-9d23-18af0231bd80', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:28', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('853c405a-6367-422a-9851-4109c35af18e', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:29', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('58fef0ed-01cd-4f78-8dc7-483a45d94032', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:39:14', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ddc4a89f-cdfa-4b6c-b6af-b9fbb3c719bf', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:39:17', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1baf32a0-1f21-4f50-aab7-ae543d86068e', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:39:58', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fc6acab4-b14a-4d09-bb2e-32af1ba09645', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:39:59', '1', '阿菲菲反对了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0e4cc099-8750-42df-91b2-d5a0b187a7b8', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:00', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6d3880a5-f701-4d46-ab50-739f3ce1915d', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:01', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4935b652-6500-412b-9645-193f20e4dad6', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:01', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a8b78888-088c-42e7-a86d-6481da4da224', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:01', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c452d6e0-283c-41ec-97a3-d979c717a5e2', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:02', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b02ec984-fc56-4d80-a496-a198d16a8bdc', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:02', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('97f4862a-b76f-4a54-bf6a-2114dd55ec5e', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:04', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bc5a6e21-bfe3-447d-b097-1b0c17b97dd3', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:04', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c71574b7-472b-47d7-a289-c12be7524491', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:04', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('699f1096-8998-4b2d-8a36-8b99e469820f', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4819e20b-55d5-42e2-ada4-f9e904e65516', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('522c6a0d-f2a2-460e-8302-64108cad69e2', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('10fb6986-7d72-4325-a3cc-a870ad876c44', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5c7a9e54-f89b-4424-a246-39be3941cd79', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('83b92a6b-7884-43a3-880a-dfb7bc73dcfd', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3a54cad5-1001-4f17-a893-2ea8c10265e0', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:08', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e4e5308d-ddb7-4ba9-abed-84ccec79feb6', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:41:03', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0eeab0e2-ed57-43b5-aa1b-db6cfd728718', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:41:35', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ce0ca9d9-a5e8-41b2-b853-bbfa801f86c2', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:41:55', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d645aa3c-a794-40b3-8fd8-b34628898072', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:42:17', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9d9b9ac1-0e58-4c04-8a3d-145e024c2c27', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:42:17', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('19f39b82-ae29-4bbd-add6-cf50bc3ea323', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:42:21', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('98057da8-4369-44a1-b0f7-5a077364eeb4', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:42:47', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('26dbff9d-c0c8-4052-98a6-9a03073471a5', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:43:33', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5385d7e7-2daf-4bc6-b25b-2aeed4987fca', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:43:45', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c00dcbd2-b7bf-4cb0-a093-d6bec6971453', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:48', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f75093b0-bbd5-4e68-a6c6-8aeb032a84b2', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:50', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5642b04e-b69d-4e64-b1f3-bb31c9644b0b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e9eea8ae-c68b-404f-891c-f26cf7be316e', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f4a71202-1dc1-499e-a929-a085bb989590', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7397e537-b0bb-4ef1-b407-c168be810571', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7130fc26-5246-4728-a049-62cf4f9a8706', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('63a1524b-5fa0-4119-9981-f0b9d794b118', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('398041d8-1870-4dff-bfae-a503bd22ccf1', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('77148454-ac0d-4010-98e9-ccb5ade8102f', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3413101f-4de2-4417-bf7d-ad0231d85a08', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2cf08cb2-0c6d-4f4b-8cd7-d578c6882a3a', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('84671c30-dd8d-4d4e-85fc-5559237e34c3', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b04819c5-2a76-4bb0-b42e-ad1a8bda649c', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('714123f4-a1a9-4878-8665-b4d2b3e2956b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a12f6594-40cc-4ba3-8b4c-afb395e9ce12', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('59ba2618-ebaa-45ae-b110-a381a0923257', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:55', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('351b8fef-fa57-492a-917c-9a564ff150cb', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:56', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3fafadf8-5b56-4dd8-9b30-bc2b22622bf8', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:57', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('854c6ba0-4f14-4f88-a024-97da92be66a2', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:57', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dc79cf0f-0489-48ce-8ea2-76019e26ad2c', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:57', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e779637e-a629-4012-86e0-94b4e21f1652', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:57', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('794615d1-8ad0-488f-925c-057d41bb506b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('73165107-acc9-4f33-9a82-b8fdd5a5f7b4', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1d139cbd-84d8-4755-8351-0cce3a3a01d5', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0b041f95-e4bb-4951-8b5c-5d193de30497', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e9924e0a-c4e8-470a-a20a-930f4089c0b4', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bc5ddc84-9410-4d49-9811-085dcf4c01ad', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3166c0cb-c0b1-4d0b-9203-9d9a629b191f', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8224ab92-68fa-4c54-bf85-50c3555848f2', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('91edcb15-7d62-49a5-a309-4f2ad9dd2fa9', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8621d807-041f-488d-92b4-148e7ecfd0a1', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:45:03', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e3e26256-b358-47b1-98f4-3637e983939a', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:45:11', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('298203bf-b999-4cfc-a2ff-8d6305aa02b7', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:45:19', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0e33eb7f-741a-437a-beb3-fa3bf1d97912', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:45:55', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('aba4c1f2-276a-4971-8e15-68b3b0d95e11', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:46:18', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ad7ae40d-d82f-499b-9961-74d8373a54e2', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:46:19', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fb5dccd8-8f16-4c71-9510-30707c6dd27b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:46:28', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('923c45b3-0d9c-4175-adaa-aae26412bc44', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:46:37', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('17d3e798-1f1c-4585-b7c2-3e24fb0d2970', '加菲猫', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:47:14', '0', '加菲猫赞同了你在问题“啊是大”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c3ddbe48-517c-4af3-828d-d650811dd61b', '加菲猫', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:47:17', '1', '加菲猫反对了你在问题“啊是大”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c17005b9-bea9-4fab-8b75-1baa6c99226f', '加菲猫', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:47:20', '0', '加菲猫赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('81d04916-e0be-4f42-b69a-91fc54048814', '加菲猫', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:47:22', '1', '加菲猫反对了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9f2560d7-5170-446c-921b-feb99df64720', '加菲猫', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:47:41', '0', '加菲猫赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('aa82043a-cef1-4f8a-a1e0-e4d8aa1467d7', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:47:59', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5abfd110-b711-4004-9ce0-b6f8c980b703', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:48:43', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3dd3aa06-62ce-4485-a3b0-c111e51d5c60', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:48:45', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('40210cae-77c8-4648-bae5-36d23fff77f8', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:48:52', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('68d88812-9500-4dbe-a2fe-a067cefccc02', '阿菲菲', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:48:54', '0', '阿菲菲赞同了你在问题“啊是大”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('19640070-6f0b-49f8-b40d-56b6bb47b0a2', '阿菲菲', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:48:56', '1', '阿菲菲反对了你在问题“啊是大”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dd5fbb9a-d7cd-478e-9d73-1aacb89e3251', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:49:19', '0', '阿菲菲赞同了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d8dba0e5-7992-4c49-9ce1-1b13d7825657', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:49:22', '1', '阿菲菲反对了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('85d9c4d2-aa08-472a-bc5d-8afd8ff93824', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:49:25', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('700a1957-509f-4482-94e7-ec312a66e65f', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:49:29', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('57699938-60b2-41a1-b598-eb54a9aa7c7b', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:51:46', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('77150d08-b862-48d5-9ff4-7f42c1d897a9', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:51:48', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('59513e81-b7ba-498f-851f-e9a8bb0b17f5', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 13:51:51', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3d18a508-c274-421f-b809-c434e0354328', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 13:51:52', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('04ef764f-20c3-46ba-927d-8cf68d6c439f', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 13:51:53', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('833b4bc3-2733-42d9-af43-1b23f59f7f41', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 13:51:53', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('df70d623-fbf4-4281-b8ef-b5941bf847ad', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 13:51:53', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('421e8290-7ed3-41b1-b1cc-4abf67bbbcce', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-04 13:51:53', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('06c203d4-fc5d-44d2-9f25-9bc474acbc1c', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:52:31', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1d705397-036c-4c19-a35c-45ac0373a002', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 14:19:46', '6', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9388fa46-ac65-4a7c-88ec-111c203785d3', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 14:19:49', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f8f0f6a5-dc97-4fe0-8380-8fe35820a8c1', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 14:19:51', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('77b2ab83-dd62-4369-80d2-0e673c4c6a69', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 14:19:53', '2', '阿菲菲收藏了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('df11ed9a-112b-437c-a7bc-73d37b072540', '阿菲菲', '加菲猫', 'a639c2d9-942c-414b-9422-5e6f15a6400f', '2019-05-04 14:56:40', '3', '阿菲菲赞了你标题为：“<b>阿三发射点3</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('a30ad85e-5a17-4bd0-81e3-020f32944103', '阿菲菲', '加菲猫', '1b085133-b37e-44f6-8dda-52bf5205dc77', '2019-05-04 14:57:12', '3', '阿菲菲赞了你标题为：“zxc&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('308fcda8-3a8c-4fbd-894d-f8b14727e779', '阿菲菲', '加菲猫', 'c5db833c-5f27-44a5-a7cd-0307e9dd3050', '2019-05-04 15:34:02', '3', '阿菲菲赞了你标题为：“asdas&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('f4a79574-5c2f-432f-8949-003de8e54c63', '阿菲菲', '加菲猫', '38ebb34b-71d1-492a-a786-f407fc8b1388', '2019-05-04 15:35:26', '4', '阿菲菲踩了你标题为：“null”的文章', '0');
INSERT INTO `pushinfo` VALUES ('8fdbb8eb-c690-43e3-b097-a2c5b5e51e46', '阿菲菲', '加菲猫', '38ebb34b-71d1-492a-a786-f407fc8b1388', '2019-05-04 15:35:37', '3', '阿菲菲赞了你标题为：“xdxd按时大苏打”的文章', '0');
INSERT INTO `pushinfo` VALUES ('a6beaef2-c151-48eb-a00b-db671e1f9ba2', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 15:38:51', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('eae9f57b-139d-47d2-936e-45a55584bb09', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 15:38:53', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('09718980-acbe-4991-b8a7-3dc0583a0092', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:57', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a3acd843-579a-4701-b5b6-faea5e96f3f8', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:57', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c5be2f25-646f-404e-97a7-04baf1b0c89e', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:57', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0d94b843-6f49-41f1-8a8e-2f83ec9858f2', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:57', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('feb6d208-3d8e-4b35-8651-847355cd98c5', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:57', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f041126a-d943-4d92-8ce4-ea8cd648a4f2', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:57', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f1dbddce-6080-45bf-9cf4-77fa9a104c43', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:58', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('51af85e5-ed2c-44f2-bc56-e0384c12088b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:58', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2196b6a3-bb10-4b5e-87a9-e0fbcc4d249d', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:58', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8ce66b3c-88d0-42f8-8bd3-0136a8924019', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:58', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('68e94655-220d-4eb5-bacf-1d24b6bd2076', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:58', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('494f547f-1c12-493b-be6f-99f02155fe6b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:58', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('272d5f09-6953-4890-b63c-6155d35caffd', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:59', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('826d4530-635d-4f3d-959e-5473be9b796d', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:59', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8c262926-c32a-44a7-be50-c0ede0f20739', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:59', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2f3afacc-2c42-4e87-adcf-209f225d070e', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:59', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b2e36f1d-371b-4120-b374-a429aead015e', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:59', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a9075847-a3c0-4ed6-88bf-01b415dc4c53', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:59', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1c556414-3186-43d6-b943-fdd55fdb4d0d', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:38:59', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f6074e6e-83e2-4561-b062-0afb55427ff8', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:00', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('89af2949-dba9-41ae-a0a1-70fc10115d8e', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:00', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c5d4c3ea-193b-4561-bf53-1d45001db732', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:00', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2b87a7bd-ba98-427e-8b3e-ffcb95f4a076', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:00', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('adca7292-279c-4242-b9f1-fcc114d70b82', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:00', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('aaf4c718-eda0-465b-8778-cb6962d2e4bb', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:02', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7d291d31-c0b5-4847-a146-8545153e0b5a', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:03', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4585e3a7-b10d-4f14-add3-111f7bf090dd', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:03', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('21e7dc32-b308-49fd-a60e-20084c4fc053', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:03', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('153102ea-b6d8-434e-804c-e301291be729', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:03', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fa025c21-8d15-4610-bb43-664235cfb7bc', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 15:39:03', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ab192c5f-fcf2-4823-aaa9-3eca5b8877b9', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 15:55:09', '6', '阿菲菲评论了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('63f9a77c-bbf2-4d19-92d8-28f3ab0e3a65', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 15:55:18', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('d88ffacd-7ad4-4edd-bb56-20e979007565', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 16:02:42', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('f1af940f-bf49-4409-985a-dc364e7d2444', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 16:02:44', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('b3768cb1-2de3-4a14-a45f-5f8739f869d3', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 16:02:48', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('ad983175-1888-4899-825a-d42d8e835259', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 16:02:50', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('b16b33b2-061a-40bb-a5d1-802e80b4f535', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 16:02:52', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('b787c0e8-66d1-46e5-8674-acb2475f1c2d', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 16:02:56', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('0c834426-bbd6-4a66-8627-04bca74c186b', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-04 16:02:57', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('3d9a45fe-4c3c-4275-b6b6-beaeffd89f4c', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-04 16:02:59', '4', '阿菲菲踩了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('67abf3bc-a024-488b-9bcb-6eb417dd546e', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-04 16:03:03', '3', '阿菲菲赞了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('280ec53e-abb6-4239-b7ab-2cdf7747a42f', '阿菲菲', '加菲猫', 'a97ee283-c951-44b2-bdd0-c5b022c8baea', '2019-05-05 08:28:15', '7', '阿菲菲评论了你标题为：“<b>阿三发射点5</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('35a44abf-9c18-44a8-a2c4-99caad5efcbb', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-05 08:35:26', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('bc89e3c7-3ebb-4c6e-9d8f-7ce451f7b1ca', '阿菲菲', '加菲猫', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-05 12:29:06', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('30a7a27f-50b1-4d12-ac58-ef42c7a8ad38', '阿菲菲', '加菲猫', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-05 12:29:08', '1', '阿菲菲反对了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('919ff0a0-d823-4986-9cf4-33186097a238', '阿菲菲', '加菲猫', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-05 12:29:17', '6', '阿菲菲评论了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('62c613aa-9fb3-4988-833d-9d864c9b05c2', '阿菲菲', '加菲猫', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-05 12:29:19', '2', '阿菲菲收藏了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0cd4c05f-d9f8-4ae8-b83a-998c4437c58d', '阿菲菲', '加菲猫', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-05 12:29:21', '2', '阿菲菲收藏了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cea375f0-ea7f-4e37-8d62-01d50c9ebfc0', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-05 19:17:06', '6', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('77030102-752a-46e7-bbdf-ddb44694bfb2', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-05 19:17:09', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8071f458-ed70-4650-8054-475ca9753237', '阿菲菲', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', '2019-05-05 19:19:29', '0', '阿菲菲赞同了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('914dc469-cfd8-4f47-ac9a-c2c4f8d5422c', '阿菲菲', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', '2019-05-05 19:19:30', '1', '阿菲菲反对了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2806e3df-2240-4aa2-b132-a527a4b18203', '阿菲菲', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', '2019-05-05 19:19:35', '6', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7c18f155-ab7f-4683-8cd9-5f39626577ee', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 08:55:16', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('42b16ec9-a5ab-483e-9603-d119206ee218', '加菲猫', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 09:35:56', '3', '加菲猫赞了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('053a85db-98ed-4e9c-a963-43302d7debc8', '阿菲菲', '加菲猫', '4669bc01-e935-4e69-a4e8-e202b7e4ff4e', '2019-05-07 09:40:26', '3', '阿菲菲赞了你标题为：“<p>阿斯顿发射点发生我打发士大夫士大夫</p>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('5a3283f0-7ff7-4ece-a9fd-09f1a141bed4', '阿菲菲', '加菲猫', '4669bc01-e935-4e69-a4e8-e202b7e4ff4e', '2019-05-07 09:40:28', '4', '阿菲菲踩了你标题为：“<p>阿斯顿发射点发生我打发士大夫士大夫</p>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('1a990a6e-2d61-49f3-857a-611674588371', '加菲猫', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-07 09:42:52', '3', '加菲猫赞了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('f93d1c2b-ffd4-455a-b13c-abd787c56f89', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:17', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('cb66ac1d-a236-49ec-83c5-c4ce424c33bf', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:20', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('e37af0c9-b0af-4b27-a4e0-63497baa579f', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:21', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('912a2bb6-738a-4663-9046-59c1ae5440b5', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:21', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('03c4021d-80fe-4a73-a9ba-62238b21423c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:21', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('4a78911f-493d-435e-84e0-19809432d7c2', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:21', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('6e53d71d-a4fe-430c-be7e-09b533b92fec', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:22', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('c0427d57-c564-4804-a3c1-6dbbea02003c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:22', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('f0e0b0dd-e07f-40ae-bed2-0e7a2433b661', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:22', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('99d1b1c2-a908-4e30-a5d8-675f3cd195ff', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:22', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('9f6d4dc4-0054-40db-a299-952081223b3b', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:22', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('bf90bf0a-16ce-4a5e-b193-eb5650b84e16', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:23', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('7036f6d1-2ad9-457a-944c-1353e00b1c64', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:23', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('0ba7709b-aa7a-4551-b767-368e857ada27', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:23', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('5e97cde0-3f41-426c-971b-8d9f42f450a8', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:23', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('170c3ee9-fc36-4b2e-8ac2-5548f5317fc4', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:23', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('4a54555f-e73a-482e-a791-4873fee5b093', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:23', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('41a5d3c9-4b44-4825-9c13-354cc26d568c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:24', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('666c4b26-706a-4c05-a32c-993cd0e6ce94', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:24', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('f9e3e3e0-23ed-4bc0-90ef-4a3f25dee4c5', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:24', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('498e3679-b686-44f4-8dee-e9e08cb40d57', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:24', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('2a95330f-b9b0-40e9-9fdc-226c338318be', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:26', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('3e57c64e-3476-4096-91ac-6e64aa5c2e3c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:26', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('aa350975-7537-48f8-bce7-76f30b96424c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:26', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('7780a3bc-338f-4adf-9e56-8de5198e9633', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:26', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('a8b7f9ea-7998-460e-9043-f7e023934b77', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:27', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('28e7c695-42a5-44b0-9670-92772ccaaae4', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:27', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('e8b23730-84bd-4014-9f87-3c7923433383', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:27', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('8b8f3c67-0f5f-448f-abcc-9b0d1ae53c7a', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:27', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('5fd15801-8bfb-4066-b98c-b071bf6efde1', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:27', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('14a0dc9a-8e50-4c0a-a5bb-6f47951a1bf4', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:28', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('71d7407e-c03f-461d-ad6c-69f5cd06366e', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:28', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('731e1471-8c74-44cc-90cf-a4d8286f0428', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:31', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('4d188f7f-acac-4d62-84e7-1feeffb3dcc3', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:31', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('0c29cb78-039c-4744-8c5f-a53bd8784742', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:31', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('826cdcee-2cd0-416b-a473-e8c2ce6b9217', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:32', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('641001ac-8c45-4d04-a863-0431564ede02', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:40', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('e14573ed-a0db-4308-9857-022ca25533f1', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:41', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('0727085e-1aea-466d-be66-d873cf253d8c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:41', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('3302b95c-b479-466f-92fa-867dc058287b', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:41', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('ec300b58-9f1d-406f-946a-c2f442b22c4a', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:42', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('914091ef-9163-4a2f-8989-4201cb1f5f88', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:43', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('bec1586a-1dbd-40a1-90f1-7a825948632c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:44', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('787d68e0-fc93-45a7-9fd5-e3faea30565e', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:44', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('f6771168-63e3-4fab-b163-c09fd89b644d', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:44', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('64f38860-60d3-4bda-8b08-ec7dafeee5bd', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:47', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('b5665184-7d19-4f78-9d00-27f9ea0540dd', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:47', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('6422f282-4562-42c2-9cde-f2f9b469dd0f', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:47', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('a0631380-9671-4d15-9696-133c1c15162c', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:48', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('8e8b2c7e-6fda-4f52-82a2-0721c84cd962', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:48', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('3bb12a9a-2234-41d4-be67-34bd0cc9cf86', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:16:48', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('a8f8a4d9-ef62-4fff-8422-eed0305a07fa', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:17:00', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('dd30ded1-d782-4747-bece-3fa738b40b9f', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:17:00', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('ff7b6c86-5eb8-4856-aff2-7bc1df48ae97', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:17:00', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('d0a9ee25-add3-4274-a1cc-4bb17c3acdcb', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:17:01', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('fcb1efad-e934-4850-9b18-e26eb8c702bb', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:17:01', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('d58d6152-f4d4-430e-a1de-c8ae51964deb', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 13:17:01', '4', '阿菲菲踩了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('ad84a33e-16b8-4379-883f-8462073986c7', '阿菲菲', '阿菲菲', 'bd359937-76a2-4685-a12b-291dbd0525f2', '2019-05-07 13:17:25', '4', '阿菲菲踩了你标题为：“啊是大”的文章', '0');
INSERT INTO `pushinfo` VALUES ('9e9f00b8-101a-4847-83f7-9194933fa995', '阿菲菲', '阿菲菲', 'bd359937-76a2-4685-a12b-291dbd0525f2', '2019-05-07 13:17:28', '3', '阿菲菲赞了你标题为：“啊是大”的文章', '0');
INSERT INTO `pushinfo` VALUES ('1198e95e-4c61-4857-870a-cc7d2217e17e', '阿菲菲', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-07 13:37:06', '2', '阿菲菲收藏了你在问题“啊是大”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c551d8c4-c26d-44e1-bf1b-47fea44ca7ca', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:37:11', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6d87ae34-8b46-4d2e-8267-659bb57858e1', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:37:13', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3dfc4161-7462-4989-bf90-b41c02f7457c', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:37:19', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('11e9bfb3-e778-4ec2-87f0-98c6b2dc4bd1', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:37:20', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('68114851-ea84-4ed1-ba15-2487fc3ff252', '阿菲菲', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', '2019-05-07 13:37:43', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6344c72f-1017-4621-a5d3-d6c1d992e1d0', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:32', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1c4de93e-67b9-45f8-8d4b-6952ddcc250f', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:35', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('75a8dedc-600d-44e1-b6ae-0275b273122a', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:35', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('807664a0-968a-4fd5-933a-7608b40aac30', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:35', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4faa37b3-753a-47f1-af53-101f83ad028d', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:36', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d594697e-a8ef-496a-864d-2ed2a07ad83c', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:36', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cf98212a-279f-49b8-8825-5b7195a5d597', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:36', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e9e279ca-c00d-4648-95a0-e1bc7f651ce0', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:36', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bafbdfa5-4295-4a29-89ea-71a4dd60d7eb', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:55', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bb24edfc-b820-4496-ba23-3f807bada7f7', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:55', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f1be2f80-0a62-473f-8f74-5131e4f412ae', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:56', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('83f6ac20-9956-4b8f-87d6-9ba99100bff7', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:56', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('854b5f04-d202-4328-8bc3-79b058f1004c', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:40:56', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1a8234c1-a4dd-4ecc-a195-1aa98b35d7fa', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:41:25', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3ac37c6d-2187-4cc4-81f5-012bd55f25a9', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:41:25', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1d81dae7-b9cd-4dec-94b9-62bf4ae3784c', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:41:25', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d59af954-f951-45e6-bcb0-928a9d9ac9fb', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:41:25', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('37f7c715-7c53-49da-9469-6dd4ffae54a3', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:41:26', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2a0d16c5-5507-467f-8ee9-9928de7e173a', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:41:26', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('24cec164-b827-4470-9c24-3afa09f7848e', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:43:20', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3bcf3745-b374-41a2-8a0b-99e54d4365b5', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:43:22', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('17265f94-6bed-4ec1-9ccc-b89d392e62cc', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:44:32', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('7b58af5a-7b69-4e1d-8db5-44e67e9dc271', '阿菲菲', '阿菲菲', 'caf9e628-b02e-4f03-a1c1-b6fa5d446744', '2019-05-07 13:46:25', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1ef84cc7-8bbb-4eb2-9cc6-684fff0a08c0', '阿菲菲', '阿菲菲', '80ae0b1e-4fd0-4f69-99c4-9bbd3fd8c661', '2019-05-07 13:46:33', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('56420429-9736-48e8-a535-63b28b8f01e9', '加菲猫', '阿菲菲', '80ae0b1e-4fd0-4f69-99c4-9bbd3fd8c661', '2019-05-07 13:46:48', '2', '加菲猫收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('01dd7bc6-b035-4a8a-bc5b-3018f559b8e9', '加菲猫', '阿菲菲', 'caf9e628-b02e-4f03-a1c1-b6fa5d446744', '2019-05-07 13:46:50', '2', '加菲猫收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('eb374b7e-9a0a-4dd9-9b07-046a2ce6b5e3', '加菲猫', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', '2019-05-07 13:46:52', '2', '加菲猫收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dc21904d-4003-47af-bba8-d3f1e4d41a7f', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:46:54', '2', '加菲猫收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('45717195-31f8-4ee2-bbc0-cd0c9996cf13', '加菲猫', '阿菲菲', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', '2019-05-07 13:47:29', '2', '加菲猫收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('599dd9b8-1a9c-4c39-bb8b-01d8b4b6b206', '加菲猫', '阿菲菲', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', '2019-05-07 13:47:32', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5390ce4f-26ec-4752-9735-c5660c83228d', '加菲猫', '阿菲菲', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', '2019-05-07 13:47:36', '1', '加菲猫反对了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4523dea9-a428-4825-af85-26db104d4773', '加菲猫', '阿菲菲', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', '2019-05-07 13:47:37', '0', '加菲猫赞同了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b259eb85-948f-40a6-9087-c56b16b59665', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-07 13:48:13', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9b206888-f6e2-49c6-97a7-2a93731b3e71', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-07 13:48:15', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ba2a4d7f-1ebd-4b3a-a06a-199023d034d4', '阿菲菲', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-07 13:48:17', '0', '阿菲菲赞同了你在问题“阿三”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5d4a8c35-2f9f-4c7d-9135-3256dd38ab9d', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:20', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0f0576c7-c2b6-4179-a9d6-16c06b2c2da6', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:21', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8f5c5a02-2878-475d-b2e5-05b24dc88610', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c3632d77-f389-4f25-9038-bac5d37cdafa', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('3558ffdf-3c3c-4169-a0d4-044b5f5610af', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('aef05ba8-c1ce-4d35-8328-51d14133e89b', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('32746612-82d7-48aa-9166-48c5365cf0d1', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b6b4d598-9625-4564-ab53-7fa04ab5ac50', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '0', '阿菲菲赞同了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ca3fc92d-0648-443d-a1f7-e36a7992aca2', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:23', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('92db1629-3434-48a9-a5de-80c4a555affc', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('63baf713-b1cf-442a-a85c-8ace00f91df4', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4f775bf9-14c0-41f8-94d7-0059dde4928a', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cf703f6d-522f-4daf-b56c-8677f21a547a', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('57f73272-e666-45c7-9688-cd77f7ca13e3', '阿菲菲', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:25', '0', '阿菲菲赞同了你在问题“额为嗡嗡嗡”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('95c4757f-418d-4fb6-95f9-3b546eb5bf1a', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('226add62-0cbd-43ae-8e65-36586f1bf638', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('de91e9b3-dbc2-4656-a351-ba720dc4fc40', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('72e4aa81-852e-48be-94ca-949d60259364', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9dc1aa95-4f55-495d-8a77-53f11f754704', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:27', '0', '阿菲菲赞同了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('61f5acf4-cc8d-4139-bfa1-a58ae92c1529', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:28', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e589dcaf-b2bc-4244-9caf-a2a7803ceded', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:28', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('aa002c26-ff4c-4fa4-9d7c-440d44a15dab', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:29', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8b4ca0d8-61e8-49c0-a97a-0e61108dd208', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:29', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('72ffa477-0d71-4875-8dd5-488cfbefac1d', '阿菲菲', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:29', '0', '阿菲菲赞同了你在问题“按时大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fc33b890-128b-4b60-a768-11e7c6ebb068', '阿菲菲', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-07 13:48:30', '0', '阿菲菲赞同了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c9b0d784-3ac7-4a54-9903-a501fda62f7e', '阿菲菲', 'shenshenshen', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-05-07 13:48:34', '0', '阿菲菲赞同了你在问题“阿文实打实大苏打”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dbf3cb3a-564f-443e-ba59-99e22d9ec3d3', '阿菲菲', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-05-07 13:48:36', '0', '阿菲菲赞同了你在问题“都323423二点烦人&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('eb150665-ef63-4748-8f50-87728bf64ce9', '阿菲菲', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-07 13:48:38', '2', '阿菲菲收藏了你在问题“啊实打实打算”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ce5a8ac7-1a62-4e89-bf19-5d9c39ed5e3f', '阿菲菲', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:49:24', '2', '阿菲菲收藏了你在问题“对方的杀人佛挡杀佛委任为”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('47b45e44-7dc4-4cee-91be-c3eecac61fff', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:49:31', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b8b783d7-f9d5-43fd-8f2c-2120013d4e06', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 13:49:33', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e26daea4-f007-415c-aede-2ae59ea0f355', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:02:19', '6', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('fa6d7ee8-6dec-4a2e-b35e-a4c92f8dbd11', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 14:02:29', '6', '阿菲菲评论了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f0df2bf8-24ae-4d1e-bc09-4b60e7557ed1', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:31:39', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2af2cb10-cc5d-4694-9fb5-4a256362d0cd', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:31:39', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('12152d7e-c0d5-479f-87c8-7466290192d7', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:31:45', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('8808f7c8-8188-466e-92c2-145a152fc388', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:31:45', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('bb0d0eec-bc1f-44d7-91f7-1a842cf82272', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:31:47', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('1c42704a-4a51-448d-93c0-41f0292962e3', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:31:47', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('30d53ff2-7072-4442-8022-0e0411215a5a', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:16', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('4160991f-efe2-4694-abb6-f48090a06b76', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:16', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('dff6779c-9314-4c54-b2d8-714ab6d3eac9', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:22', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d50488d5-dbbd-4d1a-9ca0-38013e74b1ac', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:22', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('4178d077-89fc-4c81-b731-454dd40a040b', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:23', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('80b784b0-fe91-42a9-b5aa-a95a557ca1de', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:23', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('9bf635ac-d9e0-47c9-b0f0-357e84c58d33', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:24', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a9967d62-bc6f-4434-8f46-06a2f6def4bd', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:24', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('59c0d32c-09cb-481f-bfe5-b800e5bcf950', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:53', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('f4ca6526-8f75-45a6-81ce-1e6d61754120', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:34:53', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0f85771a-3d8f-48c8-8038-76ca2ac74476', '阿菲菲', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:35:07', '8', '阿菲菲回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('d9cb6d6a-55a1-4019-9e16-a8fab69df669', '阿菲菲', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:35:07', '8', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('901e9e98-1998-4e58-b7f6-e53744ad39a1', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:37:13', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('9a1d647d-6798-49d0-96a9-705297c73cc5', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:37:13', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('8caeb9f6-e87f-4974-ab66-7ae8fc1434a9', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:38:05', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6c3fd0aa-9640-4740-ab40-28ddf4a9f817', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:38:05', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('e37ce643-b7c5-4d9e-b01d-47b781587141', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:43:57', '6', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('86ed9df4-5b95-48b7-8fac-5f2aa78d8dd3', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:45:53', '8', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('06e89c9e-fd95-478c-8c95-111762a8cb1f', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:45:53', '8', '阿菲菲回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('b1c70cea-4106-4b34-bea6-35eb7b68197a', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:52:27', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('af478d01-2d39-439e-b730-ef36bb94d9a8', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:52:27', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('4b490a97-001f-4a09-9c78-0f104b823413', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:52:39', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4b936239-2d8f-4d75-9f0d-5a0293cb5ef8', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:52:39', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('0699bc46-56f3-44b4-8f63-77d08eef83c4', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:52:57', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ff12c66e-4d75-4ade-8e1d-78565b62f6f2', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:00', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ce2a191c-a2fd-4cf5-80c7-ed677bd60add', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:00', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('ffbbed87-0d93-48f2-bbe2-c48a402d2662', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:10', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('a0878fa9-1af3-4161-a2b8-52d15b4bd443', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:12', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c0ed57b0-50e3-4107-9303-e0570239f398', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:12', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('8136d70f-dab2-4150-b165-f17a7898adb5', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:39', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bea808b3-ed06-476d-b63a-e12ccb1add88', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:41', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('56d7d81b-ea62-4a62-ac91-e47a21fc6e51', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:43', '8', '加菲猫回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('9cafd716-fafb-4373-9b4f-8fd794f56a3d', '加菲猫', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:53:43', '8', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0f30fd04-54c7-459f-a55e-791a43f479f2', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:13', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5e744a58-4340-4e97-8a8e-ee881e45eca7', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:15', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('47c61e34-eba6-43e0-a196-b7893cab49f5', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:16', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ef5cc2fa-6208-4f3d-b2ca-e8baea509152', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:16', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e7717b26-a7f0-411e-8eeb-0c6bb1a3c6c5', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:17', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e8d280ac-cc61-4ab3-b68a-7253ee952500', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:18', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('5ae9ca06-2a18-41a0-b00a-2d05f6936289', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:18', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cf1feb83-0f50-4142-813a-4586789385ec', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:54:19', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4948c98a-9b19-4e45-86b8-57a98cebefca', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-07 14:57:10', '6', '加菲猫评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('82cb11c6-e7a1-43b7-b9ea-5e55b1fe020a', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 14:57:32', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('69da7237-4752-4469-aa91-06ecf9d92fa4', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 14:59:43', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('23e55d79-7d8c-4e12-9a68-51999badac99', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 14:59:44', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('c622f9e2-dada-47de-b25d-baeae64d8763', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 15:00:19', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('d2f6ca71-30d9-45fe-9bf9-88e6e38f3719', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-07 15:00:31', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('27ca34de-2c9a-45be-a24d-3a5532cbfcc4', '阿菲菲', '加菲猫', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8', '2019-05-07 15:02:55', '3', '阿菲菲赞了你标题为：“aaaaa”的文章', '0');
INSERT INTO `pushinfo` VALUES ('8821e025-60fe-4358-98a2-0070ed93046a', '阿菲菲', '加菲猫', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8', '2019-05-07 15:02:58', '4', '阿菲菲踩了你标题为：“aaaaa”的文章', '0');
INSERT INTO `pushinfo` VALUES ('2995d5a4-6299-46dd-b5b0-961f6d397cba', '阿菲菲', '加菲猫', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8', '2019-05-07 15:03:11', '7', '阿菲菲评论了你标题为：“aaaaa”的文章', '0');
INSERT INTO `pushinfo` VALUES ('62798e5e-141b-42f0-8d9c-5bd55e66108a', '阿菲菲', '加菲猫', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8', '2019-05-07 15:03:17', '7', '阿菲菲评论了你标题为：“aaaaa”的文章', '0');
INSERT INTO `pushinfo` VALUES ('bac06bd1-d8b0-4c11-b492-6a85a836084c', '阿菲菲', '加菲猫', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8', '2019-05-07 15:03:46', '5', '阿菲菲收藏了你标题为：“aaaaa”的文章', '0');
INSERT INTO `pushinfo` VALUES ('1dbf61a1-20cf-4d72-9585-d50b7bd9443c', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:09:24', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('e973af61-85f5-425f-aa76-1e949d5f6a4e', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:09:27', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('288f0f90-6953-4b40-970e-a363b2eacb71', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:09:29', '2', '阿菲菲收藏了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('b2a5ed66-d7db-42e5-9c64-73a1ca63ea02', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:35', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('931df7ea-822e-4ed7-8b49-6fe33dd8a624', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:35', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('f58b07ae-8ced-4588-a4d1-d0f5ad2bd25d', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:35', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d9b3ebd9-e257-44c4-b46a-1529f74a0925', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:36', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ea95c617-f990-491f-a3e7-9296c96e83db', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:36', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('d0a77cbb-3576-4be2-8204-0e693238915e', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:36', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('788d0d82-0afd-41fb-8305-0602b8fbaea5', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:36', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('11518d04-4dff-42dc-b70d-c371ff0311b1', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:36', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('790d666f-4f37-435e-b8b3-f5dbe88937e7', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:37', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2542c398-f519-4d10-9669-02b2594a945a', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:37', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ce73ad00-30f5-4360-b856-fc9b39a7b133', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:37', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('aae08ebd-0774-4e5f-8501-4da38cab3841', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:37', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('ebd7f51a-1fd8-4b66-ace9-209925f5d25a', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:37', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('cc974d83-8fe1-403e-92e9-2e086707d852', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:37', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('2844f5e8-c2a0-4f44-bac9-6e213ab36319', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:38', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c6d40c13-dd9d-4f4c-b44b-38acc355ea79', '阿菲菲', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-08 13:09:38', '2', '阿菲菲收藏了你在问题“上的v”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('6af8aab8-f1b1-4bb2-b858-73e2623cc970', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-08 13:09:40', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('4aca6ec2-98e2-47bf-b81c-d4ac0b47808c', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-08 13:09:40', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('edb2cb95-286e-4a40-b05c-a924f32ba44b', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-08 13:09:41', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('314ec92e-4ca9-453d-8632-916afc88c411', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-08 13:09:41', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('bf5ffd99-b2eb-45ba-b2b9-56e369e37548', '阿菲菲', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-08 13:09:41', '2', '阿菲菲收藏了你在问题“<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('c0399d15-335a-452f-b3eb-a9cc4937f39e', '阿菲菲', '加菲猫', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', '2019-05-08 13:09:49', '2', '阿菲菲收藏了你在问题“阿三打撒21阿3&nbsp;”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('755e0c23-5601-4b89-aa1d-3d1f57b13ab4', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:09:55', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('c6e6eb32-5e2f-474a-a35f-defc7935e1d5', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:09:56', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('bbb100c1-3e8b-4849-8e83-c9fa6acde506', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:09:56', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('51134651-6c8c-44c1-a47f-5ac4d10e7244', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:09:56', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('686b2d3e-769e-4f92-b14a-66b3884b6938', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:09:57', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('14486f5b-0d7e-49ba-a0f8-4006cff1489f', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-08 13:09:58', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('36a4b7f6-370c-49b7-8629-18470ab42f6c', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-08 13:09:59', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('11af5b1d-6776-481e-82b7-a65797c9b18f', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-08 13:09:59', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('0d86a8ab-a0f7-495d-b28c-e476bc00621e', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-08 13:09:59', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('8575961f-5e56-4ffd-ab2f-5c9e26b890ee', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-08 13:09:59', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('c6520c7f-ce38-44f5-a178-7069fab028be', '阿菲菲', '加菲猫', 'a639c2d9-942c-414b-9422-5e6f15a6400f', '2019-05-08 13:10:00', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点3</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('0e11ac25-8b6d-4ecb-a9ea-bd6cc1a64733', '阿菲菲', '加菲猫', 'a97ee283-c951-44b2-bdd0-c5b022c8baea', '2019-05-08 13:10:05', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点5</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('b6bc0998-95ab-4d91-8df8-f4dad3651c49', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:11:51', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('e38f0595-630b-475d-8ea3-c0957fb61ffb', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:13:26', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('80182532-2990-421a-b66d-164a91ce948b', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:18:37', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('f6287be6-f864-4cf7-90b3-aec397f82dbe', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:18:45', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('ad38615f-2bb9-4899-a9b0-caf60d447297', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:31:00', '6', '加菲猫评论了你在问题“看看”下的回答', '1');
INSERT INTO `pushinfo` VALUES ('d2da092c-9e78-4805-85e9-bebfdee602bb', '阿菲菲', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:31:46', '8', '阿菲菲评论了你在问题“看看”下的回答', '0');
INSERT INTO `pushinfo` VALUES ('0eda10e5-c473-4971-a4a3-30ba6bf30ff4', '阿菲菲', '加菲猫', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:31:46', '8', '阿菲菲回复了你在问题“看看”的答案下的评论', '0');
INSERT INTO `pushinfo` VALUES ('5b00b0a7-c288-4692-b91c-5fa383cdcca1', '加菲猫', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:38:06', '7', '加菲猫评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('dab3d90c-49fc-4644-b404-c1957da634c3', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:38:14', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('c744fd86-ad1f-4a18-9adc-2f27a374fdd5', '加菲猫', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:38:18', '7', '加菲猫评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('7b512692-4001-4cc1-8bad-8654dc4faf5c', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:46:54', '6', '阿菲菲评论了你在问题“看看”下的回答', '1');
INSERT INTO `pushinfo` VALUES ('c89d8cda-dc4b-4eb2-8e73-af444d0017cb', '加菲猫', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 13:47:05', '6', '加菲猫回复了你在问题“看看”的答案下的评论', '1');
INSERT INTO `pushinfo` VALUES ('e8573c79-ecde-4b62-a8c5-532adff25877', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:47:17', '7', '阿菲菲评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('53a5ee21-3c56-4a32-b4c7-cb67104da14d', '加菲猫', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-08 13:47:21', '7', '加菲猫评论了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('7986336c-d9da-4473-85dd-9e3aaa07edf6', '加菲猫', '阿菲菲', '4ce4fd40-35fd-43ca-bbce-8a46e566f59f', '2019-05-08 13:47:21', '9', '加菲猫回复了你在标题为“<b>阿三发射点</b>”下的评论', '1');
INSERT INTO `pushinfo` VALUES ('7cafa8c5-79d9-400a-93e2-9952c7a5a15b', '阿菲菲', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-08 14:03:52', '6', '阿菲菲评论了你在问题“看看”下的回答', '1');
INSERT INTO `pushinfo` VALUES ('482d9711-cc64-4dc6-b403-09e8bb7944a8', '加菲猫', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-08 14:04:02', '2', '加菲猫收藏了你在问题“啊是大”下的回答', '1');
INSERT INTO `pushinfo` VALUES ('3df76dba-e55a-4124-936e-a340dfc4fb91', '阿菲菲', '%E5%8A%A0%E8%8F%B2%E7%8C%AB', '30d60c79-dd80-4f1f-96ad-f70a69b47834', '2019-05-08 16:16:08', '10', '阿菲菲私信了你：“按时大苏打”', '0');
INSERT INTO `pushinfo` VALUES ('fbb2483c-8d19-454f-8ccd-7fd0c5d1e566', '阿菲菲', '加菲猫', '8e25840c-8ae7-4abe-bbe2-2cea37335c0f', '2019-05-08 16:17:23', '10', '阿菲菲私信了你：“请问人情味热”', '0');
INSERT INTO `pushinfo` VALUES ('547596e4-7846-4393-b835-cae3753957ae', '加菲猫', '加菲猫', '2df26a41-0384-4ccd-8140-e96d88aaa1ca', '2019-05-09 12:20:12', '10', '加菲猫私信了你：“asdas&nbsp;”', '0');
INSERT INTO `pushinfo` VALUES ('a0f8f12a-1c44-447b-b25b-40cbad51dc4f', '加菲猫', '加菲猫', '2a380e41-8b68-4cba-af3b-b5228ff69ed0', '2019-05-09 12:20:26', '10', '加菲猫私信了你：“asdasd&nbsp;”', '0');
INSERT INTO `pushinfo` VALUES ('ccb3f18c-003e-4068-a91d-365dfc5ae6ae', '加菲猫', '阿菲菲', '4406be75-ef1d-47dc-b2f5-fb2dfeb77573', '2019-05-09 12:20:39', '10', '加菲猫私信了你：“asdasd&nbsp;”', '1');
INSERT INTO `pushinfo` VALUES ('dbf125bc-e03c-458a-97c9-3a18dca9d9e8', '阿菲菲', '加菲猫', '7f67ade5-b067-46a6-b1aa-e6a00d812e5b', '2019-05-09 14:11:35', '10', '阿菲菲私信了你：“啊是大”', '0');
INSERT INTO `pushinfo` VALUES ('76b04026-07fd-4c08-9004-8aefbeb3279a', '加菲猫', '阿菲菲', 'c5ad4745-5cdd-4e6a-b841-56a25a9a58f1', '2019-05-09 14:11:47', '10', '加菲猫私信了你：“asd&nbsp;”', '1');
INSERT INTO `pushinfo` VALUES ('ebccf705-4e83-4d63-80a7-f79535a8295d', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:24', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('e9362b19-3da0-479d-b02f-6f3615abca51', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:28', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('e84a9ea5-5aef-46fb-a5d1-9cae66d5753e', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:28', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('9c398b3e-1852-4a0f-a5cc-a56fd7b10b20', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:29', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('9ecfa8d4-9412-42a2-832d-d5d4a03f7b12', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:29', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('a4686383-dfb3-407f-aae7-2518c3cb6661', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:29', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('6787eecd-cfa5-4bc3-b496-abee01fc6776', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:29', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('7ef1b162-6353-473e-a48c-c0d8267e17ba', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:15:30', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('d93f1470-38fa-4285-84bd-0412144fac32', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:15:30', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('a9fbd417-4e63-4e28-9a4e-d454d043c381', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:15:31', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('4aef4e2f-2894-4686-bc54-44d9be1c9ba6', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:15:31', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('6756c9f9-d834-4159-a6f6-a329ec3fa400', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:15:31', '5', '阿菲菲收藏了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('fced0559-570f-4974-aea8-d6d47c9b7a6f', '阿菲菲', '加菲猫', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17', '2019-05-09 14:15:32', '5', '阿菲菲收藏了你标题为：“<b>阿三发射点</b>”的文章', '0');
INSERT INTO `pushinfo` VALUES ('2796b0e9-1c67-4dec-8947-3f48cee90cd9', '阿菲菲', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:15:46', '7', '阿菲菲评论了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('652c7746-9946-47c6-9c6e-c3b065cbeb94', '加菲猫', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:16:49', '7', '加菲猫评论了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('9d7252e3-7663-43fb-938c-9ac95920f151', '加菲猫', '阿菲菲', 'dc97b18a-f9e6-48f5-930f-c07380348b1b', '2019-05-09 14:16:49', '9', '加菲猫回复了你在标题为“asdasd&nbsp;”下的评论', '1');
INSERT INTO `pushinfo` VALUES ('6c12cff9-0463-4790-9932-7517c4267dbb', '加菲猫', '加菲猫', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:18:58', '7', '加菲猫评论了你标题为：“asdasd&nbsp;”的文章', '0');
INSERT INTO `pushinfo` VALUES ('6680b997-47a2-4b7c-b8b8-59e4a9cb4e9b', '加菲猫', '阿菲菲', 'e2626f4c-3179-45e2-ae34-5df19d8ece30', '2019-05-09 14:18:58', '9', '加菲猫回复了你在标题为“asdasd&nbsp;”下的评论', '1');
INSERT INTO `pushinfo` VALUES ('5f3468cb-6a9d-422e-9bd5-f1fe5a12e1d7', '阿菲菲', '加菲猫', '1beab1b5-f994-4d40-b6a1-f96ff270cfe8', '2019-05-09 15:07:00', '10', '阿菲菲私信了你：“啊是大”', '0');
INSERT INTO `pushinfo` VALUES ('a2d5be25-43ce-495e-b3c2-650686d908b1', '阿菲菲', '加菲猫', 'a00675f0-3d03-405b-beb5-cf6712f6b99f', '2019-05-09 15:11:16', '10', '阿菲菲私信了你：“按时大苏打”', '0');
INSERT INTO `pushinfo` VALUES ('99ed69db-23ff-4dea-8494-77b87cc32e1e', '加菲猫', '阿菲菲', '15b672a7-1a0a-40c0-9ed5-367704e77e28', '2019-05-09 15:12:43', '10', '加菲猫私信了你：“asda&nbsp;”', '0');
INSERT INTO `pushinfo` VALUES ('0a2299d2-0e69-4a31-91e3-3466c299d6cd', '加菲猫', '阿菲菲', '45de1609-6054-4aea-9e0f-325230fecc00', '2019-05-09 15:21:46', '10', '加菲猫私信了你：“11111111”', '1');
INSERT INTO `pushinfo` VALUES ('55366df2-c0aa-4e8b-bed6-7953d1fa0d35', '加菲猫', '阿菲菲', '1c754f06-9a74-4924-bd90-69eb96cf9f0b', '2019-05-09 15:21:50', '10', '加菲猫私信了你：“2222222”', '0');
INSERT INTO `pushinfo` VALUES ('18e18208-7fe7-479d-ac4a-43f346b9d09e', '阿菲菲', '加菲猫', '9861b778-0692-4334-a8e5-0eb669e5ce08', '2019-05-09 15:22:05', '10', '阿菲菲私信了你：“按时大苏打”', '0');
INSERT INTO `pushinfo` VALUES ('cc74f330-e516-45d7-9b47-b33d9940c566', '阿菲菲', '加菲猫', 'c09a32e3-9652-46b7-a2cd-3b2bf4ae578e', '2019-05-09 15:23:57', '10', '阿菲菲私信了你：“啊是大”', '0');

-- ----------------------------
-- Table structure for questioninfo
-- ----------------------------
DROP TABLE IF EXISTS `questioninfo`;
CREATE TABLE `questioninfo` (
  `questionid` varchar(255) NOT NULL,
  `contant` varchar(5000) DEFAULT NULL,
  `isopen` int(11) DEFAULT NULL,
  `creatdate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `hot` int(11) DEFAULT NULL,
  `creatuser` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `answernum` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of questioninfo
-- ----------------------------
INSERT INTO `questioninfo` VALUES ('33d20f62-384d-482e-a2d4-84e0bf5cf899', '啊啊实打实的', '1', '2019-04-24 20:50:37', null, '20', '加菲猫', '8', '2');
INSERT INTO `questioninfo` VALUES ('d1695356-6bd1-465f-a82b-91265f028d5b', '区瓦尔地亲吻青蛙的', '1', '2019-04-24 20:50:52', null, '0', '加菲猫', '24', '0');
INSERT INTO `questioninfo` VALUES ('3380a568-c866-45a5-8537-dac3d69abec3', '按时大苏打', '1', '2019-04-24 20:51:01', null, '140', '加菲猫', '11', '1');
INSERT INTO `questioninfo` VALUES ('62b27fb1-10bf-443f-b9b9-81afcfdc3ecb', '啊实打实打算', '1', '2019-04-24 20:51:11', null, '120', '加菲猫', '3', '1');
INSERT INTO `questioninfo` VALUES ('c887f09f-3834-49b1-acc2-5441992b93a7', '阿文实打实大苏打', '1', '2019-04-24 20:51:20', null, '90', '加菲猫', '10', '1');
INSERT INTO `questioninfo` VALUES ('12d8dcdf-93f8-448b-8238-8138cb05a8a5', '撒大苏打飒飒的<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/12.gif\" alt=\"[泪]\">', '1', '2019-04-24 20:51:32', null, '20', '加菲猫', '15', '1');
INSERT INTO `questioninfo` VALUES ('9c6345d3-8721-4177-8669-5900e860f893', '按时大苏打<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/12.gif\" alt=\"[泪]\">', '1', '2019-04-24 20:51:46', null, '15', '加菲猫', '20', '1');
INSERT INTO `questioninfo` VALUES ('39751e7d-ee99-48f3-9461-aeac020795d3', '阿萨啊啊1323让微软<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/50.gif\" alt=\"[熊猫]\">', '1', '2019-04-24 20:51:59', null, '45', '加菲猫', '21', '2');
INSERT INTO `questioninfo` VALUES ('4ae2299b-5c0f-4f72-8cd7-9a9e78c8ef14', '都323423二点烦人&nbsp;', '1', '2019-04-24 20:52:10', null, '85', '加菲猫', '3', '1');
INSERT INTO `questioninfo` VALUES ('ecd660d8-368e-4b6d-930a-0af8f636d41b', '阿三打撒21阿3&nbsp;', '1', '2019-04-24 20:52:18', null, '20', '加菲猫', '18', '1');
INSERT INTO `questioninfo` VALUES ('61c61fb7-b7e4-472b-87b2-74af4db7c213', '对方的杀人佛挡杀佛委任为', '1', '2019-04-24 20:52:35', null, '530', '加菲猫', '13', '1');
INSERT INTO `questioninfo` VALUES ('2ab46893-acaa-45f7-bbfb-33328aa38c3a', '额为嗡嗡嗡', '1', '2019-04-24 20:52:43', null, '395', '加菲猫', '18', '2');
INSERT INTO `questioninfo` VALUES ('9a5aef04-96ba-4a05-8740-f2ed7c496390', '<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/38.gif\" alt=\"[哼]\">', '1', '2019-05-03 18:51:28', null, '290', '加菲猫', '4', '1');
INSERT INTO `questioninfo` VALUES ('654338eb-91fa-4b02-8389-7f922a3c3d53', '上的v', '1', '2019-05-03 19:18:13', null, '25', '加菲猫', '20', '1');
INSERT INTO `questioninfo` VALUES ('f3c8792f-561b-47c3-a93a-0ce2e7861f9e', '阿三', '1', '2019-05-03 19:19:51', null, '785', '阿菲菲', '2', '8');
INSERT INTO `questioninfo` VALUES ('437da0bb-56bb-4b26-ae58-0ae0f60f9cae', '啊是大', '1', '2019-05-04 13:46:50', null, '30', '阿菲菲', '19', '2');
INSERT INTO `questioninfo` VALUES ('29c64f35-071d-4f7e-8fd0-62537c4a8405', '看看', '1', '2019-05-04 13:49:12', null, '85', '阿菲菲', '2', '7');
INSERT INTO `questioninfo` VALUES ('52da7601-d30b-45fc-8918-35a67c2c4d62', '阿三打撒', '1', '2019-05-08 14:23:36', null, '70', '阿菲菲', '20', '7');

-- ----------------------------
-- Table structure for questiontype
-- ----------------------------
DROP TABLE IF EXISTS `questiontype`;
CREATE TABLE `questiontype` (
  `typetext` varchar(255) DEFAULT NULL,
  `typecode` int(255) NOT NULL,
  PRIMARY KEY (`typecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of questiontype
-- ----------------------------
INSERT INTO `questiontype` VALUES ('计算机', '1');
INSERT INTO `questiontype` VALUES ('文学', '2');
INSERT INTO `questiontype` VALUES ('数学', '3');
INSERT INTO `questiontype` VALUES ('物理学', '4');
INSERT INTO `questiontype` VALUES ('电影', '5');
INSERT INTO `questiontype` VALUES ('音乐', '6');
INSERT INTO `questiontype` VALUES ('历史', '7');
INSERT INTO `questiontype` VALUES ('土木工程', '8');
INSERT INTO `questiontype` VALUES ('水电工程', '9');
INSERT INTO `questiontype` VALUES ('数码', '10');
INSERT INTO `questiontype` VALUES ('汽车', '11');
INSERT INTO `questiontype` VALUES ('军事', '12');
INSERT INTO `questiontype` VALUES ('政治', '13');
INSERT INTO `questiontype` VALUES ('宗教', '14');
INSERT INTO `questiontype` VALUES ('心理学', '15');
INSERT INTO `questiontype` VALUES ('二次元', '16');
INSERT INTO `questiontype` VALUES ('科幻', '17');
INSERT INTO `questiontype` VALUES ('科学', '18');
INSERT INTO `questiontype` VALUES ('语言学', '19');
INSERT INTO `questiontype` VALUES ('生物学', '20');
INSERT INTO `questiontype` VALUES ('化学', '21');
INSERT INTO `questiontype` VALUES ('体育', '22');
INSERT INTO `questiontype` VALUES ('美食', '23');
INSERT INTO `questiontype` VALUES ('其他', '24');

-- ----------------------------
-- Table structure for question_care
-- ----------------------------
DROP TABLE IF EXISTS `question_care`;
CREATE TABLE `question_care` (
  `rowguid` varchar(255) NOT NULL,
  `be_cared_questionid` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of question_care
-- ----------------------------

-- ----------------------------
-- Table structure for record_user_against_answer_article
-- ----------------------------
DROP TABLE IF EXISTS `record_user_against_answer_article`;
CREATE TABLE `record_user_against_answer_article` (
  `rowguid` varchar(255) NOT NULL,
  `against_user` varchar(255) DEFAULT NULL,
  `answerid` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `to_user` varchar(255) DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `articleid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of record_user_against_answer_article
-- ----------------------------
INSERT INTO `record_user_against_answer_article` VALUES ('75c36d73-c385-43b3-aa13-c9863c2c50e4', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:26', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f87923c3-b869-409a-8291-8a84eed8980e', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:30', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('aee43386-0fdb-4651-8b12-a232c7cf00c1', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:31', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e4574432-e489-4b56-a33b-66114918bdde', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:31', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0af3af2a-2697-4e64-af9c-16ffabc226fd', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:31', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('15ebfd67-fe90-4961-b735-026730190fff', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:32', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('7841aedb-9ba6-4931-a0e4-148e9c1612ea', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:32', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('fad6f362-6eba-4727-9f84-70ebbbedc828', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:32', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('d2566afc-36fa-4704-92ee-5d47b29cef60', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:13:32', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('2ebb7223-fd34-4437-a1ca-b666c4649a04', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:00', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e44bc027-c91e-40a4-93b4-864fedbc4e10', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:03', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('55cf5be2-9f35-43a6-85ab-f0b5173b5975', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:04', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('8f43430b-f91b-4535-8980-5508ba0be026', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:04', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9325a3ee-1a81-4ef5-960e-6667c334724e', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:04', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('51b77bcf-b1e6-49c5-91af-505774612b88', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:04', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9a91e4fb-5ea6-43d9-af98-ddb5350bc83c', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:05', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f30dc939-2378-4663-951b-e690759d2ac8', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:05', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('ac8d3b28-c812-4bb8-b557-b0c2120d422b', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:05', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0e728391-0d97-4069-870e-d96a6111c183', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:05', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('61431c41-9cee-4e83-826f-87d9fd22fd2b', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:05', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('04aac025-c8ef-41b8-9ec6-a8adddf7a4e7', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:06', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('1c4dab25-b7f0-405d-be52-71a67580153a', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:06', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5b03a494-d632-4898-bd29-269e2fe567fa', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:06', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('fd69b729-05e2-46a1-8231-b41c2eece61c', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:16', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('521d7589-c6c3-4998-a260-ed15be98880d', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:17', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('609acb05-cde7-4a91-970e-8b770f7f97cb', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:17', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9d627023-2c87-4574-b184-3980d58def5c', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:17', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('ad8b6cc2-91eb-4682-911c-15c59f49b8a1', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 15:15:17', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('af4a1590-c7bb-4ce0-be4d-85272ff80643', '加菲猫', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '2019-04-18 15:17:23', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0ea62893-f4a5-415a-ad56-300de7663242', '加菲猫', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '2019-04-18 15:17:24', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('3562b01b-19e4-4c56-8d26-0c99fa330b78', '加菲猫', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '2019-04-18 15:17:24', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('c380c624-4cfb-482a-bd93-354d9e193a78', '加菲猫', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '2019-04-18 15:17:24', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('32b19246-c446-43b7-bb86-4557920c2e84', '加菲猫', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '2019-04-18 15:17:24', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('10e85893-3560-4941-8275-e7d2a759b03f', '加菲猫', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '2019-04-18 15:17:24', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('8d0cbb01-b697-4d87-8543-4dd6b96b8c0f', '加菲猫', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '2019-04-18 15:17:25', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('eeebdb4f-0d00-47aa-ab32-9e44f3907f7d', '加菲猫', '3c0a891e-7207-4545-9421-f8fa284c00e6', '2019-04-18 15:17:26', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0663cfc2-ad0b-4ee5-83b7-0edf005450ac', '加菲猫', '3c0a891e-7207-4545-9421-f8fa284c00e6', '2019-04-18 15:17:26', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('6336657a-ccee-42d6-8629-5346b1390e86', '加菲猫', '3c0a891e-7207-4545-9421-f8fa284c00e6', '2019-04-18 15:17:26', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('dc9b60f3-78f9-487f-99d5-6fe8703ed67b', '加菲猫', '3c0a891e-7207-4545-9421-f8fa284c00e6', '2019-04-18 15:17:26', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('aa85b04f-9d5d-4491-a1fe-577f561d271f', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:43', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('734da796-b146-4329-a994-bc863653ff4d', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:43', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e1ee073e-5387-419c-aae9-eb59c48266c5', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:43', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('3f325201-085c-4f4b-992c-8ea47f89a963', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('56b49ff2-6391-473e-bd22-d1b967e44df0', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('66fc188e-0971-4925-a4ec-680a1c83b380', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e032866f-3c88-425e-b218-0f96a95c1f3c', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('adc594a5-5413-4d8e-94e9-eb756482feeb', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('63cf135f-9c9a-46ec-9ee0-25475214d8ec', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('df803456-faa2-4f5f-866e-990d078afefa', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('cdf06083-2a89-470b-865a-920c39b61d38', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('92043b91-e2c2-43ea-865a-a8353c4f91d1', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9ca2cad5-d15a-4d03-bdaa-a81f7bb1f261', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('aefec233-38e6-4034-b642-f39aac64fae9', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('3388c885-59eb-4c41-89a0-7901c8f16c16', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5451268b-282e-43d5-a7ca-edfac9669c4e', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:46', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f2814378-b16c-4ed1-b49f-e3aacf5a9216', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:46', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('45d1ab41-8ceb-423d-a948-6d3d4e46290c', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:46', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('c9425a31-8543-4379-88b7-70dded1a709e', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:46', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0d861554-9a63-4261-a29f-741efd7dfa69', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:46', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9b486e62-4e05-4cea-9a20-94b6da6794f1', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:46', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('48902e84-5d8d-4bcb-bf14-7f87bdcdfaa2', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:47', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e1bc827f-80ce-43d4-a397-c14c3ca70cce', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:47', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9f3c9479-f4ad-4706-b5a6-92cd818fc50d', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:47', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('3243e458-0acf-4c53-baf8-0dbeb4bdf39f', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:47', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0b51d120-243f-442e-93c0-653abe822ddd', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:47', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('8d66441c-b643-41e4-8a6d-459f982ea949', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:47', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('64c18898-771d-40b4-b554-f1325c26f1c9', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:47', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('612aeeb8-02d2-4185-87e4-054ab8804446', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:48', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f68f8c0b-5e08-44b8-aed4-76bb0f8789f6', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:48', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('71877085-e80f-4072-8ad0-2c1702a436cb', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:48', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('d10ff0fc-86f2-463f-a458-a776803b86f2', '加菲猫', '9600475d-ec3e-4309-a781-28485880cb48', '2019-04-18 15:20:48', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5119a74e-c9fa-4d93-9fc9-38ed4e8b0130', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:38', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('906c9fed-1139-442b-9434-2e37a18a478e', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:38', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('add292a0-ab62-4816-980c-8924b24604fc', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:38', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('32923f18-dde4-4edc-9adb-99633a25f7e7', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:38', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('c06fff7f-b923-4902-b5c1-9d315a4a813e', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:39', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('442ffdbe-0cce-42bb-9d40-5b71e5854f63', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:39', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('701fdaca-b7e2-4890-884f-7d61b35dc91d', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:39', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f446dd0e-d553-4ce6-a254-36228b67d9a8', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:39', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('d543cf77-3bf7-43ee-994d-9c953d2817bc', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:39', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('c3f4ea12-06b9-49c7-97c9-3bced08a4cc8', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:39', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('64e2f634-f24c-4183-8ef4-10e460fa04fe', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:56', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('64dccc2e-5b59-4e24-9bde-52997df67943', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:56', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('7172dbe5-5359-4cdb-8369-265914cba0f7', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:56', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b65bf8a2-fc09-4ba8-895f-d16d94883d58', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:56', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('46224587-9652-4e49-b964-07dcb759e7d3', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:56', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('20ab284b-9389-4c55-9a95-5dfd9a54f8c0', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:56', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('49cc01b5-6d06-4988-8040-8ac1f614f7e3', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:56', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b4ebde1d-2799-4d11-91a1-7cff215d791d', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:57', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('d614a486-9ef5-4ed6-bc91-e53705f1a2e6', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:57', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('992b475c-ef3b-428c-bb75-2e9b7ac7e3f3', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:29:57', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9174f0d7-c749-402d-b5f4-3227dd6572f9', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:42', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f56340a6-375d-449b-8e1f-27c3af130210', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:42', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b3ef8049-b788-49fb-afee-430808d4a5dc', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:42', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('43e2d62b-8b31-41c9-86f8-1b32f3ce5f8f', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:43', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f6be3876-6a84-4bd8-99c9-b9e75808eeba', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:43', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b34e5181-7b9c-4c4c-8462-9f6ce090ba16', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:43', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('fa5e1e8f-5435-4ce3-89fd-5a3f39377d58', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:43', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('93049218-523c-4a63-a93c-433ca30974c5', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:43', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('c000b5c2-ca79-40fe-8dc9-4d955d8ca976', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:43', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('baa8c840-6fea-4871-8a11-ad1bcf729918', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:33:43', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e218a057-6479-4ba3-8948-9f9b4aad9293', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('142a0dfd-80d4-438e-a654-dac2065a5bf3', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('24682b3c-114b-4668-8f67-b811296a3d71', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9af171a2-7d18-4624-9857-bd939bdabec1', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('419aaaa4-96b4-4707-b76d-5114aa0fd6c9', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5523d5d8-9197-4445-bd6f-e4b91e2a37f4', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b00685a0-5ea1-45e5-b8ed-cf8c0c2abf3e', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('a268f4e9-e04f-46b6-af05-c7e76f15cb83', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('470a5c21-0d8d-42cc-bbc4-b9a11b8447b3', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:13', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('39b24948-bf38-48df-9b70-6e2f952f9af7', 'fys', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 16:36:14', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('fe587836-1ac0-4c89-9db4-d3b12aa32626', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 22:03:28', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('70a8d912-4026-43b7-af9c-2653c91f98a6', '加菲猫', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '2019-04-18 22:03:28', '天天敲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5d0b0027-9a88-4163-af21-7608bc6cd7ad', '加菲猫', '715a7a3b-52b8-48b4-80d2-e313ce491865', '2019-04-18 22:06:53', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('2e7fdf2a-edf0-4738-8b7e-47a7d9e6b4ae', '加菲猫', '715a7a3b-52b8-48b4-80d2-e313ce491865', '2019-04-18 22:06:54', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5a4e9b24-a2a3-48f9-b459-020eb6df634b', '加菲猫', '715a7a3b-52b8-48b4-80d2-e313ce491865', '2019-04-18 22:06:54', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('42e4c2ee-ec5f-456e-97df-f91d72b74eb1', '加菲猫', '5a0f4054-8aa6-4d1a-a753-22a0572dc71c', '2019-04-18 22:15:33', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('218b4b0b-fe9b-49d1-87ac-af0d4a156215', '加菲猫', 'a00582d2-8938-42af-9110-35f7ad2eb59c', '2019-04-23 19:28:45', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('de7ebfa0-f911-4a2c-afdb-c73ac0f0a569', '加菲猫', 'a00582d2-8938-42af-9110-35f7ad2eb59c', '2019-04-23 19:32:37', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9a08cc60-c256-4f38-be44-8f9d48cebc9e', '加菲猫', 'a00582d2-8938-42af-9110-35f7ad2eb59c', '2019-04-23 19:32:37', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('c805ff93-edb0-46b7-9764-d9bd290df160', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-24 21:04:43', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9d65b41d-a4d9-46a8-bee0-29ea57a22308', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-24 21:04:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('7ff0dab1-a241-408c-a8d8-2bc177959258', '加菲猫', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', '2019-04-25 18:27:56', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('050f652b-c88a-41c5-b9b0-09c4810ebc7a', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 14:23:38', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('30023343-c808-4587-8b73-2117425ce794', '加菲猫', null, '2019-04-26 15:29:54', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('3449154e-8835-4417-b6b2-7203535ce5fb', '加菲猫', null, '2019-04-26 15:29:56', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('57cda88f-dcd5-48ed-a274-53fed240c7a2', '加菲猫', null, '2019-04-26 15:30:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('f9d5628c-2136-478f-9a12-64473ac081a4', '加菲猫', null, '2019-04-26 15:30:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('5d4b5bf1-b0dd-4363-9ec6-ddde67b46b42', '加菲猫', null, '2019-04-26 15:30:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('86c216d2-2ebb-4e5b-89c3-f8cfa221cb2d', '加菲猫', null, '2019-04-26 15:30:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('3c21656c-88ec-46f9-ae39-0138d5830a33', '加菲猫', null, '2019-04-26 15:33:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('bd87f0e2-0c7d-4dc4-9d0d-d20f4175d497', '加菲猫', null, '2019-04-26 15:33:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('aa18bc00-0d0b-4e3e-ac34-98fa39a5f375', '加菲猫', null, '2019-04-26 15:33:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('40523900-b51d-4c3a-9dbd-0c4f2c2fc015', '加菲猫', null, '2019-04-26 15:33:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('556c3b56-bac2-4b43-9de8-17565c1fbf8f', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:05:06', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('42d6fab9-ab95-4ec0-a0c6-cf3f67578b9e', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:05:24', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('a7753039-4693-49aa-a0f0-922bb61c85ec', '加菲猫', null, '2019-04-26 19:08:12', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('f7559ac2-f9a9-49e2-b320-af934c492d6b', '加菲猫', null, '2019-04-26 19:08:39', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_against_answer_article` VALUES ('d81f966f-9fc5-4513-b417-e83aa12e1d69', '加菲猫', null, '2019-04-26 19:08:40', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_against_answer_article` VALUES ('7f316971-8f67-476a-80a2-6cb4c334294b', '加菲猫', null, '2019-04-26 19:08:40', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_against_answer_article` VALUES ('0e2c8914-9215-4e9d-b349-9008c92ccd89', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:21:33', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('29b900f1-4cb6-47a5-816e-808ffb1494f0', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:09', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b57c1c96-fa1c-41af-9d55-8798a421e8de', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:10', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('d71d192c-4b02-49d3-b139-98f7cf63c20e', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:10', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b8399a02-8230-4b5f-9a33-42d3204fda23', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:10', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('26e5b678-19f3-4886-8039-22bad91fd9c7', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:34:10', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('680ce21a-a5df-417c-a121-0c438ee06adc', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:34:11', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f2097e71-5dc4-48fc-b2ef-5879579cc5b5', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:34:16', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f3e229ff-3d7b-485b-8188-2a32e7a806f0', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:40', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('6b4f5058-56a8-452d-ba7d-7d21489412cd', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:40', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('bd8124b2-d9a4-465b-ba59-113f303b93af', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:21:10', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('8be2f2c3-4b95-4fa4-99d5-800bb84d5536', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:40:54', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5f3bd493-8786-44a8-9011-5dbb71e6ed1a', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:08', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('a48df2e9-dd7a-4896-815c-4650e9440758', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:15', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('86ec9527-3ea0-4c31-a5b7-d5196c0b6e77', '加菲猫', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-03 17:41:18', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('4922f299-1fe6-4504-a51d-aa7921fb5e80', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:39', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b412f665-015e-418e-add7-d28fecb5b6c1', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 17:41:49', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0a02b420-ac6d-4308-beaa-45be5a58db74', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 17:46:41', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('fd80bfdf-bed4-47c7-9fe6-353470859726', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:07:21', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('d7bd8318-a2fa-4938-9e66-3a0e5716a69a', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:08:02', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('6f8ea8a0-d618-424a-a8cd-358f0f9ebd8c', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 18:08:25', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('a05cdd26-9fbc-4eb8-8a70-c3082d74fff7', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:09:00', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('46ca2ae2-6019-4daa-b9c0-97ae97499f49', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 18:15:13', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('28d1a7ce-db5a-46f5-94f4-1c1968b6eea5', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:20:22', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('a6f8910f-db04-4c07-8e30-d6d9eede27ef', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:21:45', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('179bde32-2198-43af-abbf-8b91bca2e270', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:23:21', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('4e9d357b-6e48-4d5a-bcb1-30b6dbb9b8d8', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:23:53', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('6dcdeceb-37ad-4065-9e12-8f85294ecf4a', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:27:32', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('2a63f9ad-62e0-44ea-b804-64ee7c688454', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:47:07', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('accb820a-df1e-450e-bc6d-0edae40121de', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:09:42', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('7fa2efca-51e3-4c4b-b099-483c4daa15f5', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:00', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('4e059f5b-1355-45b2-a5f4-72908525d7bf', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:04', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0967dfff-773d-44ff-9590-65a679e48f0e', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:17:50', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e1ec3191-ab52-45fd-a687-bc8abf2dadfd', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:18:39', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('a3bde416-e057-4fc2-a975-3d525e48e64b', '阿菲菲', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:19:03', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('56947a4e-8beb-4ccb-9487-6d8e3e56652e', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:12', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('abe19780-d5bf-4dc1-b249-f4b12f85732c', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('20cca6d9-b804-4ab6-8a6c-64c61745d144', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('e1c50b90-13eb-4449-babd-e94f4b46f161', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('94e4e262-efcf-40c3-b64e-e1ca6e4ec081', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('921460fa-7a53-4d21-815d-b70233ca9b66', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('1aa7b5f6-2a21-499f-bbc9-5a3308a0b912', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('0c7af9a0-dd12-4516-8771-1bd3e4410a91', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:44', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('d454c1c1-fc55-4297-a2b5-a5f0f50e1a81', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:07', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('2415d69e-1b6e-4da2-a98e-e6f8579bad29', '阿菲菲', 'f254fed0-7f9a-4f74-8c67-f49ea329531f', '2019-05-03 19:28:34', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b82fc7dc-b484-4d19-91f5-3255deba7431', '阿菲菲', '57a3f71b-a945-4ae4-89ff-655b3339981a', '2019-05-03 19:28:59', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('559699df-3d60-4d87-8b49-f4f3cfe2e176', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('9ad287e0-ff68-4376-b5da-93b8d0466925', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:28', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('ebfb5b1b-bea7-40f5-8cf7-81af62fb807b', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:41', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('a9fa1f8a-294a-468a-a57b-df64a17e12cb', '阿菲菲', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:12:34', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('15e02be2-95a0-4ea8-9ed1-155f77e81890', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:12:49', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('98510f49-1f8d-4424-8655-58ab3dd5dd81', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:16', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('8e446295-3f5e-439e-8943-ab285b67baf0', '阿菲菲', 'e1648ec0-5a2f-45cd-a9b4-653662488995', '2019-05-04 11:20:45', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('10680883-4b51-4c5d-9850-62d8733442d9', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:21', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f3f31355-a0cc-443a-96a7-8bcd8bcb4c40', '阿菲菲', '380045ae-5f9f-4009-b818-daedf5adc931', '2019-05-04 11:33:36', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('5cb4de6e-a00d-4508-804d-2da4e3bcd695', '阿菲菲', null, '2019-05-04 11:42:45', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('f03602a4-c995-425a-921c-48997f3c038a', '阿菲菲', null, '2019-05-04 11:42:46', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('21e9b4ff-aa14-491c-bf9b-f4725f40d11d', '阿菲菲', null, '2019-05-04 11:42:46', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('f5b6f55b-b909-4c3b-9080-e1e4a58402d1', '阿菲菲', null, '2019-05-04 11:42:47', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('df1d3a2e-c2a6-4381-85b3-ab05907f8c85', '阿菲菲', null, '2019-05-04 11:42:47', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('ddbc3d3a-83bf-4d99-8b9a-d1d4510a36b1', '阿菲菲', null, '2019-05-04 11:42:47', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('c39f4da4-d415-432e-a585-84784ae3eeed', '阿菲菲', null, '2019-05-04 11:45:29', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('eaa8345d-b886-4cf6-82c4-b649201655f7', '阿菲菲', null, '2019-05-04 11:45:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('4e7b6b16-5a2b-4608-bf80-814a6045c3be', '阿菲菲', null, '2019-05-04 11:45:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('1757a9b3-b429-4c4c-b2e4-8cb37790e6c4', '阿菲菲', null, '2019-05-04 11:45:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('9f0d9138-7cf4-4c1a-b138-32c90a2d70ed', '阿菲菲', null, '2019-05-04 11:45:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('681f4df8-caa9-496d-9835-2f02c296a3c4', '阿菲菲', null, '2019-05-04 11:45:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('53209804-d8e4-4070-abf8-4477726cb514', '阿菲菲', null, '2019-05-04 11:45:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('114804f4-1017-4d08-95dc-e89025e94b1b', '阿菲菲', null, '2019-05-04 11:45:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('02aee4e5-4fdd-40fb-889b-bd23aa94ef1a', '阿菲菲', null, '2019-05-04 11:45:38', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('79e88e07-10c2-4951-9072-60efddbf1cc1', '阿菲菲', null, '2019-05-04 11:48:30', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('ff071a3d-a3d9-4c20-a810-49b28ade537e', '阿菲菲', null, '2019-05-04 11:50:01', '加菲猫', '1', '28d7d198-f6bc-40f4-937a-bc3bde235280');
INSERT INTO `record_user_against_answer_article` VALUES ('36822f3b-2d53-4440-b5e7-506bb4c393fd', '阿菲菲', null, '2019-05-04 11:50:07', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_against_answer_article` VALUES ('7ff33b6d-8b8c-4d90-a7c9-a13191630187', '阿菲菲', null, '2019-05-04 11:50:09', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('939b9cfe-5c2e-4461-bafe-7b09dc247087', '阿菲菲', null, '2019-05-04 11:50:10', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('7db40d0f-a82a-46e9-8c57-faff3aa772d9', '阿菲菲', null, '2019-05-04 11:50:11', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('906ba6d0-938c-4532-9e27-1ff960f2a950', '阿菲菲', null, '2019-05-04 11:50:11', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('bd3f9450-8649-4e80-aebf-f009a87ade2b', '阿菲菲', null, '2019-05-04 11:50:11', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('28c00f2d-a4c5-44be-820c-75fec045138a', '阿菲菲', null, '2019-05-04 11:50:11', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('cd93f896-05c4-4eb3-b1c2-8de607d6dc0c', '阿菲菲', null, '2019-05-04 11:50:19', '加菲猫', '1', '459af1f1-a907-4800-8d62-3a5824d9f913');
INSERT INTO `record_user_against_answer_article` VALUES ('707bd9ba-f0ba-4c18-9c76-f8ed91b54667', '阿菲菲', null, '2019-05-04 11:50:22', '加菲猫', '1', 'a97ee283-c951-44b2-bdd0-c5b022c8baea');
INSERT INTO `record_user_against_answer_article` VALUES ('4c293cd7-c8e7-472a-b734-a88778ca3269', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:39:59', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('b4c12709-f65f-482f-9082-6d4f8d89d965', '加菲猫', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:47:17', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('4cff0626-6fbe-4e6b-ba63-3eddf6343e75', '加菲猫', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:47:22', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('f6b93104-d096-4abd-a09d-ed58c22bb9ff', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:48:56', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('766fe8b0-e8e6-4c82-85f4-564feb59969e', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:49:22', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('bfa0730c-b06c-4655-853c-d1e2396bdc1d', '阿菲菲', null, '2019-05-04 14:57:15', '加菲猫', '1', '1b085133-b37e-44f6-8dda-52bf5205dc77');
INSERT INTO `record_user_against_answer_article` VALUES ('0c566c10-685e-4e75-97b2-9233666242ef', '阿菲菲', null, '2019-05-04 15:32:28', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('ba9abcd0-9b04-484a-86df-9b2dc49aec1e', '阿菲菲', null, '2019-05-04 15:32:31', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('db3152fd-e498-4d39-86ab-6561839df496', '阿菲菲', null, '2019-05-04 15:32:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('1051d9af-69c9-4efd-9b1d-8df169df94cd', '阿菲菲', null, '2019-05-04 15:32:43', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('6ca576fe-52e4-4d7d-981b-0b3a5b68913d', '阿菲菲', null, '2019-05-04 15:33:17', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('a3d7487b-6da7-40a8-9a24-006ad04134f6', '阿菲菲', null, '2019-05-04 15:33:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('22ec3e7d-07e5-4892-ae54-f0c4ca84c6a8', '阿菲菲', null, '2019-05-04 15:33:26', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('9477bf9e-4587-4eb5-9e45-6a1d53798b45', '阿菲菲', null, '2019-05-04 15:33:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('34b55794-2528-4678-82ba-5b4daa540173', '阿菲菲', null, '2019-05-04 15:33:34', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('0224f43b-a98e-42a1-a1ba-f88ef20979d0', '阿菲菲', null, '2019-05-04 15:33:34', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('8b6ede65-8f2b-49c0-b489-80b6892342b4', '阿菲菲', null, '2019-05-04 15:33:34', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('03e2829e-97cd-42fc-b96c-6d83809fa148', '阿菲菲', null, '2019-05-04 15:33:34', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('a6b2ba2b-18cb-4b9e-8b19-8b94c079ae79', '阿菲菲', null, '2019-05-04 15:34:00', '加菲猫', '1', 'c5db833c-5f27-44a5-a7cd-0307e9dd3050');
INSERT INTO `record_user_against_answer_article` VALUES ('2c0dc2f6-901e-4974-9c9b-7f8c1f83e48a', '阿菲菲', null, '2019-05-04 15:35:26', '加菲猫', '1', '38ebb34b-71d1-492a-a786-f407fc8b1388');
INSERT INTO `record_user_against_answer_article` VALUES ('973846f9-ef6a-4099-be6b-d334a1a2bbc2', '阿菲菲', null, '2019-05-04 16:02:50', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('34e88dd2-fda4-4b2c-8b46-7239305f847b', '阿菲菲', null, '2019-05-04 16:02:52', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('6724cafe-af5c-431a-a451-5e60d1fee709', '阿菲菲', null, '2019-05-04 16:02:56', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('4ae8d1b1-1453-4328-be31-d16b0cfb7500', '阿菲菲', null, '2019-05-04 16:02:57', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('3b9b6fd5-576a-4224-a3a1-55b433b85bc1', '阿菲菲', null, '2019-05-04 16:02:59', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_against_answer_article` VALUES ('743f0124-1542-4983-84df-82c7d6a05f5e', '阿菲菲', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-05 12:29:08', '加菲猫', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('39b17b3b-9512-4a46-9a04-87aa8bd1448a', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', '2019-05-05 19:19:30', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('409fff8c-f7bd-47f1-8e5a-b58686b3cac8', '阿菲菲', null, '2019-05-07 09:40:28', '加菲猫', '1', '4669bc01-e935-4e69-a4e8-e202b7e4ff4e');
INSERT INTO `record_user_against_answer_article` VALUES ('b3b99d96-e76c-4afe-982b-83e702d94c3f', '阿菲菲', null, '2019-05-07 13:16:17', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('d0357850-0251-4146-9af9-0bd8927a599e', '阿菲菲', null, '2019-05-07 13:16:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('f15aa816-a341-42f3-b66f-c7ce8e485e9c', '阿菲菲', null, '2019-05-07 13:16:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('78c805b7-8370-4810-969a-522c67a7b462', '阿菲菲', null, '2019-05-07 13:16:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('c89d668e-a941-4b45-b532-a40261c164b7', '阿菲菲', null, '2019-05-07 13:16:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('f1a87633-c264-4fb1-9d70-1cd132be5816', '阿菲菲', null, '2019-05-07 13:16:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('148731d1-7a94-4c3d-a9b8-81feb5e5602c', '阿菲菲', null, '2019-05-07 13:16:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('8e387854-eaf0-42bd-80e2-86b409b2cb9a', '阿菲菲', null, '2019-05-07 13:16:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('55cdb600-0a98-4c71-a13d-1fb9cf0b8c40', '阿菲菲', null, '2019-05-07 13:16:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('3b3711e3-a98c-4203-b40d-3eaf8183d409', '阿菲菲', null, '2019-05-07 13:16:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('e389adce-d2b3-4e3f-a9b3-d02f03927dcb', '阿菲菲', null, '2019-05-07 13:16:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('eb454998-5f9c-452f-997d-aff631d4f8f0', '阿菲菲', null, '2019-05-07 13:16:23', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('0b5f0d9c-dbc6-4efb-bcb9-a783380e97ab', '阿菲菲', null, '2019-05-07 13:16:23', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('98e13ed2-39c0-49e2-9456-02a15e868c87', '阿菲菲', null, '2019-05-07 13:16:23', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('9b6189e8-29dd-47fe-96f2-5d38e283c593', '阿菲菲', null, '2019-05-07 13:16:23', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('7b27a066-87df-47dc-a3af-3cf13256c5e7', '阿菲菲', null, '2019-05-07 13:16:23', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('00b98153-0ccc-42f8-abba-bd693a1b24df', '阿菲菲', null, '2019-05-07 13:16:23', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('0c8798a5-ed73-47fb-83be-224b6c18a839', '阿菲菲', null, '2019-05-07 13:16:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('8f3aa64b-a17c-4727-969b-476817d1aaff', '阿菲菲', null, '2019-05-07 13:16:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('77fe28de-e202-494f-868f-820e9b2ce41a', '阿菲菲', null, '2019-05-07 13:16:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('eef22d06-57b0-4216-860a-f72def828a0a', '阿菲菲', null, '2019-05-07 13:16:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('5f8ab887-7226-4077-8b9d-4216c9a98386', '阿菲菲', null, '2019-05-07 13:16:26', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('d13c9d12-7f14-4ed0-9b50-e1768d972ece', '阿菲菲', null, '2019-05-07 13:16:26', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('98aa9c6e-efbd-46f7-b977-1ac0abcd058d', '阿菲菲', null, '2019-05-07 13:16:26', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('d77c1930-fc87-4afc-a6e7-b6cc7a052d81', '阿菲菲', null, '2019-05-07 13:16:26', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('77cd6cdb-1bf1-4e41-af42-f96fa6cecaad', '阿菲菲', null, '2019-05-07 13:16:27', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('e1aa1d8b-e850-465d-8f36-5f7e830b6e93', '阿菲菲', null, '2019-05-07 13:16:27', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('3312c0b4-2d54-4207-b06a-4466601b86fa', '阿菲菲', null, '2019-05-07 13:16:27', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('37c7547c-3874-446a-918e-973f57aa2f9d', '阿菲菲', null, '2019-05-07 13:16:27', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('dd5a55d3-ac0d-4278-a90c-d114cc31887e', '阿菲菲', null, '2019-05-07 13:16:27', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('384fde56-cbae-4b16-b38a-546ca6825f14', '阿菲菲', null, '2019-05-07 13:16:28', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('6e36b070-2dfb-4c9d-8457-25db6e066499', '阿菲菲', null, '2019-05-07 13:16:28', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('77669980-af22-4594-9f07-51300ce0381b', '阿菲菲', null, '2019-05-07 13:16:40', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('c24c3283-cf5a-4df6-ab72-aab1f110d6d5', '阿菲菲', null, '2019-05-07 13:16:41', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('6a645418-9efc-4049-9ec2-ea7bc1177452', '阿菲菲', null, '2019-05-07 13:16:41', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('03bd1339-060b-4e97-a9b4-5400d1e6aa41', '阿菲菲', null, '2019-05-07 13:16:41', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('915eb4d3-5577-4fe2-b285-9b5bbc2f95f9', '阿菲菲', null, '2019-05-07 13:16:42', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('8a26849f-6211-49dd-88d5-2f73a300d953', '阿菲菲', null, '2019-05-07 13:16:43', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('6a85d018-15ee-4855-8c68-7304fc675a3a', '阿菲菲', null, '2019-05-07 13:16:44', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('dee098b6-14fe-4390-86a5-35e4e5065b9d', '阿菲菲', null, '2019-05-07 13:16:44', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('1a1b0d53-caea-4f5d-9045-48b25e0a97bd', '阿菲菲', null, '2019-05-07 13:16:44', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('42ce91f9-67fe-4dfc-99c9-53675b2e9014', '阿菲菲', null, '2019-05-07 13:16:47', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('1faadb3a-1128-4eac-8ba4-307afcdaf2b7', '阿菲菲', null, '2019-05-07 13:16:47', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('5d2a4418-fba3-4a41-9ad0-e4e4d7aa826d', '阿菲菲', null, '2019-05-07 13:16:47', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('b5a839f3-4cf1-4167-a036-2bb49d56675d', '阿菲菲', null, '2019-05-07 13:16:48', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('e4525462-89dc-4bcf-aa20-bddd5f63815f', '阿菲菲', null, '2019-05-07 13:16:48', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('3d6edd47-715a-4846-ba59-e448f968213e', '阿菲菲', null, '2019-05-07 13:16:48', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('c534a9b5-59aa-4a1c-8412-cf41730fd53a', '阿菲菲', null, '2019-05-07 13:17:00', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('09dc5c70-a924-4898-a663-8b19d8a72edb', '阿菲菲', null, '2019-05-07 13:17:00', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('8708e76a-447f-48e2-bff9-7205b74500d2', '阿菲菲', null, '2019-05-07 13:17:00', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('f06ae900-aa98-415a-b8b6-b60e3b65f02d', '阿菲菲', null, '2019-05-07 13:17:01', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('3075c499-9f60-4c47-ae19-a0dc3afea159', '阿菲菲', null, '2019-05-07 13:17:01', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('d8e988d5-aae0-4085-b7ff-54451f33c53d', '阿菲菲', null, '2019-05-07 13:17:01', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_against_answer_article` VALUES ('7b00f13d-68b3-4244-af18-d9bb49219031', '阿菲菲', null, '2019-05-07 13:17:25', '阿菲菲', '1', 'bd359937-76a2-4685-a12b-291dbd0525f2');
INSERT INTO `record_user_against_answer_article` VALUES ('223f6ebd-595c-40aa-9471-a66122345cb3', '加菲猫', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', '2019-05-07 13:47:36', '阿菲菲', '0', null);
INSERT INTO `record_user_against_answer_article` VALUES ('7cf78734-ba59-4324-9adc-6ca781669300', '阿菲菲', null, '2019-05-07 15:02:58', '加菲猫', '1', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8');

-- ----------------------------
-- Table structure for record_user_agree_answer_article
-- ----------------------------
DROP TABLE IF EXISTS `record_user_agree_answer_article`;
CREATE TABLE `record_user_agree_answer_article` (
  `rowguid` varchar(255) NOT NULL,
  `agree_user` varchar(255) DEFAULT NULL,
  `answerid` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `to_user` varchar(255) DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `articleid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of record_user_agree_answer_article
-- ----------------------------
INSERT INTO `record_user_agree_answer_article` VALUES ('7f6139b1-ac31-4a98-a522-84d5886aa265', '加菲猫123', null, '2019-04-26 14:58:15', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_agree_answer_article` VALUES ('a2856aec-1b8a-4dd9-b2ce-982a38f0a5de', '加菲猫', null, '2019-04-26 14:58:16', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_agree_answer_article` VALUES ('c1cde5fb-e0ed-4a98-888c-ac1559c628b3', '加菲猫', null, '2019-04-26 14:58:16', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_agree_answer_article` VALUES ('71caa621-f737-4315-b9bf-dbb211179545', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d9b51207-02d1-4122-b088-9070ee703e40', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('faefa0f2-8fcd-4bf9-880e-daba3e90030e', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b4e047fa-9fba-4c23-81e6-0b8db5a0892d', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('45685643-e3c1-429a-8202-7579527c7e7f', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 15:37:40', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('354a5ed5-8239-4154-83fb-12acf9bb4171', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:37:25', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5e455077-7a17-41f5-8a97-69c07bb8da03', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:37:25', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8126c6bc-28f1-4a1c-9366-9cab91c37db5', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:37:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f26cb9b6-fc77-423e-aeb0-7eaed1336ef3', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:38:30', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b1d3ca13-5d9b-4d9e-af32-fe073d6bea6d', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:38:30', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('54ff9c9f-9207-4ebd-b8f8-9fe770547d52', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:39:08', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('92e291e3-4e67-4b35-8380-5603e2058092', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:39:10', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9ab60392-39dc-43bf-aa76-4105340b2282', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 18:39:14', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c9c56a4b-2d36-4008-977d-1c9161b0f641', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:05:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('df1a0245-9882-4931-836f-8d493c82dbf3', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:05:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('47c9d85f-7f2a-4230-b230-aba356386d4d', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:06:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6cf9c2ce-7292-4aae-aa23-158d67a8629e', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('830c6590-0998-43c5-a8aa-eba1c25c3756', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6efe49b2-41cf-4b04-8572-48f561bde411', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('390b09a5-979d-4a9c-ab57-0ef75f20fd20', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6509de08-0584-4f90-a159-6a766723458e', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('51d98209-da5f-488d-a056-72d3ebe5f93a', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('cc78f1d2-d699-4f1e-a66d-daf7b49bca1b', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-26 19:07:12', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('dc45fe5e-1fae-42cf-bdeb-cfaa104b0169', '加菲猫', null, '2019-04-26 19:08:12', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_agree_answer_article` VALUES ('a202cfb4-b492-46c8-900e-d56fa3d2511c', '加菲猫', null, '2019-04-26 19:08:39', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_agree_answer_article` VALUES ('675ed9af-3cd3-42e4-9058-921e2a09650b', '加菲猫', null, '2019-04-26 19:08:40', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_agree_answer_article` VALUES ('4c600d54-c402-4e7a-95b0-f45109590708', '加菲猫', null, '2019-04-26 19:08:40', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_agree_answer_article` VALUES ('928186f2-2a3b-47a9-9dd0-681fb7352c38', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:14', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('72cdedf1-bbaa-4ade-87d7-7fa59d7406b2', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-26 19:22:14', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b6436f47-ab3c-4812-b04b-a7c0986d6440', '加菲猫', null, '2019-04-27 14:24:23', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_agree_answer_article` VALUES ('702557db-5526-4d20-bb49-0c38ac690444', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 14:39:53', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bee359ce-f537-4b25-a7d4-42f571ed77b1', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 14:42:46', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d65a233c-96bf-4a99-ab06-7effb6f4abd3', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-27 14:44:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3595f30d-a66f-4766-87d6-20f702cebde6', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 14:45:29', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4c52a568-63a2-49db-a7be-d7baf60bc276', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-27 19:36:51', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7336dfe5-d60d-4d7f-8c02-3b16d8ce2045', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('dfa2099f-8736-4664-aa56-2162f3db7f80', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3cebf6f4-921b-4c48-ae91-88f62d4092dc', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1c802683-7ab9-4a6c-bcb2-99489fafa7cb', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('080f5e46-87d2-40d7-9fe0-69da81227c8a', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0508ded4-a63c-4f59-8bd8-785f603c9f0c', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('737cb962-f9ad-4fee-b0ed-3a6ccb5892c7', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('78f79ec6-a79a-48fc-8258-49ff1e10f09c', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6a434d51-451e-4ff1-86eb-fbc48d26dd1f', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8c7716eb-9b60-446a-979a-93cb06d1bc5c', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2b5463cf-b5ae-4020-8caa-1bc6d9368cc0', '加菲猫', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-04-29 09:18:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0abd3ccd-d3c3-4cb3-b42e-ecc184c314b1', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c9c39c21-2643-4368-874b-654e43bbd1d5', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('39df78dd-6e28-45e6-a470-7764e73d1db2', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7c23f822-b979-4f19-9da8-eb3a74986a6a', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:47', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8e68fc7d-c2ca-4f61-8412-9980f84dcea6', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f585841b-24b1-4985-872d-42367d6a7de0', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7a2c09d3-f5d8-4421-9804-a97228d5aa37', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9d726b79-94d7-4e83-bc0c-8ece494e9038', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('19e49435-4710-442e-a6d2-dba0f9e43be7', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:48', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6a8c3f26-3403-4403-ac63-3f588843e9a1', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f1802c7d-f292-4ceb-831d-86f9695c00f2', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c728a2d3-7f14-4ecc-9f0d-aac3847a35b9', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2c96b144-a21e-4851-9421-9bb4d5137974', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ba37a5b7-f22d-4081-b773-fee498f4c347', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('58b576d2-c57e-4937-b015-499a70736e0e', '加菲猫', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-04-29 09:26:49', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('df64543a-d635-4bcb-b2fe-173ffa33c626', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:33:33', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ee34f467-c50a-4bd9-9fae-9f72da62c7af', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:33:34', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f1aa6d8d-ffd0-4e4a-a607-6eb59853894b', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:33:34', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fbd8a865-8b85-454b-b40f-7253d4574baa', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:53:57', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('07aa8780-a06c-4848-9387-93644bbba0ff', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:00', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6a895597-87f0-47a3-9a33-e51feb5bb76d', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5ab94609-8adc-4548-b55b-dfd89f8ee968', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6a2cd2aa-2620-42da-adff-7a4f2513f8df', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('49a6f7bc-adb1-4912-8e5a-49ecdefd8246', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('48515ee8-4eb4-42bd-946e-4b09adfd2f36', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1143569b-f0b6-4a7f-af44-bcc26043050c', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e6a1d2f9-4483-4f29-823c-5ee48d18ef3a', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bb197b1d-8b8e-4b10-ab83-6bbbec3efd21', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5c992856-4e0d-4d4b-a88e-696028b8f3dc', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d6556184-d01b-461c-8b1b-3c3617754b3b', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e153f0e7-e79a-422a-852b-862ee62cf0fb', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('67627906-c2e4-4c34-95eb-4e48971c168d', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('03226f38-80ea-420b-af4d-1994522d2417', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('14f84eae-f747-4922-ad0c-8f4f81e5d849', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d25884d5-4985-4a61-9860-66609507a52c', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('61781473-9359-4589-9fbd-fb0ff7969be2', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fe429db7-8911-4ad1-bf9c-95677c9c612c', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('babf3f94-9ecc-40b8-abd9-033c12e7d5b2', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b687302b-7609-4619-b4e4-9ed53f423fb1', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1bf8be11-9567-41a5-98bd-ae1206b7f09f', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f122a515-7289-4ce4-b27e-d7438d32b54b', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b55c2221-bcbc-4c50-be63-b9f73687dbee', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4d1b4aea-8cfb-477c-8f24-47d5a9f57aed', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8bd3c954-0a52-4554-b071-74d23cb24ff4', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 09:54:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9182b4e9-1a4f-4438-b0ef-0f8b7d12dbb6', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:57:57', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5cc21337-2c45-4fbf-a11c-5155ce7901f8', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 09:57:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('51bd62fb-8469-4145-a22d-32a0a2ebe510', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:46:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ccb99758-9402-4616-88b8-0c8a69b65a6b', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:51', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('19c67a04-6252-4d8a-89ff-ad852e14cb61', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:53', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9a7457e4-29c6-4d72-9794-082606209bac', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:54', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8516b04f-e7eb-4143-907f-6c3906d3432b', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('dcb81b66-56dd-4b05-b410-24c40203c018', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 10:59:59', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('62083db8-f436-4201-afba-247fb3bf3f42', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 11:00:34', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('20c16db9-b55f-435f-86a4-7510b07acf84', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 12:19:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f27adcf0-8239-4778-a1f5-fd7ded39c34f', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:19:36', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('075fedf5-e8cd-4a8f-90ef-186b3c0405c1', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-04-29 12:20:06', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('83b69654-e742-4b1c-a50c-1baa876c3615', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:20:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('96a95a89-4306-4774-af04-cdf9efd90f97', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:21:12', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('80541def-0c78-4c2e-8458-7caf330e474b', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-04-29 12:21:16', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('802e2790-6450-4d74-83c7-28a5322857e0', '天天敲', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:05', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('17b0c2cc-cafc-48f1-b196-847d42b30c39', '天天敲', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b89af28b-5aec-4ce7-a016-60eb4755669f', '天天敲', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('906d5187-a3d9-4ced-b580-000951668822', '天天敲', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e229fa0d-a190-4942-a96b-5bd9c876d60c', '天天敲', '5d56aa61-6cd1-4c71-a46f-b8cd362c508e', '2019-04-29 22:36:06', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c50e609a-58ce-48eb-a110-c12ecece05be', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-02 10:21:35', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0351ded0-eec4-4944-a89b-4518ce5b32ad', '加菲猫1', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 17:41:17', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('36491409-07fc-4248-980a-cfa3e5b674d4', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 18:27:44', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('78877913-cc29-4fa5-8464-d64c59e7e287', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:15:56', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f74ec5ce-7f43-43db-9dd4-bac987c2d720', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('82ea1771-a2a0-4490-8f08-d1e055adb73f', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:08', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4fde713f-b9d4-4973-881d-79d57c95e7e9', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:16:16', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a70f3f7b-2eaa-453b-ad9e-be82afca7a13', '加菲猫', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:16:45', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5924cf0e-97b8-4dd0-9a6a-bc6b5c39d63d', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:18:27', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('eb2fe336-ae9a-41ea-ae82-a0f672b7e647', '加菲猫', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:18:36', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2d1c6d38-70af-429c-a486-f73aff3e44ed', '阿菲菲', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '2019-05-03 19:19:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2aaa38a3-dbe7-4bd2-9f26-976c38ebcd4c', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:06', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6ffb0ed1-7d22-4ed1-b05c-e9c91a18d931', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:07', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('055cafae-d5c1-45a3-8cbe-6c7d056a375b', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:09', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('48c00224-84a4-4561-8a85-eab054ec7266', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:09', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b989ba9b-e717-44da-987e-2b508c50f5b7', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:09', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('621df398-235a-4e3c-80b3-d9038d5cb3fb', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8ea4827b-f23b-4cda-97e4-5ea4d91bb1b7', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2144af5f-eb85-4aac-aa01-46b576bd2bca', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9280f3d4-97ce-44ff-bc5c-205beea3de98', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('22fef116-5791-4762-b612-fb11f2fe342d', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6f2e615b-e2d7-480a-af68-f5201919e941', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:10', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('885fbab2-236e-4685-b13f-4cf5b3e41450', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c156a154-2321-429c-86d2-4736895cd97c', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('13a615da-b0d2-41d0-993b-503240669647', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-03 19:19:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a91c4ad2-3b4b-40dd-8fdf-0ef944e81c96', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:35', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7c34c8de-b745-435a-b151-92227c494b40', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:37', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fae58194-e257-4e30-9844-398593c7feff', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4dca284b-0e4d-4742-8536-dd6e316422b8', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6a8b446e-c8e8-4ebe-993c-28679ba275c9', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2be7a13d-8d5a-4ddd-b952-ea28aaf20e18', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ec0cec6e-6810-4f6b-8afd-279f99ad5ba6', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:38', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('db1036ff-ada5-471d-9122-b668cd6ee8df', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ecccff61-b2f4-4edb-8724-32543f9425a1', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('20acdfff-16d3-41f7-b281-cfeafcf3265a', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e9bb6d02-3c3c-4dad-b6fb-ff75ececb5cf', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a92f2e3b-bbca-482d-a038-f09214a701be', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ac1edff0-d388-4e84-92f3-1ad4455904b1', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:39', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('201044de-e4ba-43c6-a15b-47dc862a4160', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b5691310-b66c-43db-bda3-8245a2cb7d01', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b1d9c269-93f4-48c1-a93e-90e80eab0f27', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('558bc107-975e-4deb-a80a-9ed0e2ee729e', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('884d8fd4-b0f6-4dea-948c-7b424525eef1', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3f589863-8128-4a64-8082-5dd2fc3dfe36', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:40', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0a7e0e5b-f276-4a28-bade-a01205e45c17', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('353a2a4f-7198-4a9a-9915-66b85deecf07', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('831874ea-178d-4ac9-ab35-f1587ca50028', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d40410ac-25b6-40c8-8c18-b08b3c9cbc7e', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f7a55d21-83f7-4a68-8557-b5277754cfba', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7e92af31-7da6-44ec-a502-7dd8ce389750', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('53e0399e-c359-428f-ad83-12af00bdb326', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6c287a00-f0fd-4b51-96d8-00388596b564', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ec3f92eb-ed9f-479e-8362-2702252486f6', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('86f00013-cf45-42c5-a554-52682d211069', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('64d38c29-966a-4afd-8161-3f846d022257', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:42', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e543c062-8a7e-4b37-beb7-1a6a0e3b4de9', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7e8a69a5-8bee-48fd-96cb-2ae4f5e26fc8', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d15c780f-1574-421e-a0ff-fb7b4b128ac7', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-03 19:19:43', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('85c0800a-3ad4-4d25-ba4d-a7bba4e8c09f', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:19:58', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('278db147-cd2d-42f7-9543-10cfc3326311', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:01', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c2260a86-fc6b-40ae-9a01-9d29c766f954', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:03', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f367b26b-b1f7-42a6-9897-9fd790e2a491', '阿菲菲', '6a33608e-1e74-443e-87b5-4a31234e742c', '2019-05-03 19:20:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8987aa9d-105d-4052-8d9c-1292a7dc9ef9', '阿菲菲', 'f254fed0-7f9a-4f74-8c67-f49ea329531f', '2019-05-03 19:28:31', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('951750fd-79f5-4ed8-b21a-bba4dea39a0d', '阿菲菲', '57a3f71b-a945-4ae4-89ff-655b3339981a', '2019-05-03 19:28:51', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('488cd1ee-3384-4f3a-9b24-aa5d5ca61495', '阿菲菲', '57a3f71b-a945-4ae4-89ff-655b3339981a', '2019-05-03 19:28:54', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e6be8137-addc-4292-aceb-e62254852b75', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:39', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3ca4fee3-e490-472f-a6c3-70bbc4e14cf0', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:42', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('17d03cf6-a518-4fbd-b21a-6577161a4bed', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:43', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('663b791b-4124-461c-9c10-3d0ce7d5c5b7', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4f3d9c33-5f8b-403a-a4fc-f64ccb7e309e', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4a28110e-043a-418f-91e4-33fbd444a0b6', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('730fec5a-0134-48d6-8400-c791bc80c136', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:44', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d17c3783-95a0-4a0f-80f5-623d2b12108d', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2360147f-3a08-4e7f-8e13-03147c2501b9', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7129c2b3-8012-4976-add5-4431467505b8', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('24f3bce5-e6d2-4224-b2f9-1650b9c687ac', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9c548bd0-cf0d-4a6a-b8cf-8ac10a415832', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('707f283a-f65e-48a6-af36-34a33ae9cb0d', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c78c3d03-c18b-4aa7-8789-1fc8861f339b', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('cbc75b24-bbf8-4636-b357-267cee33d8cb', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('92312dd6-78b7-4957-9248-b288aa9a6e96', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('10a2a3cc-a120-4660-ba2c-3860fcb82840', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8c37d65f-259b-405e-a28d-f15eae699091', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:46', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('79a86e7c-5db5-4664-806f-0d271b1ecee6', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e67059b1-4629-4418-a588-677d0376d263', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('35ac47ed-3cee-4760-8707-0b5c5105f848', '加菲猫', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-03 19:29:47', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6760648b-8080-4c0b-8628-f87b0306f5d7', '加菲猫', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:13', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('be643b86-fdc1-4974-92d1-48654e5c659d', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:19', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('92a048f2-d9c0-41c6-a4ab-ff5527dccfbd', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:20', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('68f0ef56-1177-4f60-9652-58e9d0bec8ab', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:21', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bff38797-86ab-426c-8119-cd22e207d39a', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:21', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c9410bae-e305-420e-b39e-0f5b7a5ce029', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:21', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('165b9cff-6449-4c89-aeba-b013b4a6f656', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d74f862a-c28c-481f-a5a3-ea8dae57ce45', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('33398000-aec4-4fa2-8ca9-fc6ee3d38fde', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('142deb13-3bbf-426a-9a6a-e72e4ddf4721', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('92625dc3-4f63-4fb8-94a5-991f4ebdd692', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7d852e3e-2c56-4e0a-b6ab-9115f55b76f6', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e37927ff-cb8f-480b-8317-60cf108d1338', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6bb7ece0-9d4c-4ab7-8973-022b21369b05', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f6215381-13fc-40a2-a02c-d8be77045906', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c736da88-8be8-4659-95f0-8e93396138b3', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1868426e-fcc5-4ec0-afac-339714456736', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0e3b7139-8221-497a-9611-81b1e2747442', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('144c21db-169d-4051-87f5-6650254d4e68', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f1a0f355-d5bc-4b28-a60e-be12f1ddf82e', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('af299aef-0da1-48ef-9d0b-4367c6e5023d', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-03 19:31:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d3d4b791-3a28-4266-b36f-3ea553042a4c', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:38', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('88aa88ea-134b-45b8-aa59-0d5eaa739be1', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:43', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('946264f8-2452-4bea-9e95-063bdcb3542c', '加菲猫', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-03 19:51:45', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d905d9b4-de90-4087-8314-c44072583107', '阿菲菲', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '2019-05-04 11:12:33', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('40a85c1a-4998-4d28-b7d5-d7e030e5ebff', '阿菲菲', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '2019-05-04 11:12:48', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1774e94c-90ab-4a06-bbec-27b2b650ea02', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('52334419-c879-49c7-a71c-d38b12f911ef', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ae6d49c5-8f60-453f-bdc2-862f8e34075b', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ac136eed-f0ea-4e74-8a1c-a6d050c68b63', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9bb19e1e-5db4-49bc-97a7-7c073ee8ca6f', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('205406a1-246d-46a3-9660-d9454823c972', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ab23c4a7-9bda-48e5-bc51-810ab943797f', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('85a9e817-eb28-4b60-8d0f-bbbc7fb7742d', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('725b0b24-01d5-4047-bd67-4a62ba2afd56', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d3e926ea-20e9-49c4-a75e-2af967b1be80', '阿菲菲', 'e4e12881-eafd-45ce-b2ba-b0c42b1039b3', '2019-05-04 11:20:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8a9415af-876a-4fba-9145-d6b66f057453', '阿菲菲', 'e1648ec0-5a2f-45cd-a9b4-653662488995', '2019-05-04 11:20:38', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('82bb7d10-85c3-486c-adfc-f7725e772aaa', '阿菲菲', 'e1648ec0-5a2f-45cd-a9b4-653662488995', '2019-05-04 11:20:42', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('00a0453c-4ce6-4a33-b111-b4eca412edc3', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:58', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('85a9a71b-fa9f-430a-b7cf-99dcc9d74a74', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:58', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bdff4ada-29a9-4c61-b36d-7f2481035c63', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('260ee670-c660-48e3-a882-84c42f325a29', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a647f406-dc16-485e-886c-acf840176be4', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6424fd1f-a4e2-403c-9ef0-223931eec7fc', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a81bb4a2-6e3c-474a-abec-9088f25e5c8b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:20:59', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bc6d880c-82c1-41e5-9e4f-94084798b71a', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1d72fac2-d56f-4509-8229-9e7f941de0d6', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ae8cb534-9b0b-4412-b340-31b7f31b27b0', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3f5f68c1-4d91-4233-97ee-d59325ab61c7', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c0ffceca-8887-46e0-9856-b786eece1dea', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b36ea746-6c2a-4769-9233-bbf474cb6b25', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:00', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c0930fab-2130-4612-88ab-c5626d42f771', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:02', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b7ce83b8-928d-498b-9502-52105292ba19', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:03', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('041701db-163f-44a0-ba5e-add80894ac9f', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:03', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2b5d5652-c85b-4e76-8c5f-426809bed04b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6df5f3b2-854b-4256-b9ce-9394747ef9b7', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4fd84e4b-d9ba-405c-b378-675195f05139', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4266c53f-6967-4254-9509-199fcf8a70f2', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b96b5db1-7e06-4e48-a6ef-f0296a432bf1', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:04', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d1ea9b1a-ee96-4826-a32d-45ef06b73922', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('325da55b-43a2-431f-83e9-00b18290ce00', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e80c19eb-65aa-454e-b47c-d09168557828', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('dcf93bf1-d6a8-4c9f-8065-3c4d8ef416af', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('301db0c0-07ad-4937-b0ff-1566ec212715', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fec8a4a3-347a-44aa-8bf3-aad4a126c6bf', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f91cff99-e11e-4895-a2ce-f767bd082285', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('34692de7-06ac-4d12-b4b3-a9da060048a7', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5f194b4a-78b2-4f79-a807-9ff3f7e815b6', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0b625f26-d55c-498e-b40e-136547daea1e', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('cddfaaae-48a8-43e2-83b3-444d41a70075', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('246efd77-fe39-405d-b4ed-b4cc5ce072f5', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:06', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f71f073e-982f-4c38-abfe-f1efa96534ed', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d3179315-9708-4c4e-b9b4-2f83e3175574', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('58799b6c-48b8-4279-90d6-a364c3b51b2f', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('377c836c-90de-413f-a53b-eae26bc62535', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e976fdaf-8427-4244-8efd-94b8c97eb0dd', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:07', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3899196d-7b11-426d-9ed7-2a09822c8bac', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('92db81a7-60f7-4c7c-b560-84ac9e29fd79', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9f0a8578-514d-409a-b458-4591621dd218', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7d720f20-95c0-4f89-ba87-6d3e6ff991eb', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a263a519-2440-405f-8b79-19f64566b08c', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2072682e-3192-4ce7-a1a7-a21d5978e285', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:08', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b899b874-bb53-4e38-8050-8260f55869ad', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('47e9492b-025d-4bc2-9964-f34ae5f245dc', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c9ab651f-13be-491d-9428-9c5ec2daaca8', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e3f328f4-edf4-4713-b61d-c3444bd7fdce', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a0fcb5cd-bc58-40ea-bae2-c4dbcf3b1696', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('28e47c0d-057d-4ae6-bc40-7758fdc8384c', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:09', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f88323b1-9a7d-447b-abe7-ab6ffee0cc8a', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fa42f100-dfd0-42b1-aaae-ad5fc38bb0ef', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c82ba4e5-8095-4f72-8a64-cca2fe6bf5ff', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('eb79d128-c1c6-4b71-ab8c-36f56b22afbf', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2bbadfbb-b70c-438f-abbf-8c21a0e34d67', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0cdf974d-14a1-4d58-a83f-cd94ce95de1f', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:10', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b454df77-0b14-49cd-b3b8-a5f8d1046acb', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('cdbaf345-b7e3-408b-b574-04f3d362df2c', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('cbddf7ea-702c-4534-be04-fa23ef4df5f3', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('92f67cfb-770b-48fd-9759-980f8223126e', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e300d5e6-ea72-4808-b6a9-ec9bc40f9750', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7b3878e0-10d3-4f06-8180-ed0c11022d37', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0881156d-3e85-4883-aa34-358873edc257', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:11', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0f34d1b7-32ba-4400-8f01-d613c3943a58', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5834ed6d-9bdf-4ef5-854c-eae72565cf88', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f4102f5a-753e-4b8d-8a70-8401a5b84f11', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('18d1ebf1-e806-448d-b28a-4e3ddba0270b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bb138d55-2902-4fc2-bfae-bce55e343758', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('443836e6-fc3f-42ed-9a46-3221c3ee2004', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:12', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('dc1d84c4-8f4f-4fc7-83c8-c67c0bce21b0', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('45bc6f79-4cc2-4554-83ce-561d5a4d0d16', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('34e093d8-9124-4073-b15a-7d53f0a2549a', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2b4b9851-c058-4d22-949a-1ac7947781da', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4b185767-9c2a-4f19-aab9-6500d0cf9519', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0f223d4e-2759-4b2a-b9b7-5c53cc6d792c', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bcef2134-6e78-4af4-8a12-b77a2a8f57dd', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('cfd4db93-b546-4507-820c-e95d5e62f950', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('518b3987-4931-48a0-89e3-172fd61500ba', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('eaa618fa-6faa-4420-b455-ba6fedcc677e', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('be300238-c784-4b39-8e88-e59605bc57a8', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fe7e2d51-4625-406a-9b15-444a921e2f1b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a5058119-e767-466b-8d6a-9fa7d268c9e5', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bb817735-87e0-4868-a79c-f18d9e172507', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3c97fc74-13e8-45a3-aa1f-21a3e420af4a', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8b5f49ce-646b-4071-931e-caaed604a02b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('90f8fd24-2a00-4f6c-84ab-677df2201c0d', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('05bf32f8-241b-4e0b-9835-14b297374413', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:16', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('108197fa-e0ed-4cd5-9284-127204428b51', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:17', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('db8e9ee9-d8ed-4a5b-8f40-37767738256e', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:17', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('96a09637-f2a4-4721-a420-5ad118c8373f', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:17', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('63cd815d-842b-46bf-a891-806aa2e36713', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7b1dd2e7-bee0-42a9-8c23-134789e4e289', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('281ca5d6-de95-4127-9b70-5ff0f00842bf', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('66102990-54c7-451e-a191-a11273742376', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:18', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d361e97e-5299-4122-96db-b5a6079a0e59', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fe015376-46aa-42e0-8e2f-5b614c86eee2', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1193091d-aa41-40be-9c50-6919c8857d0b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c2da3bfa-3a20-47f6-ae85-05121d93dc3a', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:19', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('03786a22-df51-4773-9eb0-70ad462bea7a', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:20', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c27cb0cd-c803-4919-b2cd-a59e52482636', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:20', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('873d3b88-0087-4f03-bfd8-7ef5d6143292', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 11:21:20', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1f344464-9040-4e6c-9613-9976a77454f3', '阿菲菲', '380045ae-5f9f-4009-b818-daedf5adc931', '2019-05-04 11:33:34', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d677a2a4-a1f4-4b02-b867-05045a7dfe37', '阿菲菲', null, '2019-05-04 11:42:42', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_agree_answer_article` VALUES ('96cab8ab-1568-44bf-b30b-647f7817e77b', '阿菲菲', null, '2019-05-04 11:50:04', '加菲猫', '1', '28d7d198-f6bc-40f4-937a-bc3bde235280');
INSERT INTO `record_user_agree_answer_article` VALUES ('2cacba59-8c64-474b-961c-19838342fa9e', '阿菲菲', null, '2019-05-04 11:50:20', '加菲猫', '1', '459af1f1-a907-4800-8d62-3a5824d9f913');
INSERT INTO `record_user_agree_answer_article` VALUES ('a2e58813-7a32-4e55-b0c4-c423bee70dc5', '阿菲菲', null, '2019-05-04 11:50:23', '加菲猫', '1', 'a97ee283-c951-44b2-bdd0-c5b022c8baea');
INSERT INTO `record_user_agree_answer_article` VALUES ('95f61069-e3f1-4cb8-9216-bd9a087eacb0', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:37:55', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1b6716ff-a6c7-4d52-81a0-be1d570d6996', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:37:57', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2edb5edf-ea63-40b5-b38f-b420e1d1cf29', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:02', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('01899fe7-8298-4aa9-877c-944da3d6223c', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:05', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('58bbb979-4941-464f-9ac1-782ac570271a', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:13', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('752768b4-56e1-42ef-be17-d16ba0e28063', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:14', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ac682194-f7ab-4244-90c9-81c3b43d53fd', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:15', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f958fb1f-f703-47a6-9fa1-0886f99f3a78', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:15', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a1c5e60e-eb9a-47c3-ac94-00207a4d51eb', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:15', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('95270916-a19c-4b6e-8e6f-67af39a0c003', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:16', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('057cb3f5-1d80-4d40-9d09-6f87d72a8fb9', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:16', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('837c766b-6a26-40d9-b36a-61702254c373', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:38:16', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('43c96615-4b52-4e33-ab0f-6cd30b13aa07', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:28', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f121449b-fd5f-478f-8206-fc280f3de79b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:38:29', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ebfe44ac-7f3e-4812-be07-0c81ac38538d', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:39:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8e0cb279-7417-4ce4-ba59-5460000583ff', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:39:17', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8896db2e-08cc-451c-9949-99c70505f592', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:39:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b09316a8-a0bc-47bc-b617-3a363f7d81e1', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:00', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1e613f1c-4a0d-436d-98c9-e12e91369761', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6190be46-ed6e-473a-a79a-7425a3d4af36', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('fe5beccb-7828-4c7d-bb6a-6bcdd1e04496', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:01', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f16efae7-f620-4e80-acf7-761f1c12b029', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a85a94ed-383b-4314-84b6-79874ef38349', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:02', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('abde8eb9-5f2f-4362-84fc-8599d8133bfb', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('8689ff70-ad47-4e8e-8a59-75d9f35b44ca', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3da18191-ec94-410b-b6c9-aa9397d380bd', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:04', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d014ca62-47e2-4f66-b468-b6638598269a', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e7924136-8bdf-48a2-ba12-951e08ebd69a', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('694eded7-2569-4699-8484-d776608da639', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ebccd2f0-577c-4c2f-bc79-74254e38f040', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ea1d63e7-a225-4ef3-abd9-7f1d976fc1ff', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b049a103-3117-486b-9615-7112a7ff9111', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:05', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9e239a3c-8dae-4305-80e5-2526e3828600', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:40:08', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c84627a7-307b-4b62-a462-d0a768ce1fc2', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:41:03', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('21f5f68e-d97b-4b9c-96c9-f46576c63f13', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:41:35', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('54ce7032-625e-40f6-b64e-77e08d95a476', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:41:55', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('22b6429a-8e5d-4c6b-82ac-d1e07b6d22de', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:42:17', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2da5f0c6-15d3-432d-b448-e05b3178630c', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:42:17', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bd07b96d-980d-4806-acb4-f4fe1fad0316', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:42:21', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bbb2a037-fa10-432f-9b8d-b53e8e387148', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:42:47', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0dc0c6be-f39a-4775-9dab-e27505779c61', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:43:33', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d71973d1-1ed6-4856-9ac8-afc547e023e4', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:43:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0a7f3910-3349-4eea-9823-7f8c400083ee', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:48', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('eeec0f62-5444-4478-8e8e-0b09d8fb543f', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:50', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('61c8b48e-f90e-4c0b-8623-4b426747f488', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('97b39c5a-5057-449f-b52b-c7f2b1585e4d', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7c237ac4-aed6-4d5b-9f78-1d5a142a9c7b', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('927d803f-83bd-4907-8a1c-78015b2a5b36', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:51', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('09dbd01e-16e3-4737-90e7-079e1b0aabd0', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e5b8c95c-3008-4354-a030-bfadc2e267d6', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('844fb6f7-b4fc-4af8-b1c1-be1ffee5b90a', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7b586643-ce30-45eb-8327-c52af956208c', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5e5a24fc-420a-42b6-afe5-ceece52117f5', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('badefb3f-6226-4f79-873a-5fd3a270f1a6', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:52', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('58961d55-cd60-4c2b-b13e-b5dfd50810e9', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5362ddc6-2db8-4dcf-a421-9b7401467e46', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('525b735c-bb82-450f-ad97-87bba1336be7', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e962be61-93cc-4263-a09e-529608eaf3d4', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:53', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2e90f7b3-9683-4517-bc51-81af7b29bab9', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:55', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5f0027c7-de84-4f89-b0d5-84c0bf59410e', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:56', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e08457af-b1d6-4014-88da-899de46ea903', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:56', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2d4ed400-1449-415e-ba47-4daf47d9c3bf', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:57', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('906c1235-7956-42fb-aec3-3b64df4fbba2', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:57', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('66f9ff1d-b9bc-4a80-a834-e3dd16dae485', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:57', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('665e5b34-81c9-438a-8f16-07f70181648a', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e72c1c73-7f1f-445e-8edd-39fdc12d2abe', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('6a7b8ffc-98be-4daf-8373-ee328cb191a2', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c8a98754-b985-40b2-aaaf-ea9add6c2d80', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5c6d7655-5288-4565-bb22-8b71d95a6266', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:58', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('aeed303a-873e-493b-84ac-fa92a82fcbe5', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f5e6d5b2-757f-4a32-b692-c748621ea416', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('1c03a0f1-2157-4185-8949-5bce615ee3de', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d40523b2-d296-4ad2-b1e7-1e4b9fec7223', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:43:59', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('850a022e-9f4f-42e7-b223-7c3fdbc5bfce', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:45:03', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3b5f5083-4b7f-44d5-b1c4-f6e9e9bc5d25', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:45:11', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('061953fc-3c36-48f1-aef8-b4002fe07524', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-04 13:45:19', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('397f498f-53bc-47a0-93c3-a1b448d801ca', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-04 13:45:55', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('431a772b-14c2-4547-8970-336a5a767c81', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:46:28', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ede1109e-f5a4-4a31-9a1e-4904172d8295', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:46:37', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('74d79433-fcc5-4d2f-9655-3403ad891a39', '加菲猫', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:47:14', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('63a206a2-e09a-4077-931f-1747b210ce43', '加菲猫', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:47:20', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ed92a18f-587e-4c7c-99a5-49aa9442a49b', '加菲猫', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:47:41', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bc913c0b-a647-40ef-9e5e-11ccbe304013', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-04 13:47:59', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9ded5b14-a4c0-4750-834b-b941a7953862', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:48:43', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('07dfbeeb-3821-47a3-87a6-0e9d94ecf92c', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:48:45', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('e02415fa-8529-40ad-be86-4c21de5583a7', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:48:52', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('661c40da-5a6d-4575-bb4a-be3cb2f6d74b', '阿菲菲', '23290b33-8fc4-496b-a261-2d3d1368037b', '2019-05-04 13:48:54', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('16205325-11fa-4b04-af5d-477dea2d1b42', '阿菲菲', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '2019-05-04 13:49:19', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('2f519d18-6cfe-445a-9318-9252a48f6275', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-04 13:52:31', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('acc1318d-bcad-4999-93e8-31b3721fe605', '阿菲菲', null, '2019-05-04 14:56:40', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_agree_answer_article` VALUES ('8b3c550a-d77b-44bd-a2d7-0cbfc2dbc780', '阿菲菲', null, '2019-05-04 14:57:12', '加菲猫', '1', '1b085133-b37e-44f6-8dda-52bf5205dc77');
INSERT INTO `record_user_agree_answer_article` VALUES ('664beaca-9dfa-41e5-bb41-9d88e294b5b8', '阿菲菲', null, '2019-05-04 15:34:02', '加菲猫', '1', 'c5db833c-5f27-44a5-a7cd-0307e9dd3050');
INSERT INTO `record_user_agree_answer_article` VALUES ('11e8d05f-561f-4798-81ce-e43bd16902c6', '阿菲菲', null, '2019-05-04 15:35:37', '加菲猫', '1', '38ebb34b-71d1-492a-a786-f407fc8b1388');
INSERT INTO `record_user_agree_answer_article` VALUES ('7610f17e-6731-4cbc-9404-c4cbc2d49952', '阿菲菲', null, '2019-05-04 16:03:03', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_agree_answer_article` VALUES ('06ab9716-dbfc-4f80-a7c3-d878e8b20fad', '阿菲菲', 'ee296d46-a18f-4573-bb35-156e84637712', '2019-05-05 12:29:06', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('42a18f2d-7bec-46e9-b2e0-6ddd3e08140a', '阿菲菲', '7b12111b-0ae9-4965-b049-52a10e97e34f', '2019-05-05 19:19:29', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('bb9864f3-b0e8-4ad9-a8da-83f670b4928c', '加菲猫', null, '2019-05-07 09:35:56', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_agree_answer_article` VALUES ('77234f1e-28d6-4886-96dc-a40a6acafb4d', '阿菲菲', null, '2019-05-07 09:40:26', '加菲猫', '1', '4669bc01-e935-4e69-a4e8-e202b7e4ff4e');
INSERT INTO `record_user_agree_answer_article` VALUES ('7fcab5b0-914a-41a3-aeae-1224c1207b89', '加菲猫', null, '2019-05-07 09:42:52', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_agree_answer_article` VALUES ('19e618cc-611d-4351-8791-bd4df3fc61d6', '阿菲菲', null, '2019-05-07 13:17:28', '阿菲菲', '1', 'bd359937-76a2-4685-a12b-291dbd0525f2');
INSERT INTO `record_user_agree_answer_article` VALUES ('e6a617cd-68ad-4364-abb4-df1747ffd7d3', '加菲猫', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', '2019-05-07 13:47:37', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('268aa7e9-bf53-4966-81e5-e6fce0af6b46', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-07 13:48:13', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('13ba799e-b8d4-4df5-9ba0-5ba7d538403b', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-07 13:48:15', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a18a0824-9c05-41f8-ae3f-aaba798502e1', '阿菲菲', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '2019-05-07 13:48:17', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5bd05bff-ab77-4eda-b62b-ee68440a258a', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:20', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('da4d5c6b-b4d1-4bfa-bf41-e640d4332459', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:21', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ae0dcbdd-7313-4693-92d0-93bffb4f9dcd', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9b59a0e8-51db-451f-9be8-2173ab19b5d3', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9fd33b27-645a-4b92-9820-b005d271cbcb', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('4f4308d9-9d0c-472c-9bbc-379964cd2107', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('97da6fed-7d99-4948-87e2-c8f2c889d486', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('090fb23c-079a-4762-850d-43a38855b60f', '阿菲菲', 'ab799560-1289-42e8-a719-e3ab7b201822', '2019-05-07 13:48:22', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('13e85095-e1c7-4b7c-8666-938d820b4ded', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:23', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9b583c6f-9e81-48ca-a9ab-9cb5bac2d842', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('3c1a7875-8c37-4537-880a-7c8d9c361b61', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('f5e49729-ad5d-451d-ab3c-de2e42e81280', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d857f6a2-a749-44f3-a325-1d347b38d38a', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:24', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('12efc28e-bb05-4c18-ae18-89575660758c', '阿菲菲', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '2019-05-07 13:48:25', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('9f02b73a-d93b-4208-b8de-d6a5ab722297', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('7271d71f-a339-4130-ad1a-26ae7442b137', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('a2ce9528-4f9c-4668-a667-fac40b33b720', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('997cf4e2-0c08-4487-8edf-97996ded73a8', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:26', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('874c60b7-6954-4138-b4b1-87187dbfff8b', '阿菲菲', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '2019-05-07 13:48:27', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('b1829049-2b50-4863-bd54-7353d9a8d5c4', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:28', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('ab4b9d0d-3166-4998-923f-f6404f453f5c', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:28', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('c4d165d3-9e89-4d8b-99b1-a003cc74161d', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:29', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('0ffdebc4-f8f4-432a-9038-57141a5b9c72', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:29', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('80090ea0-bca6-4e2f-a5f5-c7f3a30c4c94', '阿菲菲', 'a784f169-edc5-4c9c-b7a8-c2d9b995ffed', '2019-05-07 13:48:29', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('82dfc5f6-6aaa-4852-91a1-efc9e984fbf6', '阿菲菲', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '2019-05-07 13:48:30', '阿菲菲', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('5244cf35-b45f-4344-b505-b0bf5ddef0de', '阿菲菲', '28a3cca4-bc71-4a12-bece-7847570edfb7', '2019-05-07 13:48:34', 'shenshenshen', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('d022c33d-451b-4363-843d-20ff40069eeb', '阿菲菲', 'f63762f6-de9b-4805-a6a6-b3b3a4434648', '2019-05-07 13:48:36', '加菲猫', '0', null);
INSERT INTO `record_user_agree_answer_article` VALUES ('87c60724-c770-4ab0-adc7-d590d093526f', '阿菲菲', null, '2019-05-07 15:02:55', '加菲猫', '1', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8');

-- ----------------------------
-- Table structure for record_user_like_answer_article
-- ----------------------------
DROP TABLE IF EXISTS `record_user_like_answer_article`;
CREATE TABLE `record_user_like_answer_article` (
  `rowguid` varchar(255) NOT NULL,
  `answerid` varchar(255) DEFAULT NULL,
  `likefrom_user` varchar(255) DEFAULT NULL,
  `likedate` datetime DEFAULT NULL,
  `to_user` varchar(255) DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `articleid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rowguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of record_user_like_answer_article
-- ----------------------------
INSERT INTO `record_user_like_answer_article` VALUES ('00b7b7a5-7a52-405f-97a5-9ee8b73b7fff', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '加菲猫', '2019-04-18 16:06:14', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('01107334-357d-41bc-b9cc-1df39f05dbe6', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-04 13:51:53', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('02470a70-464f-44e3-a000-665334ccffe1', null, '阿菲菲', '2019-05-04 15:37:01', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('0249fc04-e1db-49cc-b1b2-c040b07b4de0', null, '阿菲菲', '2019-05-09 14:15:31', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('02b916d5-ba4e-45a4-874f-7dcf4defe9af', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-08 13:09:41', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('0397fa80-8022-4a3d-8332-ec1c48620bd1', null, '加菲猫', '2019-04-26 17:27:35', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('0407f01f-574e-45e3-b9a4-d1a2a93f326e', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:58:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('0506ac3f-8053-4c22-bf39-f50f0a4b48b9', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '阿菲菲', '2019-05-04 11:16:41', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('06c52d68-942a-47fc-9290-cea87981cb93', null, '阿菲菲', '2019-05-09 14:15:30', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('070f9d11-c908-490d-add0-77677d374cb6', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:08', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('0726a89a-7202-465b-896e-d7bf9ee56d88', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '加菲猫', '2019-04-26 19:22:11', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('0765e2fd-b8ab-403d-bbca-b7a23379af7d', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:58:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('08223629-f475-47de-af40-7655e04782b7', null, '阿菲菲', '2019-05-08 13:10:00', '加菲猫', '1', 'a639c2d9-942c-414b-9422-5e6f15a6400f');
INSERT INTO `record_user_like_answer_article` VALUES ('095b8ad9-5a98-46fa-b654-5b3ddd68cda8', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '阿菲菲', '2019-05-04 11:16:41', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('097e60b4-9857-4641-ab0f-012930392ef6', '9600475d-ec3e-4309-a781-28485880cb48', '加菲猫', '2019-04-18 22:06:51', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('0998faf0-f888-4959-ac8d-c67dc4db2eba', 'ee296d46-a18f-4573-bb35-156e84637712', '加菲猫', '2019-04-29 09:50:02', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('09bcc696-a8fb-411c-8b66-b729be176244', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:28', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('0abb7249-2aeb-4c32-acdb-20a98d021de1', null, '阿菲菲', '2019-05-08 13:09:59', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('0af78828-e41e-48ac-8f63-f2d354664a96', null, '阿菲菲', '2019-05-09 14:15:29', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('0b22c7e4-ed1e-488a-a07e-35643bbfd1cd', null, '加菲猫', '2019-04-26 15:33:12', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('0be8e1e4-0248-4ae9-8b2d-5edb138e28f8', null, '加菲猫', '2019-04-26 15:30:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('0c4ac84d-7633-4ee9-9b01-eb03d0f2b33a', null, '阿菲菲', '2019-05-04 15:38:45', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('0c920dba-1bd4-4d16-bfa8-ce63f4e60e01', null, '阿菲菲', '2019-05-04 15:37:19', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('0d298c34-91a8-4def-ba97-a32408965b13', null, '阿菲菲', '2019-05-04 15:37:02', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('10bdaeb3-5dee-4efe-9d33-3a55671f72b5', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:35', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('1177a547-21fa-48e5-9010-b8810e346e57', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:35', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('14e57564-6990-4b75-b0ca-a910e03edcb0', null, '阿菲菲', '2019-05-04 15:37:01', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('1568099e-1a04-49cc-aaed-3141f5ab867b', null, '加菲猫', '2019-04-26 15:33:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('161db290-962a-49cf-9a98-054af2704d21', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:58:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('170c5dd8-d606-4f3f-8afe-f24b49f66f77', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('174092f9-d03c-4b39-bb0e-08a37a9983da', null, '阿菲菲', '2019-05-08 13:11:51', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('17b3a6d4-4ad1-4d60-9002-752c1571a3d2', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('1848a964-a341-48f7-a9f4-303b18eaf027', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:28', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('1854e882-e16a-4622-b6da-24ce8925b806', null, '阿菲菲', '2019-05-04 15:38:45', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('187411b4-2ff1-4a9f-bef0-8cdc6b8709bb', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('1905dbb8-de4c-4bb7-81e7-e3d50b0998a0', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:32', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('19e73899-0d66-4775-9e4f-4980469d8cf7', null, '阿菲菲', '2019-05-04 15:37:01', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('19fa010f-42d7-4d7d-90ce-310aa3065d33', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '加菲猫', '2019-04-18 16:06:14', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('1b08ab56-c849-4909-bcaa-c1eeb6508c3d', null, '阿菲菲', '2019-05-04 15:38:41', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('1b5c9dfb-6a0f-4b96-8528-c7682c9d7992', null, '加菲猫', '2019-04-26 15:33:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('1b80d92a-150d-47b7-8514-bf0b25c17796', null, '阿菲菲', '2019-05-04 15:38:40', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('1bac30d1-5fb4-474e-b639-20e34c2b8625', null, '加菲猫', '2019-04-26 15:33:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('1be93435-49f9-4070-a26f-8e29349c898c', null, '阿菲菲', '2019-05-04 15:37:04', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('1c5c6b6d-2114-4121-9598-6b2dae10f86a', null, '加菲猫', '2019-04-26 15:33:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('1cc4d615-7697-4013-bd1d-c0d5e4f74bda', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 14:19:49', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('1e33708f-0c8b-4aad-889e-ced7c7f58360', null, '阿菲菲', '2019-05-04 15:38:41', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('1ea762f4-a663-413f-955c-f55aa18375af', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '加菲猫', '2019-04-18 16:06:14', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('203f6b83-54a2-4d8d-8774-b4bf3ae343e1', null, '阿菲菲', '2019-05-04 16:02:44', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('20fff664-0e9f-49be-9d50-f706444263b2', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:49:31', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('219cbb78-09ad-4d95-bb61-6dbaf43f988e', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '阿菲菲', '2019-05-04 11:16:40', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('21c6c722-f409-4edb-9b74-1eb89c411b81', null, '加菲猫', '2019-04-26 15:33:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('22602f85-0783-497f-be4c-bb5a1fa3318f', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('23724b17-9021-4eef-8875-c16d9abf25b0', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:40', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('23ba4f78-543b-455e-ac09-4452b6f09df1', '23290b33-8fc4-496b-a261-2d3d1368037b', '加菲猫', '2019-05-08 14:04:02', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('284b4f81-a19e-43da-a382-a995db85b2ae', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:57', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('28787939-6ef8-484e-be10-e21c87dd9bbc', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:37', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('293ba4c4-45b1-4865-8c11-6acac83ad8e1', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 15:32:25', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2a30a945-c4ad-4919-8f71-267c7bee9803', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 13:46:19', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2a46e9ee-73cc-4ff2-bdae-d3878830a2f7', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '加菲猫', '2019-04-26 19:22:11', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2af31a82-4ac4-4f8f-b89f-11fca94aa836', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:24', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2afd91a8-8867-40da-85ea-c3e95d72a14d', '08fcf5d1-0442-4b48-809d-82d6211bcfa6', '阿菲菲', '2019-05-04 11:07:18', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2b839ba5-0ae8-470c-add9-5b6db2b77b1d', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 13:51:48', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2d00765f-f22c-4c81-a3a9-41cb55e0fa64', '9600475d-ec3e-4309-a781-28485880cb48', '加菲猫', '2019-04-18 15:53:57', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2d17b906-820e-41df-b987-02e838aef690', null, '阿菲菲', '2019-05-04 15:37:14', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('2e3db59a-867e-4b27-ad19-1227d179e4c1', null, '阿菲菲', '2019-05-04 15:37:01', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('2e571a75-b827-4d76-8754-632d5823874e', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:58', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2eb17487-81cb-4a5b-b6d3-9a59bf47f31e', null, '阿菲菲', '2019-05-04 15:37:03', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('2f65584d-3505-4a14-bf33-cdbcd6375890', '9600475d-ec3e-4309-a781-28485880cb48', '加菲猫', '2019-04-18 22:06:51', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('2f69929b-d95d-4de8-9c80-4ae7877132a6', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:53', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('30d711bd-006a-430d-b181-a36b939167e9', null, '阿菲菲', '2019-05-07 13:16:31', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('321bc74a-cab6-4e27-8c36-77676d6dc2d5', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('321c3265-b738-49fe-93a4-1853592ce5ff', null, '阿菲菲', '2019-05-08 13:09:59', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('3225d993-608f-441c-9bd3-c9918ea6c6ff', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '阿菲菲', '2019-05-04 11:30:48', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('32509dd7-695a-4903-b3c7-020496acade0', null, '阿菲菲', '2019-05-04 15:37:14', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('326d7d53-a291-4c51-a4b2-9858fc5a32e0', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:37', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('337be78c-27f9-462e-b414-f06ad8b0fcca', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:03', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('33c083f1-c39e-4832-9a1a-c1056fdfc302', null, '阿菲菲', '2019-05-07 13:16:31', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('34fa63b3-206c-4ff7-89d1-0a69302670dd', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-08 13:09:41', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('3646cbc5-1549-471c-8cd5-589cd908442e', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:24', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('39a0ca11-4a36-4cca-8014-fe3487bd2b9f', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:09', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('39fc4049-b577-42e6-b1fa-f491f9bf707e', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-04 13:51:53', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('3a496f25-f9d8-48f9-9cbe-5e62f3fe43cc', '505bbe4d-dff6-4321-9927-9c7d13eb0dff', '阿菲菲', '2019-05-08 13:09:49', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('3b32f87a-8290-432d-9e95-6dc986adb398', null, '阿菲菲', '2019-05-04 15:37:02', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('3c669044-dbce-4684-9942-8e6b6661d09d', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:36', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('3cd62e59-6ad9-49b5-9f4c-e62a250581f2', null, '阿菲菲', '2019-05-04 15:37:04', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('3df348e3-2cff-42b8-a9c0-8a05c5ddecb4', null, '阿菲菲', '2019-05-04 15:37:15', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('3eb05e69-2298-46af-be72-c6ba4152cb6f', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:36', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('4011ba64-5816-4036-9dc3-ce7335a29bc7', null, '加菲猫', '2019-04-26 15:33:06', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('41a1d2ef-4c65-4b8c-9874-497c3ce74a7c', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:05', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('424bee39-c65b-4536-9c70-51dee3999177', null, '阿菲菲', '2019-05-09 14:15:31', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('4451c977-9cd9-44b7-b1e4-68e0b9ed1b95', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:52', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('455d17c0-6035-4516-98cb-216aa61a60ba', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:55:47', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('46a80152-b1be-42ff-8a63-31119f8078ac', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-08 13:09:29', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('46dceb8d-506c-4107-80a7-153ee82381d6', 'ab799560-1289-42e8-a719-e3ab7b2018221', '加菲猫', '2019-04-26 18:27:25', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('46ed5aac-ff87-4e1b-8410-e2fc6b1cc3b8', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:05', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('475683c5-0383-45b4-971f-5bf70d83b91f', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-08 13:09:40', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('47bf51cc-2949-4c74-bc55-5fbbb2a7871b', '23290b33-8fc4-496b-a261-2d3d1368037b', '阿菲菲', '2019-05-07 13:37:06', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('48c272f3-6913-4331-9610-211219446811', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:28', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('48e18f0c-b068-490c-b491-0b7b22837503', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-04 13:51:53', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('49113a2e-8ab9-4ecc-a521-06dde24484b5', null, '阿菲菲', '2019-05-04 15:37:02', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('49136cb0-645f-4e74-8c96-d85154b08390', 'bfd642fe-28d7-4fa2-9921-f971e620a080', '阿菲菲', '2019-05-04 14:19:53', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('492e95b2-f7ae-4d52-b314-bb36fb29e798', null, '阿菲菲', '2019-05-04 15:38:41', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('49b48672-b235-4a76-bcd6-396f554850da', null, '阿菲菲', '2019-05-08 13:09:59', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('4a08ea07-9ca3-4a01-b3e7-2681952cb551', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:37:20', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('4a31c1ee-eb60-4ff4-83fd-a386660fa08d', null, '阿菲菲', '2019-05-04 15:37:19', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('4b855174-2c52-4b57-8276-2ce6f4b142f6', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('4bbcca9c-8b56-452d-ae0f-3ff46127b5c1', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-25 18:28:10', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('4bc8096c-da67-4989-8fc1-c9dcd339547e', null, '加菲猫', '2019-04-26 15:32:59', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('4d417beb-6378-46bc-918d-68af0e8939c0', '7b12111b-0ae9-4965-b049-52a10e97e34f', '加菲猫', '2019-05-07 13:46:52', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('4d62704b-89fb-415d-8c6e-2b433e7b52c1', null, '阿菲菲', '2019-05-08 13:09:56', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('4d691353-4633-4814-ab88-653fc71d2978', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:05', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('4df74bd7-e523-441e-b68f-faf097e4cd32', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '加菲猫', '2019-04-25 18:28:08', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('4f1122e8-cabe-4a20-9ae6-c5ed484f84d2', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('516fe3e7-cf7b-490b-8c24-67f77e0ea3e5', null, '阿菲菲', '2019-05-04 15:38:39', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('5379c8dc-22ac-4911-9d26-e4de3147ed57', null, '阿菲菲', '2019-05-04 15:38:39', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('53f2f78f-0e6c-47aa-b9e0-ffb2048a7aae', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:36', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('543c1d95-1391-451b-b98c-d51d72f214ab', null, '加菲猫', '2019-04-26 15:33:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('54ae437b-4658-4272-8720-bf8e71a3ce92', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('54dc5f70-d9d3-45ad-ad68-08a0dc4adf76', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 14:19:51', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('573d7221-68fc-4138-bf26-9acf28e3d1dd', 'ee296d46-a18f-4573-bb35-156e84637712', '加菲猫', '2019-04-29 09:50:02', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('596cff6a-4fe8-4a3f-9c1d-5ef450f61dcd', null, '阿菲菲', '2019-05-09 14:15:24', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('5a013329-cdce-48db-b18f-388fd964ff34', null, '阿菲菲', '2019-05-04 15:38:41', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('5a8b87c9-2787-4cc0-854e-2339fccbf16c', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:52', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('5aa3c317-5025-42e9-a4ae-d312018292be', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:38', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('5c3b297f-60be-4f62-ab95-05694dfc8f94', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-04 13:51:52', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('5c97dbd3-51cb-4264-8b49-86f341696370', null, '阿菲菲', '2019-05-04 15:37:03', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('5de840b4-7584-4f4c-88f3-5a7a82525a59', null, '阿菲菲', '2019-05-04 15:37:14', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('5e1aa558-75c4-4d90-a024-046eca01042f', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:09', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('5e3d04f4-6a4d-4077-8aaf-d0b19a983eb4', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:58', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('5e4b9706-7408-457f-9a3e-f5b2e859deb2', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '加菲猫', '2019-05-04 11:04:35', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('5eac8f17-899b-482b-a579-be6198aa6af4', null, '阿菲菲', '2019-05-04 15:37:05', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('5ff7658d-ab51-489e-8d80-39e0a7087382', null, '加菲猫', '2019-04-26 19:21:39', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('60a4f51a-2de3-4322-a184-85842432d906', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 22:03:29', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('60d61c2a-2e40-44a9-8656-c5271b422206', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:37', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('60f36ea0-3083-421d-b437-4c39521c882a', null, '加菲猫', '2019-04-26 15:33:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('61b1a70b-108d-4449-a835-fafaed80b38c', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:04', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('63222ce5-3887-4af7-896e-f79863b849a8', null, '阿菲菲', '2019-05-04 15:37:04', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('67e56263-7e9c-48b6-b19e-994c3a94c407', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('68c2f62c-e24a-4df6-aa1a-d4afdcc8d65c', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:03', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('6b69ea22-5810-47a3-b08a-6cf272b03878', 'ab799560-1289-42e8-a719-e3ab7b201822', '阿菲菲', '2019-05-07 13:49:24', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('6c4846d5-1423-4bc1-8b4f-e35856a53f50', null, '阿菲菲', '2019-05-08 13:10:05', '加菲猫', '1', 'a97ee283-c951-44b2-bdd0-c5b022c8baea');
INSERT INTO `record_user_like_answer_article` VALUES ('6ca62451-2f97-41c1-bde8-95f84e4b8446', null, '阿菲菲', '2019-05-04 15:37:02', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('6d33f345-048b-4cc8-950c-fa2ddd45c7e9', null, '阿菲菲', '2019-05-04 15:38:45', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('6dbea028-f4d2-4631-8c2b-dc4c677e8993', null, '加菲猫', '2019-04-26 19:21:39', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('6ec31b17-e254-40a8-92d4-e6ac5349b61e', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:35', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('6ec6b168-da1a-4ed5-bf65-b6c7885c07a6', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:03', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('6ef07919-3183-46fe-bab8-927167eeb1b8', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:49:33', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('71e77f20-cf06-4586-8164-2c18e418b7e4', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:58:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('72b9c54f-6776-446d-bd27-ac94d518a1f0', null, '阿菲菲', '2019-05-04 15:38:41', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('72c073b2-174d-4481-98e6-6142f36a6b4a', null, '阿菲菲', '2019-05-04 15:38:41', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('7395bac1-c961-47ae-8ba4-346d9cbea6f9', null, '阿菲菲', '2019-05-09 14:15:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('73c6eb3b-64d1-469a-b751-05d45be8e2fa', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:56', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('73e32f71-f404-4c52-919d-29fe8057b99a', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:56', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('73eafb94-4c39-407d-85d1-3c69073b4701', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('73f8172c-8743-4a90-b084-b531ff1bbccf', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '阿菲菲', '2019-05-04 11:31:03', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('76ae9f71-6866-4532-a661-2396225b2ba0', null, '阿菲菲', '2019-05-04 15:37:05', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('76e74ea9-bf7c-4fb7-85dd-2ac015a89698', null, '阿菲菲', '2019-05-04 15:37:05', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('774ba055-3499-4fdf-b41a-20d44d684056', '715a7a3b-52b8-48b4-80d2-e313ce491865', '加菲猫', '2019-04-18 22:06:53', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('7799eb9d-46bc-45af-8bed-84e102ac5e93', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:58', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('7a92c835-f875-4b06-84c4-e539cf4474ac', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-08 13:09:40', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('7b0af356-3dd8-405a-a5e0-b9dae975abd6', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:35', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('7b19a5f7-331a-42ef-b07e-a0d4703752e8', null, '加菲猫', '2019-04-26 15:33:12', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('7d26b281-8554-47b0-9062-785954526a72', null, '阿菲菲', '2019-05-08 13:09:56', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('7d422207-c786-4618-881c-2fafe3b0a969', null, '加菲猫', '2019-04-26 15:31:37', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('7d7040e7-fb94-479c-99e8-6bfaa3620b49', '715a7a3b-52b8-48b4-80d2-e313ce491865', '加菲猫', '2019-04-18 22:06:53', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('7dcf3808-9c5f-4273-93b7-c70dd25c642a', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:35', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('7e2d8bcd-8e1d-4474-acf2-6fdf1aa07c68', null, '加菲猫', '2019-04-26 15:33:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('7f46e42e-4bb3-40d2-94f0-b27ffd573597', null, '阿菲菲', '2019-05-04 15:37:15', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('7faf36d6-6916-4388-a7a7-8facd71ae6f2', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('7ff5b47d-f88d-4de1-8916-88d4efb9c3c2', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:41:26', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('808b333e-e0f0-4366-bf47-1ebbe4cf3b20', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:36', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('81700cbc-7200-4fb5-af6a-76dc01719514', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:36', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('822d63bc-fd0e-452a-9d2d-b530db5d0e98', null, '阿菲菲', '2019-05-09 14:15:28', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('82d06a9d-ed57-478a-b9b3-ce78ecb42c54', null, '阿菲菲', '2019-05-08 13:09:59', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('83ebc560-8025-4256-adf4-a4ba2a51107e', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '阿菲菲', '2019-05-04 11:30:44', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8413f15e-5e6f-4571-bdab-97285334a4c4', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:06', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8595d567-4bfc-4b21-a81e-571cdc593ac9', '6a33608e-1e74-443e-87b5-4a31234e742c', '阿菲菲', '2019-05-04 11:07:12', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('860e1dd6-c79b-4f45-85b5-782cf79c0d54', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:54:54', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('87db10f2-6e4c-4575-afc5-033c4116b558', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:54:19', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('88b3bebe-5dc2-4da8-8df4-a4ab4d685df9', null, '阿菲菲', '2019-05-08 13:09:55', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('898367d3-4f05-4e92-b6db-76c588bc5510', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('899dadb6-5543-45b2-81f4-9a2f834dcd80', null, '阿菲菲', '2019-05-04 15:37:00', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('8a10e79e-caf0-48f4-a978-be9db4c99e3a', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:03', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8aac115a-0a44-48a3-9657-25ece13bba1e', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:23', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8b3bc062-ef9c-4f74-9061-9099217d9a80', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:05', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8bc19b96-1d76-479c-943a-fc58af27bb18', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 13:49:29', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8bcb4635-0bd5-4483-b582-0e73f03cae55', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:40', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8bce3d14-b7d0-4bcf-834f-f34a096c5991', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:04', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8bd5614a-4ce4-45c6-bcb5-01fa0fb77de2', null, '加菲猫', '2019-04-26 15:33:12', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('8c195bb6-305f-4f6c-96f2-afb9999f3b37', null, '阿菲菲', '2019-05-04 15:37:02', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('8c612464-ee9e-4ef7-9aeb-374a7b45b2e3', null, '加菲猫', '2019-04-26 15:32:13', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('8f2b1b5a-c770-4e92-a418-87ebf31af92a', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:09', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('8f9d2172-3ca5-4d55-8f7d-eaa4493746b4', null, '加菲猫', '2019-04-26 15:33:05', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('90491fe7-1297-4f17-b0bd-dc75dbb3aad0', 'caf9e628-b02e-4f03-a1c1-b6fa5d446744', '阿菲菲', '2019-05-07 13:46:25', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('91a6eddb-8e6a-44cf-9ed2-d9cd6ba3bb31', 'ee296d46-a18f-4573-bb35-156e84637712', '阿菲菲', '2019-05-05 12:29:19', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('91d57252-db30-4161-959b-8b2a021cca71', null, '阿菲菲', '2019-05-04 15:37:18', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('93ac98d1-9adc-4062-8398-8ee866bfda70', null, '加菲猫', '2019-04-26 15:32:59', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('951b18ca-d41c-4455-93eb-0d04c730ed6e', 'a81b9581-2fef-48cf-97f1-3806a4d00b56', '加菲猫', '2019-05-07 13:47:29', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('959a4412-5b9d-46ae-b742-5b23eb959c72', null, '阿菲菲', '2019-05-04 15:37:14', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('962a93fb-bcd6-4ab7-b086-7e1a6288699b', 'ee296d46-a18f-4573-bb35-156e84637712', '加菲猫', '2019-04-29 09:50:02', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('9630370b-05e8-4695-b0fb-394720c213cb', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-04 13:51:51', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('9671b802-418c-474c-9e33-7b3789f29b36', '80ae0b1e-4fd0-4f69-99c4-9bbd3fd8c661', '阿菲菲', '2019-05-07 13:46:33', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('973d5108-07ac-4a8e-828a-46b3eddec29d', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:08', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('978b008d-60db-4cda-a7bb-48a2e353848f', null, '阿菲菲', '2019-05-04 15:37:00', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('98650252-9704-49b4-a558-257782a246bd', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:41:25', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('998c3243-08d3-4540-815a-481996662555', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('9b4bcf08-82fe-47a3-977e-6081abc5dcdc', null, '阿菲菲', '2019-05-04 15:38:40', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('9b717b01-9241-4742-aa8c-15eb1191a0c2', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '加菲猫', '2019-04-18 16:06:14', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('9b942c4f-ff4c-43e6-8b40-7eb709c48a3e', 'b5bdc021-ca35-44da-923e-a11e0f9d5706', '阿菲菲', '2019-05-04 11:12:41', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('9c7207f3-7790-4a91-b0ed-5864fef344e6', null, '加菲猫', '2019-04-26 15:32:59', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('9e8cb40a-6378-4c12-87d9-b21cdfa4bbc5', null, '阿菲菲', '2019-05-04 15:37:15', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('9f2c66b3-d6f6-4132-9c81-cca0e2fb2679', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:41:25', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('9fb598ee-df15-4e16-b1b5-9b88c51c9c6f', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:36', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('9fe75e11-da8c-4256-ab00-b00578de38fd', null, '阿菲菲', '2019-05-07 13:16:32', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('a069ad71-46d2-45f4-8bfb-92fa502cf7a3', null, '阿菲菲', '2019-05-07 15:03:46', '加菲猫', '1', '82d19fa0-1c90-4998-8bef-9cee2b3f34f8');
INSERT INTO `record_user_like_answer_article` VALUES ('a09a8122-d95e-4159-81ca-631846e8dce0', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-08 13:09:41', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a2087969-894d-443b-9128-558304e67b47', null, '阿菲菲', '2019-05-04 15:38:40', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('a2495004-931f-46b0-bd46-7371fe75072c', '6a33608e-1e74-443e-87b5-4a31234e742c', '加菲猫', '2019-05-04 11:04:29', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a36a61c3-f0c3-46fe-948a-b74e41d4313d', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:03', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a38e4268-aabb-46e6-9a64-0eb988869ccb', null, '阿菲菲', '2019-05-04 15:37:04', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('a3db777c-650e-4041-9415-5ed65a9cd288', null, '阿菲菲', '2019-05-09 14:15:29', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('a46b280e-bc24-4548-91b2-d3a483fd246d', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:58:59', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a49c3f5f-cc2a-4490-8685-c006bf1c31d5', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:09', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a4b51279-1c4e-4eee-b46a-963dae6871a9', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:55:44', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a666df77-87d3-4bd8-b08f-a84fedd24c65', null, '加菲猫', '2019-04-26 15:33:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('a6d3b505-00e8-47b5-a939-55979d72e4cc', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-05 19:17:09', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a85f82b6-12c1-44f4-9a06-05398c7cfd3f', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:37', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('a999cff3-4de6-42d3-90db-adfd4e28be4c', null, '阿菲菲', '2019-05-04 15:37:01', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('aabc5d6a-24bd-4f81-aa6c-00631f07b525', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:05', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ac84c9c4-0c27-4029-8620-509fbf24b1c9', null, '阿菲菲', '2019-05-04 15:38:45', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('addac917-60c0-4a7f-8741-b5c56ce6d2a2', 'ee296d46-a18f-4573-bb35-156e84637712', '阿菲菲', '2019-05-05 12:29:21', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ae3fc7c5-6882-40ed-b804-06800ca74474', null, '阿菲菲', '2019-05-04 15:37:03', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('b03d9048-02dd-4467-8739-57e7baa698f2', '715a7a3b-52b8-48b4-80d2-e313ce491865', '加菲猫', '2019-04-18 22:06:53', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b0431001-6e4d-4c22-9429-56891a6d06be', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-04 13:51:53', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b0983569-0c72-494e-96ba-159cd33de57e', null, '阿菲菲', '2019-05-04 15:38:39', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('b12db700-87ae-4c43-a5d1-83cb6712911d', null, '阿菲菲', '2019-05-04 15:37:01', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('b145fe47-8b61-4c61-8541-2d246024996e', null, '阿菲菲', '2019-05-04 15:37:05', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('b283ee71-ee48-4f30-a821-94b7a5bdb47f', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:43:20', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b2b90a19-eb8b-4232-a025-a70b7c14f94d', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:58', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b313060e-1665-45e4-8320-396a8c4e0332', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b3161aab-f82e-44f1-a76b-1db315578677', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 15:38:51', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b3770a36-df91-431d-bf1c-559137c3015c', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:44', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b39fc946-a719-4bf3-b1cb-a1b8a4c31ff2', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:41:25', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b3e15249-714b-4f85-92b4-bb65f2ed8616', null, '加菲猫', '2019-04-26 15:33:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('b40f6c3f-da75-4936-90d7-7c0b4c3e3ad2', null, '加菲猫', '2019-04-26 15:32:59', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('b4532a90-3dff-4dba-877d-fef608bb3594', null, '阿菲菲', '2019-05-09 14:15:30', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('b5568ee6-4b3c-4977-8be8-6e2f227fa242', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '加菲猫', '2019-05-07 13:46:54', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b5dcd1f2-b2bb-42c7-8ad5-059967ef8be2', null, '加菲猫', '2019-04-26 15:33:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('b5effe4d-9ca8-42db-878d-b65c19c7e328', null, '加菲猫', '2019-04-26 15:33:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('b6845e60-d97d-4ffa-9414-7137a22b0e99', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:06', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b6b0fa29-bbf9-4903-97be-7f297700f447', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:51', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b70fac80-6975-4f73-b487-732bf3341131', null, '阿菲菲', '2019-05-04 15:37:04', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('b8cb005d-474e-4549-8d7c-0c75a35282da', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-08 13:09:24', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('b9fb2a9e-d6e7-498e-954e-3713e4af98c2', null, '阿菲菲', '2019-05-08 13:09:56', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('ba9606dc-7d7c-41a9-9292-080409832268', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 22:03:30', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('babaa06d-78bf-4d39-b121-8c4f2821e910', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:57', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('bc24754e-249d-4943-8e33-299ce4e0e500', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:51', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('bc8ddae9-c6c1-46b2-b29e-edeb2a01bed0', null, '阿菲菲', '2019-05-04 15:38:40', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('bd625233-4779-4ee3-865e-98309527e0de', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:35', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('bebe4ce4-5d24-4dec-9434-b6787d3663f0', null, '阿菲菲', '2019-05-04 16:02:41', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('beed1026-f199-4f60-b243-bed4e71f761d', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '加菲猫', '2019-04-26 19:22:11', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('befc58d9-c14e-4318-a905-bcf7d6d59444', null, '阿菲菲', '2019-05-04 15:38:45', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('bf04d722-bbf9-4e98-bd97-bbfde64c449d', null, '阿菲菲', '2019-05-09 14:15:28', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('c14314db-e003-43b1-aded-0db5667149b0', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:52', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('c15788cd-dbee-41c8-bba9-d3d2569d16af', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:44:32', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('c1971bcb-8116-44a5-994c-8a54dd695f79', null, '加菲猫', '2019-04-26 15:30:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('c420d78c-a3a9-4cad-a71f-cb26ffcc0186', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:38', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('c672afc0-ead4-4c65-b7e0-c484ad57356a', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:08', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('c6b2532d-2f31-46df-b708-1646ec1910f5', null, '加菲猫', '2019-04-26 15:33:19', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('c6e56512-69b5-4b24-8096-6e9663fb2d51', null, '阿菲菲', '2019-05-04 15:37:15', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('c7364832-107d-4ded-a73c-eb786a346b81', '715a7a3b-52b8-48b4-80d2-e313ce491865', '加菲猫', '2019-04-18 22:06:52', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('c9a13053-03d7-49af-8cf2-3ebe794f3ebd', null, '阿菲菲', '2019-05-04 15:37:00', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('ca02c182-9f5c-41d9-9a0e-47be431b8f10', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 15:38:53', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ca0d4ec1-8ffa-42b1-8001-5cdd7a09a456', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '加菲猫', '2019-04-26 19:22:17', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('cac7cb91-1062-4a0c-bd6a-36d9fced8165', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:09', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('cb600627-1777-4a67-9e16-cb16436f2add', null, '阿菲菲', '2019-05-04 15:37:02', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('cc06b2b4-6402-45e9-8ba3-a7063790ebe3', null, '加菲猫', '2019-04-26 15:33:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('cccab230-4fa5-4482-81f6-f54423034c71', null, '阿菲菲', '2019-05-04 15:37:03', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('cce04ad9-b677-4f3e-abbe-2e246930f1b5', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:58', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ce466e52-ba98-4113-b16d-7b4c39dc205b', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:35', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('cf0fc339-1e7d-4ab0-8c2a-26091015b72e', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '加菲猫', '2019-04-25 18:28:09', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('cf5a2bfb-15e6-41a0-b5ad-522a204ce9e8', null, '阿菲菲', '2019-05-04 15:37:04', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('cfd22d1f-c921-4cd7-9f83-12c98eb88eed', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:57', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('cfe7c1b0-3c6c-42f9-a7e2-a924a00d4053', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:55', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('d0f592f3-094d-4a61-bd16-a850092fe354', null, '阿菲菲', '2019-05-04 15:38:41', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('d17995b4-ccd9-496e-96c9-191034e430a3', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:37:18', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('d20d5a94-434c-4502-a51e-29502f9bb6b5', null, '阿菲菲', '2019-05-04 15:37:14', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('d215b406-1c2a-43b4-b2af-ce0517275fa0', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 13:49:25', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('d2642bde-c739-4a6e-937e-1d56be46bded', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:37:11', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('d38bc73d-0a96-4064-955c-4258b77c0641', null, '阿菲菲', '2019-05-04 15:37:03', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('d7681c44-11f2-4a30-bdf1-3a3495964415', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:58', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('d917f6e6-23c9-46fc-9654-8c37337aa6f0', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-04 13:51:46', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('d92d8db3-d8e1-4014-86cd-be096b2a52c4', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:37:12', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('d9388135-3072-45d8-b6f3-ca1be7d501f0', null, '阿菲菲', '2019-05-05 08:35:26', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('da125125-bddb-4e4e-b7f1-eb0b5dddfece', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-08 13:09:27', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('da252c99-2a8e-4b3e-884f-ff364ed02fc5', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:57', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('da6baae2-8aac-49b4-b360-700165816b0b', '9d98f4be-e9e5-4dfa-8b76-116a6b8f0a79', '阿菲菲', '2019-05-07 13:48:38', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('da70a5e2-cfce-4950-97cc-c7337559624a', '7b12111b-0ae9-4965-b049-52a10e97e34f', '阿菲菲', '2019-05-07 13:37:43', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('da8246a6-9678-4da0-9def-443a0b831bac', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('db958294-2981-4000-80de-4dc3056053df', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:37', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('dc48767d-3f11-4121-a19c-874109b93920', null, '加菲猫', '2019-04-26 15:33:12', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('dc952696-3bb6-4536-8e16-7b33bcbba90b', 'caf9e628-b02e-4f03-a1c1-b6fa5d446744', '加菲猫', '2019-05-07 13:46:50', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('dce58de4-4cf7-4028-87bc-2ef43af19d75', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:58', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('dd1d077d-1e8d-4037-bbb5-dc2a56ace06a', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:41:25', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('dd70dec3-6cf1-450d-a3d1-74019806bba0', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:56', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('def8aa7f-85c5-4945-b289-8c73c1fb3342', null, '阿菲菲', '2019-05-07 13:16:31', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('df836a93-7d04-419f-a66a-1591befe5a5a', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:31:08', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('dfbfdb0c-5448-432a-b6ca-061dc9dddee3', null, '阿菲菲', '2019-05-04 15:37:05', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('e0aecbbc-d803-44d8-94f8-1a1803ead767', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:37', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e122a01a-a0af-47d9-a577-05225cb48512', null, '加菲猫', '2019-04-26 15:30:33', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('e172802a-9909-40b2-bc79-88f86644a9f0', null, '阿菲菲', '2019-05-09 14:15:29', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('e1c768a6-3169-4c32-9b86-827bd7cc46e3', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:00', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e335cb4f-7890-4d9e-9a00-f8a106b6f800', '96c69a38-c4fe-4393-8463-90b29a3e3ff0', '阿菲菲', '2019-04-26 19:06:22', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e336c302-8890-4bf3-b642-6614dc279fe2', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:37', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e371d1ff-b783-4a0f-92bd-ce82886851e7', '80ae0b1e-4fd0-4f69-99c4-9bbd3fd8c661', '加菲猫', '2019-05-07 13:46:48', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e3cc68d7-ca07-4e3a-9fb0-bca7fb859ea7', '3e68f7f2-293f-4973-9f50-ba9a35c0de28', '加菲猫', '2019-04-18 16:06:14', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e4cc025d-740f-410d-8180-76dc323395f5', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:43:22', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e4ee2745-f0e5-4884-9715-f0840e857271', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:24', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e5c57035-d9be-4571-b36e-cba78f824963', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 13:46:18', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('e707bba7-c184-420c-acf7-7cb31b42ae0b', null, '加菲猫', '2019-04-26 15:33:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('e82317d9-8dd5-4637-bf39-3b14efe8ff04', '9600475d-ec3e-4309-a781-28485880cb48', '加菲猫', '2019-04-18 22:06:51', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('eaa5a424-1da3-4242-96b6-5e9df8ebc7a8', null, '阿菲菲', '2019-05-04 15:37:14', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('eaa8f06a-4609-4ef7-9e3a-1476660c4903', null, '阿菲菲', '2019-05-08 13:09:57', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('eb8252e8-a1d3-4f1c-b407-d45fbf98cdbb', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:53:52', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ec3f1a0f-f4fa-4191-b699-a2cdba3ca2c2', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 18:26:02', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ecadca9d-a7fc-4996-8950-4acbd3bb86db', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:57', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ecd08971-bd23-4a61-a010-9c9a7f40e5ff', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:05', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ecdc964a-1638-43a4-a589-73ab92f26118', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-25 18:28:10', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('ecec7522-327b-4ad7-a51c-1428b191061e', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:28', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('eef1ac9e-a2a8-45df-9d39-04e33ce82d9e', null, '加菲猫', '2019-04-26 15:33:21', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('eef8d655-b439-4bd1-8861-4948aa661d05', 'ee296d46-a18f-4573-bb35-156e84637712', '加菲猫', '2019-04-29 09:50:02', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('efa07e4c-2e63-45bc-b233-9386413c032f', '3c0a891e-7207-4545-9421-f8fa284c00e6', '加菲猫', '2019-04-18 15:59:23', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('efc67172-7c8f-4375-b8e3-89199b9aefc3', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:27', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f0bb6946-139d-46a5-a4cf-a04859af0cec', null, '阿菲菲', '2019-05-09 14:15:31', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('f0d8e7e1-d026-480a-8c81-803f4cc37b0f', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:36', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f1736f2d-78a8-44ff-a99d-39faaee3a4b3', null, '加菲猫', '2019-04-26 15:33:22', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('f17cba63-5a02-4416-a303-5350323ad7aa', 'ab799560-1289-42e8-a719-e3ab7b201822', '加菲猫', '2019-04-26 15:32:25', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f2ba2809-9691-42e1-916a-b6fafff28963', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:38:57', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f2c31854-7418-4a48-822b-3dbea5576e69', null, '阿菲菲', '2019-05-09 14:15:29', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('f31b5b75-c49d-43d2-8d91-5c4891b488f7', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-04 11:04:24', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f31b853a-02dc-41af-a01b-3957a0d0fdca', null, '阿菲菲', '2019-05-04 15:37:01', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('f33a8060-80e5-4caa-bb39-c998e15485f2', 'fb7fe65b-9bba-40d3-8ea9-e8c8bbcea618', '阿菲菲', '2019-05-08 13:09:36', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f3a01e1e-53a5-4a80-89f6-360517871b38', 'ce5a78c8-1e80-4a19-816e-2368a1a682ab', '阿菲菲', '2019-05-04 15:39:02', '加菲猫', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f4232b45-292f-47cb-9c24-54d383c2b225', null, '加菲猫', '2019-04-26 15:33:20', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('f487e21f-45f4-40e4-bde1-8c7e90e6375a', null, '加菲猫', '2019-04-26 15:32:14', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('f5104e50-e368-4d53-b694-4c0b7088fac6', null, '阿菲菲', '2019-05-04 15:38:40', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('f56b3a15-5973-4e8c-896f-0a3285fb5d1b', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:40:55', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f600fc69-298a-4e1d-b37d-916ad3b30ed6', null, '加菲猫', '2019-04-26 15:32:58', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('f620e76d-0732-4c0d-add9-286e59375cb4', null, '阿菲菲', '2019-05-04 15:37:15', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('f78352df-2bbf-4865-9d5c-8d445c0a7f4c', null, '阿菲菲', '2019-05-08 13:09:58', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('f841386c-ac66-42c6-835f-e1100245134f', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:56:28', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f88be35e-0ab8-404f-abca-b081a51ca05e', null, '加菲猫', '2019-04-26 15:30:34', '加菲猫', '1', 'b6c07cbd-3a2d-42a3-b9a9-8b0ad5a7aa17');
INSERT INTO `record_user_like_answer_article` VALUES ('f89c4208-df55-4b1b-acfb-9168dadafb15', 'b3f47953-9c17-4c08-9e95-20a2a352d5df', '阿菲菲', '2019-05-07 13:41:25', '阿菲菲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('f9f55c12-469b-4c2b-9682-07c459f04b9b', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:51:27', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('faf02f40-b0fa-4563-8cf6-40d99db2c168', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:06', '天天敲', '0', null);
INSERT INTO `record_user_like_answer_article` VALUES ('fb11b1f3-9140-4721-9523-69d6950d1d1a', null, '阿菲菲', '2019-05-04 15:38:40', '加菲猫', '1', 'e2626f4c-3179-45e2-ae34-5df19d8ece30');
INSERT INTO `record_user_like_answer_article` VALUES ('fbc0de85-8091-4cea-9133-2a60c8cf67c8', '0b21166a-7a5a-4fb2-a8d6-4a95aa2e95d3', '加菲猫', '2019-04-18 15:57:06', '天天敲', '0', null);

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `userid` varchar(50) NOT NULL,
  `loginid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `sex` int(2) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `sign` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `liketype` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `shownews` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES ('1fc59d56-05d2-4157-82ff-cce9b9124a34', 'shenshenshen', '111111', 'shenshenshen', null, null, null, '1049106373@qq.com', null, '1,2', null, null);
INSERT INTO `userinfo` VALUES ('6f62d7ee-a62c-4e58-acae-9577b0b4a6da', 'afeifei', '111111', '阿菲菲', '1', null, '嗡嗡嗡', '1049106373@qq.com', '18638920420', '1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20', '10491063673', '1');
INSERT INTO `userinfo` VALUES ('ea31ec8f-e856-4f5a-8c68-77f44699294f', 'maomao', '111111', '加菲猫', '1', null, '555nihao asd&nbsp;', '2504571076@qq.com', '18638920420', '1,4,5,6,9', '1049106373', '1');
INSERT INTO `userinfo` VALUES ('8bab4815-9cf6-4c10-b8c8-25d9576b714f', 'wuwuwu', '111111', '天天敲', '0', null, '你是谁啊？啊啊啊<img src=\"http://localhost:8083/shenshenshen/layui-master/src/images/face/51.gif\" alt=\"[兔子]\">', '1049106371@qq.com', '18638920420', '4,6,17,21', '2504671076', '1');
INSERT INTO `userinfo` VALUES ('615f45a2-413a-46f7-b1ad-2841460736d4', '555', '7777', 'wuwuwussde', null, null, null, 'aaaa11@qq.com', '15465945848', null, null, null);
INSERT INTO `userinfo` VALUES ('c98592dd-9f25-4d8b-abba-bad61c63423c', '0000001', '123456', 'fys', '1', null, '<br>', '535282037@qq.2', '18638920428', '1', '535282037', '1');

-- ----------------------------
-- Table structure for user_care
-- ----------------------------
DROP TABLE IF EXISTS `user_care`;
CREATE TABLE `user_care` (
  `rowguid` varchar(255) NOT NULL,
  `be_cared_userid` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`rowguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user_care
-- ----------------------------
INSERT INTO `user_care` VALUES ('231be6fa-d592-4be5-9ec4-e7b56e0cfa0e', '8bab4815-9cf6-4c10-b8c8-25d9576b714f', '8bab4815-9cf6-4c10-b8c8-25d9576b714f', '2019-04-13 23:16:18');
INSERT INTO `user_care` VALUES ('2b85ca32-42bc-4a61-a710-b77b1baa80b1', '6f62d7ee-a62c-4e58-acae-9577b0b4a6da', '1fc59d56-05d2-4157-82ff-cce9b9124a34', '2019-04-11 16:08:37');
INSERT INTO `user_care` VALUES ('620e84f2-5d87-447b-9aa7-d848f1ef3d9d', '6f62d7ee-a62c-4e58-acae-9577b0b4a6da', 'ea31ec8f-e856-4f5a-8c68-77f44699294f', '2019-04-11 21:03:59');
INSERT INTO `user_care` VALUES ('8ba490d9-2738-48ff-8149-5652774d684c', '6f62d7ee-a62c-4e58-acae-9577b0b4a6da', '6f62d7ee-a62c-4e58-acae-9577b0b4a6da', '2019-05-04 11:11:41');
INSERT INTO `user_care` VALUES ('9d808c55-f85c-4db5-bd0c-0e1a1d61e615', 'ea31ec8f-e856-4f5a-8c68-77f44699294f', '6f62d7ee-a62c-4e58-acae-9577b0b4a6da', '2019-05-03 20:14:58');
INSERT INTO `user_care` VALUES ('c85de653-0e98-4e2c-afd8-332179ebfe93', '6f62d7ee-a62c-4e58-acae-9577b0b4a6da', '8bab4815-9cf6-4c10-b8c8-25d9576b714f', '2019-04-13 12:42:39');
INSERT INTO `user_care` VALUES ('e0b1c6e0-e12c-48b1-bf7b-0ab9e79c0438', '8bab4815-9cf6-4c10-b8c8-25d9576b714f', 'ea31ec8f-e856-4f5a-8c68-77f44699294f', '2019-04-18 21:50:40');
INSERT INTO `user_care` VALUES ('e4b8957a-2f07-4c3d-bf3f-adcb2cdf1743', '1fc59d56-05d2-4157-82ff-cce9b9124a34', '6f62d7ee-a62c-4e58-acae-9577b0b4a6da', '2019-04-10 17:36:03');
INSERT INTO `user_care` VALUES ('e772d52f-3a6e-4c57-b526-c871906fed00', 'ea31ec8f-e856-4f5a-8c68-77f44699294f', 'ea31ec8f-e856-4f5a-8c68-77f44699294f', '2019-05-03 18:50:28');
INSERT INTO `user_care` VALUES ('e7bf0b87-15ff-42d9-977c-900ddcc64529', 'ea31ec8f-e856-4f5a-8c68-77f44699294f', '1fc59d56-05d2-4157-82ff-cce9b9124a34', '2019-04-25 18:34:19');
